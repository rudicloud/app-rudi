"use strict";
(() => {
var exports = {};
exports.id = 7905;
exports.ids = [7905];
exports.modules = {

/***/ 714:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4685);
/* harmony import */ var _components_ui_counter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1129);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6740);
/* harmony import */ var _framework_product_get_product__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8843);
/* harmony import */ var _framework_utils_get_variations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2349);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9627);
/* harmony import */ var _contexts_cart_cart_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5495);
/* harmony import */ var _utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9792);
/* harmony import */ var _components_product_product_attributes__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5923);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3590);
/* harmony import */ var _components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7906);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_icons_cart_icon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4904);
/* harmony import */ var _components_ui_tag_label__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1453);
/* harmony import */ var _components_icons_label_icon__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4475);
/* harmony import */ var _variation_price__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9774);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(113);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_get_product__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_13__, _components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_14__]);
([_framework_product_get_product__WEBPACK_IMPORTED_MODULE_6__, react_toastify__WEBPACK_IMPORTED_MODULE_13__, _components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const ProductSingleDetails = ()=>{
    var ref, ref1;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_15__.useTranslation)("common");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { query: { slug  } ,  } = router;
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { data , isLoading  } = (0,_framework_product_get_product__WEBPACK_IMPORTED_MODULE_6__/* .useProductQuery */ .F)(slug);
    const { addItemToCart , isInCart , getItemFromCart , isInStock  } = (0,_contexts_cart_cart_context__WEBPACK_IMPORTED_MODULE_9__/* .useCart */ .jD)();
    const { 0: selectedQuantity , 1: setSelectedQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: attributes , 1: setAttributes  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: favorite , 1: setFavorite  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: quantity , 1: setQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: addToCartLoader , 1: setAddToCartLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: shareButtonStatus , 1: setShareButtonStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { price , basePrice , discount  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP)(data && {
        amount: data.sale_price ? data.sale_price : data.price,
        baseAmount: data.price,
        currencyCode: "Ugx"
    });
    const handleChange = ()=>{
        setShareButtonStatus(!shareButtonStatus);
    };
    if (isLoading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "Loading..."
    });
    const variations = (0,_framework_utils_get_variations__WEBPACK_IMPORTED_MODULE_7__/* .getVariations */ .y)(data === null || data === void 0 ? void 0 : data.variations);
    const isSelected = !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default()(variations) ? !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default()(attributes) && Object.keys(variations).every((variation)=>attributes.hasOwnProperty(variation)) : true;
    let selectedVariation = {};
    if (isSelected) {
        const dataVaiOption = data === null || data === void 0 ? void 0 : data.variation_options;
        selectedVariation = dataVaiOption === null || dataVaiOption === void 0 ? void 0 : dataVaiOption.find((o)=>lodash_isEqual__WEBPACK_IMPORTED_MODULE_20___default()(o.options.map((v)=>v.value).sort(), Object.values(attributes).sort()));
    }
    const item = (0,_utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_10__/* .generateCartItem */ .z)(data, selectedVariation);
    const outOfStock = isInCart(item.id) && !isInStock(item.id);
    function addToCart() {
        if (!isSelected) return;
        // to show btn feedback while product carting
        setAddToCartLoader(true);
        setTimeout(()=>{
            setAddToCartLoader(false);
        }, 1500);
        const item = (0,_utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_10__/* .generateCartItem */ .z)(data, selectedVariation);
        addItemToCart(item, quantity);
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_13__.toast)("Added to the bag", {
            progressClassName: "fancy-progress-bar",
            position: width > 768 ? "bottom-right" : "top-right",
            autoClose: 1500,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true
        });
    }
    console.log("deburg singlepeoducts", data);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "pt-6 pb-2 md:pt-7",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "grid-cols-10 lg:grid gap-7 2xl:gap-8",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-span-5 mb-6 overflow-hidden xl:col-span-6 md:mb-8 lg:mb-0",
                    children: !!(data === null || data === void 0 ? void 0 : (ref = data.gallery) === null || ref === void 0 ? void 0 : ref.length) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        gallery: data === null || data === void 0 ? void 0 : data.gallery,
                        thumbnailClassName: "xl:w-[700px] 2xl:w-[900px]",
                        galleryClassName: "xl:w-[150px] 2xl:w-[170px]"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center justify-center w-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: data === null || data === void 0 ? void 0 : data.image_original,
                            alt: data === null || data === void 0 ? void 0 : data.name,
                            width: 900,
                            height: 680
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col col-span-5 shrink-0 xl:col-span-4 xl:ltr:pl-2 xl:rtl:pr-2",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pb-3 lg:pb-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "md:mb-2.5 block -mt-1.5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-lg font-medium transition-colors duration-300 text-brand-dark md:text-xl xl:text-2xl",
                                        children: data === null || data === void 0 ? void 0 : data.name
                                    })
                                }),
                                (data === null || data === void 0 ? void 0 : data.unit) && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default()(variations) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-sm font-medium md:text-15px",
                                    children: data === null || data === void 0 ? void 0 : data.unit
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_variation_price__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                    selectedVariation: selectedVariation,
                                    minPrice: data === null || data === void 0 ? void 0 : data.min_price,
                                    maxPrice: data === null || data === void 0 ? void 0 : data.max_price
                                }),
                                lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default()(variations) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center mt-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-brand-dark font-bold text-base md:text-xl xl:text-[22px]",
                                            children: price
                                        }),
                                        discount && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("del", {
                                                    className: "text-sm text-opacity-50 md:text-15px ltr:pl-3 rtl:pr-3 text-brand-dark ",
                                                    children: basePrice
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "inline-block rounded font-bold text-xs md:text-sm bg-brand-tree bg-opacity-20 text-brand-tree uppercase px-2 py-1 ltr:ml-2.5 rtl:mr-2.5",
                                                    children: [
                                                        discount,
                                                        " ",
                                                        t("text-off")
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        Object.keys(variations).map((variation)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_attributes__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                variations: variations,
                                attributes: attributes,
                                setAttributes: setAttributes
                            }, `popup-attribute-key${variation}`);
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pb-2",
                            children: [
                                lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default()(variations) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: Number(quantity) > 0 || !outOfStock ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm font-medium text-yellow",
                                        children: t("text-only") + " " + quantity + " " + t("text-left-item")
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-base text-red-500 whitespace-nowrap",
                                        children: t("text-out-stock")
                                    })
                                }),
                                !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_12___default()(selectedVariation) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm font-medium text-yellow",
                                    children: (selectedVariation === null || selectedVariation === void 0 ? void 0 : selectedVariation.is_disable) || selectedVariation.quantity === 0 ? t("text-out-stock") : `${t("text-only") + " " + selectedVariation.quantity + " " + t("text-left-item")}`
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pt-1.5 lg:pt-3 xl:pt-4 space-y-2.5 md:space-y-3.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_counter__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    variant: "single",
                                    value: selectedQuantity,
                                    onIncrement: ()=>setSelectedQuantity((prev)=>prev + 1),
                                    onDecrement: ()=>setSelectedQuantity((prev)=>prev !== 1 ? prev - 1 : 1),
                                    disabled: isInCart(item.id) ? getItemFromCart(item.id).quantity + selectedQuantity >= Number(item.stock) : selectedQuantity >= Number(item.stock)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    onClick: addToCart,
                                    className: "w-full px-1.5",
                                    disabled: !isSelected,
                                    loading: addToCartLoader,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_cart_icon__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                            color: "#ffffff",
                                            className: "ltr:mr-3 rtl:ml-3"
                                        }),
                                        t("text-add-to-cart")
                                    ]
                                })
                            ]
                        }),
                        (data === null || data === void 0 ? void 0 : data.tag) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "pt-5 xl:pt-6",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "relative inline-flex items-center justify-center text-sm md:text-15px text-brand-dark text-opacity-80 ltr:mr-2 rtl:ml-2 top-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_label_icon__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                            className: "ltr:mr-2 rtl:ml-2"
                                        }),
                                        " ",
                                        t("text-tags"),
                                        ":"
                                    ]
                                }),
                                data === null || data === void 0 ? void 0 : (ref1 = data.tag) === null || ref1 === void 0 ? void 0 : ref1.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "inline-block p-[3px]",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tag_label__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                            data: item
                                        })
                                    }, `tag-${item.id}`))
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductSingleDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ VariationPrice)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9627);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);




function VariationPrice({ selectedVariation , minPrice , maxPrice  }) {
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    const { price , basePrice , discount  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)(selectedVariation && {
        amount: selectedVariation.sale_price ? selectedVariation.sale_price : selectedVariation.price,
        baseAmount: selectedVariation.price,
        currencyCode: "USD"
    });
    const { price: min_price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)({
        amount: minPrice,
        currencyCode: "USD"
    });
    const { price: max_price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)({
        amount: maxPrice,
        currencyCode: "USD"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center mt-5",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-brand-dark font-bold text-base md:text-xl xl:text-[22px]",
                children: !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(selectedVariation) ? `${price}` : `${min_price} - ${max_price}`
            }),
            discount && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("del", {
                        className: "text-sm text-opacity-50 md:text-15px ltr:pl-3 rtl:pr-3 text-brand-dark",
                        children: basePrice
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "inline-block rounded font-bold text-xs md:text-sm text-brand-tree bg-opacity-20 bg-brand-tree uppercase px-2 py-1 ltr:ml-2.5 rtl:mr-2.5",
                        children: [
                            discount,
                            " ",
                            t("text-off")
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6557:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W_": () => (/* reexport safe */ swiper__WEBPACK_IMPORTED_MODULE_0__.Navigation),
/* harmony export */   "o3": () => (/* reexport safe */ swiper__WEBPACK_IMPORTED_MODULE_0__.Thumbs),
/* harmony export */   "o5": () => (/* reexport safe */ swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide),
/* harmony export */   "pt": () => (/* reexport safe */ swiper__WEBPACK_IMPORTED_MODULE_0__.Autoplay),
/* harmony export */   "rj": () => (/* reexport safe */ swiper__WEBPACK_IMPORTED_MODULE_0__.Grid),
/* harmony export */   "tl": () => (/* reexport safe */ swiper__WEBPACK_IMPORTED_MODULE_0__.Pagination),
/* harmony export */   "tq": () => (/* reexport safe */ swiper_react__WEBPACK_IMPORTED_MODULE_1__.Swiper)
/* harmony export */ });
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_0__, swiper_react__WEBPACK_IMPORTED_MODULE_1__]);
([swiper__WEBPACK_IMPORTED_MODULE_0__, swiper_react__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Divider = ({ className =""  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `border-t border-border-base ${className}`
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Divider);


/***/ }),

/***/ 8843:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useProductQuery)
/* harmony export */ });
/* unused harmony export fetchProduct */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchProduct = async (_slug)=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const { data  } = await api.get("products");
    return data;
};
const useProductQuery = (slug)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        slug
    ], ()=>fetchProduct(slug));
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4099:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProductPage),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9146);
/* harmony import */ var _components_layout_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7018);
/* harmony import */ var _components_product_product__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(714);
/* harmony import */ var _components_common_download_apps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1694);
/* harmony import */ var _components_ui_breadcrumb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9842);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_ui_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8121);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_layout__WEBPACK_IMPORTED_MODULE_2__, _components_product_product__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layout_layout__WEBPACK_IMPORTED_MODULE_2__, _components_product_product__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





//import RelatedProductFeed from '@components/product/feeds/related-product-feed';



function ProductPage() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_divider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "pt-6 lg:pt-7",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_breadcrumb__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_download_apps__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        ]
    });
}
ProductPage.Layout = _components_layout_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
const getServerSideProps = async ({ locale  })=>{
    return {
        props: {
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_6__.serverSideTranslations)(locale, [
                "common",
                "forms",
                "menu",
                "footer", 
            ])
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6740:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
// export { default as useWindowSize } from "react-use/lib/useWindowSize";

const useWindowSize = ()=>{
    const { 0: windowDimensions , 1: setWindowDimensions  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        width: undefined,
        height: undefined
    });
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        function handleResize() {
            setWindowDimensions({
                width: window.innerWidth,
                height: window.innerHeight
            });
        }
        handleResize();
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []); // Empty array ensures that effect is only run on mount
    return windowDimensions;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWindowSize);


/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8492:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 9699:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 113:
/***/ ((module) => {

module.exports = require("lodash/isEqual");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 153:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = require("react-icons/im");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 7139:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 9137:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,676,1664,5152,5225,8448,7310,5437,8965,7571,7018,4685,9627,1694,9842,1129,8872], () => (__webpack_exec__(4099)));
module.exports = __webpack_exports__;

})();