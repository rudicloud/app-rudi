"use strict";
(() => {
var exports = {};
exports.id = 7884;
exports.ids = [7884];
exports.modules = {

/***/ 2009:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8139);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8126);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9734);
/* harmony import */ var _utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2020);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9146);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7310);
/* harmony import */ var _components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8027);
/* harmony import */ var _components_icons_user_icon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3865);
/* harmony import */ var _components_icons_menu_icon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6581);
/* harmony import */ var _utils_use_click_outside__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1132);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8921);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5637);
/* harmony import */ var _components_icons_search_icon__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2453);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_16__]);
([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















const AuthMenu = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header-three.tsx -> " + "./auth-menu"
        ]
    },
    ssr: false
});
const CartButton = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header-three.tsx -> " + "@components/cart/cart-button"
        ]
    },
    ssr: false
});
const { site_header  } = _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U;
const Header = ()=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_15__/* .useModalAction */ .SO)();
    const { openSidebar , displaySearch , openSearch , closeSearch , isAuthorized , displayMobileSearch ,  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const siteHeaderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const siteSearchRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,_utils_use_click_outside__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(siteSearchRef, ()=>closeSearch());
    (0,_utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_8__/* .useActiveScroll */ .l)(siteHeaderRef, 10);
    function handleLogin() {
        openModal("LOGIN_VIEW");
    }
    function handleMobileMenu() {
        return openSidebar();
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        id: "siteHeader",
        ref: siteHeaderRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("header-three sticky-header w-full h-16 lg:h-20 sticky lg:relative top-0 z-20", displayMobileSearch && "active-mobile-search"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "absolute z-30 w-screen transition duration-200 ease-in-out innerSticky lg:fixed lg:w-full body-font bg-brand-light",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                    className: "top-bar-search lg:max-w-[600px] absolute z-30 px-4 md:px-6 top-1"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("top-bar h-16 lg:h-20 flex items-center justify-between py-3", displayMobileSearch && "active-mobile-search"),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    "aria-label": "Menu",
                                    className: "flex-col items-center justify-center hidden outline-none menuBtn ltr:mr-5 rtl:ml-5 lg:flex 2xl:hidden shrink-0 focus:outline-none",
                                    onClick: handleMobileMenu,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_menu_icon__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    className: "-mt-1 logo"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    className: "hidden 2xl:flex ltr:pl-10 rtl:pr-10 3xl:w-auto 2xl:mr-auto",
                                    data: site_header.menu
                                })
                            ]
                        }),
                        displaySearch && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute top-0 left-0 flex items-center justify-center w-full h-full px-4 sticky-search",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                ref: siteSearchRef,
                                className: "max-w-[780px] xl:max-w-[830px] 2xl:max-w-[1000px]"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex shrink-0 -mx-2.5 xl:-mx-3.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    onClick: ()=>openSearch(),
                                    title: "Search toggle",
                                    className: "items-center justify-center hidden w-8 h-full py-2 transition duration-200 ease-in-out outline-none lg:flex hover:text-heading focus:outline-none",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_search_icon__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                        className: "w-[22px] h-[22px] text-brand-dark text-opacity-40 ltr:-ml-2 rtl:-mr-2"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {
                                    className: "hidden lg:flex xl:mx-3.5 mx-2.5"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "items-center hidden lg:flex shrink-0 xl:mx-3.5 mx-2.5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                            className: "text-brand-dark text-opacity-40"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                                            isAuthorized: isAuthorized,
                                            href: _utils_routes__WEBPACK_IMPORTED_MODULE_5__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                                            btnProps: {
                                                children: t("text-sign-in"),
                                                onClick: handleLogin
                                            },
                                            children: t("text-account")
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7046:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_header_header_three__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2009);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8168);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1858);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_header_header_three__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layout_header_header_three__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function Layout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col min-h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_three__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "relative flex-grow",
                style: {
                    WebkitOverflowScrolling: "touch"
                },
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_product_product_cards_product_card_oak__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5577);
/* harmony import */ var _framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3833);
/* harmony import */ var _components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9988);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6003);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8921);
/* harmony import */ var lodash_slice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3434);
/* harmony import */ var lodash_slice__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_slice__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5239);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__]);
_framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const AllProductFeed = ({ element , className =""  })=>{
    var ref, ref1;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)("common");
    const { query  } = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { isFetching: isLoading , isFetchingNextPage: loadingMore , fetchNextPage , hasNextPage , data , error ,  } = (0,_framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__/* .useProductsQuery */ .k)({
        limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_12__/* .LIMITS.PRODUCTS_LIMITS */ .b.PRODUCTS_LIMITS,
        ...query
    });
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_6__/* .useModalAction */ .SO)();
    function handleCategoryPopup() {
        openModal("CATEGORY_VIEW");
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-between pb-0.5 mb-4 lg:mb-5 xl:mb-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        sectionHeading: "All Products",
                        className: "mb-0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:hidden transition-all text-brand -mt-1.5 font-semibold text-sm md:text-15px hover:text-brand-dark",
                        role: "button",
                        onClick: handleCategoryPopup,
                        children: t("text-categories")
                    })
                ]
            }),
            error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                message: error === null || error === void 0 ? void 0 : error.message
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6 md:gap-4 2xl:gap-5",
                children: isLoading && !(data === null || data === void 0 ? void 0 : (ref = data.pages) === null || ref === void 0 ? void 0 : ref.length) ? Array.from({
                    length: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_12__/* .LIMITS.PRODUCTS_LIMITS */ .b.PRODUCTS_LIMITS
                }).map((_, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        uniqueKey: `product--key-${idx}`
                    }, `product--key-${idx}`)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: data === null || data === void 0 ? void 0 : (ref1 = data.pages) === null || ref1 === void 0 ? void 0 : ref1.map((page, index)=>{
                        var ref, ref1, ref2, ref3;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                            children: [
                                (ref1 = page === null || page === void 0 ? void 0 : (ref = page.data) === null || ref === void 0 ? void 0 : ref.slice(0, 18)) === null || ref1 === void 0 ? void 0 : ref1.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_card_oak__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        product: product
                                    }, `product--key${product.id}`)),
                                element && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-span-full",
                                    children: element
                                }),
                                (page === null || page === void 0 ? void 0 : (ref2 = page.data) === null || ref2 === void 0 ? void 0 : ref2.length) > 18 && lodash_slice__WEBPACK_IMPORTED_MODULE_7___default()(page === null || page === void 0 ? void 0 : page.data, 18, page === null || page === void 0 ? void 0 : (ref3 = page.data) === null || ref3 === void 0 ? void 0 : ref3.length).map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_card_oak__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        product: product
                                    }, `product--key${product.id}`))
                            ]
                        }, index);
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllProductFeed);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4284:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9092);
/* harmony import */ var _components_product_products_grid_block__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8616);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_1__]);
_framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const PopularProductFeed = ({ className , variant  })=>{
    const limit = _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__/* .LIMITS.POPULAR_PRODUCTS_LIMITS */ .b.POPULAR_PRODUCTS_LIMITS;
    const { data , isLoading , error  } = (0,_framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_1__/* .usePopularProductsQuery */ .T)({
        limit: limit
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_products_grid_block__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        sectionHeading: "text-popular-product",
        sectionSubHeading: "text-fresh-grocery-items",
        className: className,
        products: data,
        loading: isLoading,
        error: error === null || error === void 0 ? void 0 : error.message,
        limit: limit,
        uniqueKey: "popular-product",
        variant: variant
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PopularProductFeed);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4937:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ useCategoriesQuery),
/* harmony export */   "p": () => (/* binding */ fetchCategories)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchCategories = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("categories");
    return {
        categories: {
            data: data.data
        }
    };
};
const useCategoriesQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/categories",
        options
    ], fetchCategories);
}; ///

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1576:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6337);
/* harmony import */ var _components_layout_layout_three__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7046);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9146);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_common_download_apps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1694);
/* harmony import */ var _framework_static_banner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4808);
/* harmony import */ var _components_product_feeds_best_all_product_feed__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1487);
/* harmony import */ var _components_product_feeds_popular_product_feed__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4284);
/* harmony import */ var _components_hero_hero_banner_with_category__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7195);
/* harmony import */ var _components_seo_seo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9183);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9717);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_query_hydration__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4758);
/* harmony import */ var _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4937);
/* harmony import */ var _framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3833);
/* harmony import */ var _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9092);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__, _components_layout_layout_three__WEBPACK_IMPORTED_MODULE_2__, _components_product_feeds_best_all_product_feed__WEBPACK_IMPORTED_MODULE_7__, _components_product_feeds_popular_product_feed__WEBPACK_IMPORTED_MODULE_8__, _components_hero_hero_banner_with_category__WEBPACK_IMPORTED_MODULE_9__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_14__, _framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_15__, _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_16__]);
([_components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__, _components_layout_layout_three__WEBPACK_IMPORTED_MODULE_2__, _components_product_feeds_best_all_product_feed__WEBPACK_IMPORTED_MODULE_7__, _components_product_feeds_popular_product_feed__WEBPACK_IMPORTED_MODULE_8__, _components_hero_hero_banner_with_category__WEBPACK_IMPORTED_MODULE_9__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_14__, _framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_15__, _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















function Home() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo_seo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                title: "Rudi Shule",
                description: "Rudi Sule | School Shopping at your fingertips.",
                path: "trendy"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_hero_hero_banner_with_category__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_feeds_best_all_product_feed__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        data: _framework_static_banner__WEBPACK_IMPORTED_MODULE_6__/* .bannerGridThree */ .u$,
                        className: "mb-12 lg:mb-14 xl:mb-16 2xl:mb-20 3xl:pb-2 pt-0.5 md:pt-0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_feeds_popular_product_feed__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        className: "mb-12 lg:mb-14 xl:mb-16 2xl:mb-20 3xl:pb-2"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_download_apps__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    });
}
Home.Layout = _components_layout_layout_three__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
const getStaticProps = async ({ locale  })=>{
    const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_11__.QueryClient();
    await queryClient.prefetchQuery([
        _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_13__/* .API_ENDPOINTS.CATEGORIES */ .P.CATEGORIES,
        {
            limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_17__/* .LIMITS.CATEGORIES_LIMITS */ .b.CATEGORIES_LIMITS
        }
    ], _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_14__/* .fetchCategories */ .p);
    await queryClient.prefetchQuery([
        _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_13__/* .API_ENDPOINTS.BEST_SELLER_GROCERY_PRODUCTS */ .P.BEST_SELLER_GROCERY_PRODUCTS,
        {
            limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_17__/* .LIMITS.BEST_SELLER_GROCERY_PRODUCTS_LIMITS */ .b.BEST_SELLER_GROCERY_PRODUCTS_LIMITS
        }, 
    ], _framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_15__/* .fetchProducts */ .t);
    await queryClient.prefetchQuery([
        _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_13__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS,
        {
            limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_17__/* .LIMITS.POPULAR_PRODUCTS_LIMITS */ .b.POPULAR_PRODUCTS_LIMITS
        }
    ], _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_16__/* .fetchPopularProducts */ .R);
    return {
        props: {
            dehydratedState: JSON.parse(JSON.stringify((0,react_query_hydration__WEBPACK_IMPORTED_MODULE_12__.dehydrate)(queryClient))),
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__.serverSideTranslations)(locale, [
                "common",
                "forms",
                "menu",
                "footer", 
            ])
        },
        revalidate: 60
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useOnClickOutside)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useOnClickOutside(ref, handler) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const listener = (event)=>{
            const el = ref === null || ref === void 0 ? void 0 : ref.current;
            if (!el || el.contains((event === null || event === void 0 ? void 0 : event.target) || null)) {
                return;
            }
            handler(event);
        };
        document.addEventListener("mousedown", listener);
        document.addEventListener("touchstart", listener);
        return ()=>{
            document.removeEventListener("mousedown", listener);
            document.removeEventListener("touchstart", listener);
        };
    }, [
        ref,
        handler
    ]);
}


/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 9318:
/***/ ((module) => {

module.exports = require("lodash/shuffle");

/***/ }),

/***/ 3434:
/***/ ((module) => {

module.exports = require("lodash/slice");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 153:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9717:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 7139:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 9137:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,676,1664,5152,5225,8448,7310,5437,8965,7571,9627,1694,4758,4109,6861,7607,2857,5371,6003,3040,9390,1999,7195,6337], () => (__webpack_exec__(1576)));
module.exports = __webpack_exports__;

})();