"use strict";
(() => {
var exports = {};
exports.id = 5279;
exports.ids = [5279];
exports.modules = {

/***/ 8785:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3833);
/* harmony import */ var _components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9988);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6003);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8921);
/* harmony import */ var lodash_slice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3434);
/* harmony import */ var lodash_slice__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_slice__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5239);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__]);
_framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const AllProductFeed = ({ element , className =""  })=>{
    var ref, ref1;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)("common");
    const { query  } = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { isFetching: isLoading , isFetchingNextPage: loadingMore , fetchNextPage , hasNextPage , data , error ,  } = (0,_framework_product_get_all_products__WEBPACK_IMPORTED_MODULE_3__/* .useProductsQuery */ .k)({
        limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_12__/* .LIMITS.PRODUCTS_LIMITS */ .b.PRODUCTS_LIMITS,
        ...query
    });
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_6__/* .useModalAction */ .SO)();
    function handleCategoryPopup() {
        openModal("CATEGORY_VIEW");
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-between pb-0.5 mb-4 lg:mb-5 xl:mb-6",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        sectionHeading: "All Products",
                        className: "mb-0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:hidden transition-all text-brand -mt-1.5 font-semibold text-sm md:text-15px hover:text-brand-dark",
                        role: "button",
                        onClick: handleCategoryPopup,
                        children: t("text-categories")
                    })
                ]
            }),
            error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                message: error === null || error === void 0 ? void 0 : error.message
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6 md:gap-4 2xl:gap-5",
                children: isLoading && !(data === null || data === void 0 ? void 0 : (ref = data.pages) === null || ref === void 0 ? void 0 : ref.length) ? Array.from({
                    length: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_12__/* .LIMITS.PRODUCTS_LIMITS */ .b.PRODUCTS_LIMITS
                }).map((_, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        uniqueKey: `product--key-${idx}`
                    }, `product--key-${idx}`)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: data === null || data === void 0 ? void 0 : (ref1 = data.pages) === null || ref1 === void 0 ? void 0 : ref1.map((page, index)=>{
                        var ref, ref1, ref2, ref3;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                            children: [
                                (ref1 = page === null || page === void 0 ? void 0 : (ref = page.data) === null || ref === void 0 ? void 0 : ref.slice(0, 18)) === null || ref1 === void 0 ? void 0 : ref1.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        product: product
                                    }, `product--key${product.id}`)),
                                element && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-span-full",
                                    children: element
                                }),
                                (page === null || page === void 0 ? void 0 : (ref2 = page.data) === null || ref2 === void 0 ? void 0 : ref2.length) > 18 && lodash_slice__WEBPACK_IMPORTED_MODULE_7___default()(page === null || page === void 0 ? void 0 : page.data, 18, page === null || page === void 0 ? void 0 : (ref3 = page.data) === null || ref3 === void 0 ? void 0 : ref3.length).map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        product: product
                                    }, `product--key${product.id}`))
                            ]
                        }, index);
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllProductFeed);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7465:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SchoolsSingleDetails)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_school_get_school__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2657);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8126);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2687);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9146);
/* harmony import */ var _components_product_feeds_all_products_feed__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8785);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6740);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_school_get_school__WEBPACK_IMPORTED_MODULE_1__, _contexts_ui_context__WEBPACK_IMPORTED_MODULE_3__, _components_product_feeds_all_products_feed__WEBPACK_IMPORTED_MODULE_6__]);
([_framework_school_get_school__WEBPACK_IMPORTED_MODULE_1__, _contexts_ui_context__WEBPACK_IMPORTED_MODULE_3__, _components_product_feeds_all_products_feed__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function SchoolsSingleDetails() {
    const { query: { slug  } ,  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("common");
    const { data , isLoading  } = (0,_framework_school_get_school__WEBPACK_IMPORTED_MODULE_1__/* .useSchoolQuery */ .e)(slug);
    const { openSchool , displaySchool , closeSchool  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_3__/* .useUI */ .l8)();
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_9__/* .getDirection */ .M)(locale);
    const contentWrapperCSS = dir === "ltr" ? {
        left: 0
    } : {
        right: 0
    };
    if (isLoading) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        children: "Loading..."
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center w-full h-56 bg-center bg-no-repeat bg-cover md:h-64",
                style: {
                    backgroundImage: `https://hub.fanitehub.com/page-header-search1.png`
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center px-4 py-4 border-b lg:hidden md:px-6 border-border-base mb-7",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex shrink-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: data === null || data === void 0 ? void 0 : data.logo_original,
                            alt: data === null || data === void 0 ? void 0 : data.name,
                            width: 66,
                            height: 66,
                            className: "rounded-md"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ltr:pl-4 rtl:pr-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "font-semibold text-brand-dark text-15px",
                                children: data === null || data === void 0 ? void 0 : data.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "block text-sm font-medium transition-all text-brand hover:text-brand-muted",
                                onClick: openSchool,
                                children: t("text-more-info")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_container__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll__WEBPACK_IMPORTED_MODULE_4__.Element, {
                    name: "grid",
                    className: "flex flex-col pb-16 lg:flex-row lg:pt-8 lg:pb-20",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full lg:ltr:pl-7 lg:rtl:pr-7",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_feeds_all_products_feed__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3833:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ useProductsQuery),
/* harmony export */   "t": () => (/* binding */ fetchProducts)
/* harmony export */ });
/* harmony import */ var lodash_shuffle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9318);
/* harmony import */ var lodash_shuffle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_shuffle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fetchProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_2__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    return {
        data: lodash_shuffle__WEBPACK_IMPORTED_MODULE_0___default()(data),
        paginatorInfo: {
            nextPageUrl: ""
        }
    };
};
const useProductsQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useInfiniteQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchProducts, {
        getNextPageParam: ({ paginatorInfo  })=>paginatorInfo.nextPageUrl
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2657:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ useSchoolQuery)
/* harmony export */ });
/* unused harmony export fetchShop */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchShop = async (_slug)=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://rsbase.fanitehub.com/api/v1"
    });
    const { data  } = await api.get(`${"shops"}`);
    return data;
};
const useSchoolQuery = (slug)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rsbase.fanitehub.com/api/v1/shops",
        slug
    ], ()=>fetchShop(slug));
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ LIMITS)
/* harmony export */ });
const LIMITS = {
    CATEGORIES_LIMITS: 18,
    PRODUCTS_LIMITS: 30,
    REFINED_PRODUCTS_LIMITS: 20,
    RELATED_PRODUCTS_LIMITS: 15,
    BEST_SELLER_PRODUCTS_LIMITS: 15,
    BEST_SELLER_GROCERY_PRODUCTS_LIMITS: 21,
    POPULAR_PRODUCTS_LIMITS: 14,
    POPULAR_PRODUCTS_TWO_LIMITS: 10,
    COOKIES_PRODUCTS_LIMITS: 15,
    CHIPS_PRODUCTS_LIMITS: 15,
    POPCORN_JERKY_PRODUCTS_LIMITS: 15,
    FRESH_VEGETABLES_PRODUCTS_LIMITS: 15
};


/***/ }),

/***/ 2930:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ShopDetailsPage),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7018);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_schools_school_single_details__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7465);
/* harmony import */ var _components_common_download_apps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1694);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_layout__WEBPACK_IMPORTED_MODULE_1__, _components_schools_school_single_details__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layout_layout__WEBPACK_IMPORTED_MODULE_1__, _components_schools_school_single_details__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function ShopDetailsPage() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_schools_school_single_details__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_download_apps__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        ]
    });
}
ShopDetailsPage.Layout = _components_layout_layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z;
const getServerSideProps = async ({ locale  })=>{
    return {
        props: {
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_2__.serverSideTranslations)(locale, [
                "common",
                "forms",
                "menu",
                "footer", 
            ])
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 9318:
/***/ ((module) => {

module.exports = require("lodash/shuffle");

/***/ }),

/***/ 3434:
/***/ ((module) => {

module.exports = require("lodash/slice");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 153:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 3094:
/***/ ((module) => {

module.exports = require("react-scroll");

/***/ }),

/***/ 7139:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 9137:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,676,1664,5152,5225,8448,7310,5437,8965,7571,7018,9627,1694,4109,7607,6003], () => (__webpack_exec__(2930)));
module.exports = __webpack_exports__;

})();