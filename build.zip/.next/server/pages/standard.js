"use strict";
(() => {
var exports = {};
exports.id = 8810;
exports.ids = [8810];
exports.modules = {

/***/ 2440:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_cards_bundle_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(559);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6740);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6557);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8139);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__]);
_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Carousel = next_dynamic__WEBPACK_IMPORTED_MODULE_4___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\bundle\\bundle-grid.tsx -> " + "@components/ui/carousel/carousel"
        ]
    },
    ssr: false
});
const breakpoints = {
    "1024": {
        slidesPerView: 3,
        spaceBetween: 16
    },
    "768": {
        slidesPerView: 2,
        spaceBetween: 16
    },
    "680": {
        slidesPerView: 2,
        spaceBetween: 12
    },
    "0": {
        slidesPerView: 1
    }
};
const BundleGrid = ({ className ="mb-12 pb-0.5" , data  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("heightFull", className),
        children: width < 1536 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Carousel, {
            breakpoints: breakpoints,
            children: data === null || data === void 0 ? void 0 : data.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__/* .SwiperSlide */ .o5, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_bundle_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        bundle: item,
                        href: `${item.slug}`
                    })
                }, `bundle-key-${item.id}`))
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5",
            children: data === null || data === void 0 ? void 0 : data.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_bundle_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    bundle: item,
                    href: `${_utils_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.BUNDLE */ .Z.BUNDLE}/${item.slug}`
                }, `bundle-key-${item.id}`))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BundleGrid);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3879);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6872);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);






const BundleCard = ({ bundle , imgWidth =180 , imgHeight =150 , className ="" , thumbnailClassName ="w-36 lg:w-32 xl:w-40 2xl:w-36 3xl:w-[180px] ltr:pr-1.5 rtl:pl-1.5 2xl:ltr:pr-2.5 2xl:rtl:pl-2.5" , href ,  })=>{
    const { image , title , description , bgColor  } = bundle;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        href: href,
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("group flex", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative flex items-center w-full overflow-hidden",
            style: {
                backgroundColor: bgColor
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("flex shrink-0", thumbnailClassName),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        src: image ?? "/assets/placeholder/collection.svg",
                        alt: t(title) || t("text-card-thumbnail"),
                        width: imgWidth,
                        height: imgHeight,
                        className: "object-cover transition duration-200 ease-in-out transform bg-sink-thumbnail group-hover:scale-105"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "py-3 lg:py-5 ltr:pr-4 rtl:pl-4 lg:ltr:pr-3 lg:rtl:pl-3 xl:ltr:pr-4 xl:rtl:pl-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "title",
                            className: "mb-[5px]",
                            children: t(title)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-sm leading-6 lg:text-13px xl:text-sm",
                            children: t(`${description}`)
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BundleCard);


/***/ }),

/***/ 4083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6872);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9732);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);





const CollectionCard = ({ collection , imgWidth =440 , imgHeight =280 , href ,  })=>{
    const { image , title , description  } = collection;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        href: href,
        className: "flex flex-col overflow-hidden rounded-md group shadow-card ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: image,
                alt: t(title) || t("text-card-thumbnail"),
                width: imgWidth,
                height: imgHeight,
                className: "object-cover transition duration-300 ease-in-out transform bg-fill-thumbnail group-hover:opacity-90 group-hover:scale-105"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col px-4 pt-4 pb-4 lg:px-5 xl:px-6 lg:pt-5 md:pb-5 lg:pb-6 xl:pb-7",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        variant: "title",
                        className: "mb-1 lg:mb-1.5 truncate transition-colors group-hover:text-brand",
                        children: t(title)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        variant: "medium",
                        className: "truncate",
                        children: t(`${description}`)
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollectionCard);


/***/ }),

/***/ 7298:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_cards_collection_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4083);
/* harmony import */ var _components_common_schools_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6787);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9146);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6740);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2857);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6557);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8139);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_5__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_6__, axios__WEBPACK_IMPORTED_MODULE_9__]);
([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_5__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_6__, axios__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const breakpoints = {
    "1024": {
        slidesPerView: 3
    },
    "768": {
        slidesPerView: 3
    },
    "540": {
        slidesPerView: 2
    },
    "0": {
        slidesPerView: 1
    }
};
const CollectionGrid = ({ className ="mb-12 lg:mb-14 xl:mb-16 2xl:mb-20 pb-1 lg:pb-0 3xl:pb-2.5" , headingPosition ="left" ,  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { 0: slideresponse , 1: setSlideresponse  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        const url = "https://rsbase.fanitehub.com/api/v1/schoolslides";
        axios__WEBPACK_IMPORTED_MODULE_9__["default"].get(url).then((response)=>{
            setSlideresponse(response.data);
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_schools_header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    sectionHeading: "text-curated-collections",
                    sectionSubHeading: "text-categories-grocery-items",
                    headingPosition: headingPosition
                }),
                width < 1536 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    breakpoints: breakpoints,
                    autoplay: {
                        delay: 4000
                    },
                    prevButtonClassName: "ltr:-left-2.5 rtl:-right-2.5 -top-14",
                    nextButtonClassName: "ltr:-right-2.5 rtl:-left-2.5 -top-14",
                    className: "-mx-1.5 md:-mx-2 xl:-mx-2.5 -my-4",
                    prevActivateId: "collection-carousel-button-prev",
                    nextActivateId: "collection-carousel-button-next",
                    children: slideresponse === null || slideresponse === void 0 ? void 0 : slideresponse.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_6__/* .SwiperSlide */ .o5, {
                            className: "px-1.5 md:px-2 xl:px-2.5 py-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_collection_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                collection: item,
                                href: `${_utils_routes__WEBPACK_IMPORTED_MODULE_7__/* .ROUTES.BUNDLE */ .Z.BUNDLE}/${item.slug}`
                            }, item.id)
                        }, `collection-key-${item.id}`))
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "gap-5 2xl:grid 2xl:grid-cols-4 3xl:gap-7",
                    children: slideresponse === null || slideresponse === void 0 ? void 0 : slideresponse.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_collection_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            collection: item,
                            href: `${_utils_routes__WEBPACK_IMPORTED_MODULE_7__/* .ROUTES.BUNDLE */ .Z.BUNDLE}/${item.slug}`
                        }, item.id))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollectionGrid);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9732);





const SchoolHeader = ({ sectionHeading ="text-section-title" , sectionSubHeading , className ="pb-0.5 mb-5 xl:mb-6" , headingPosition ="left" ,  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(`-mt-1.5 ${className}`, {
            "text-center pb-2 lg:pb-3 xl:pb-4 3xl:pb-7": headingPosition === "center"
        }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                variant: "heading",
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
                    "3xl:text-[25px] 3xl:leading-9": headingPosition === "center"
                }),
                children: "Our Schools"
            }),
            sectionSubHeading && headingPosition === "center" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                variant: "medium",
                className: "pb-0.5 mt-1.5 lg:mt-2.5 xl:mt-3",
                children: "Customised for your Shopping for your school requirements"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SchoolHeader);


/***/ }),

/***/ 8156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hero_banner_card)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(6872);
// EXTERNAL MODULE: ./src/utils/use-window-size.ts
var use_window_size = __webpack_require__(6740);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: ./src/components/icons/search-icon.tsx
var search_icon = __webpack_require__(2453);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/hero/hero-banner-search.tsx





const HeroSearchBox = ({ style , button  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("forms");
    const router = (0,router_.useRouter)();
    const { 0: searchTerm , 1: setSearchTerm  } = (0,external_react_.useState)("");
    function onSubmit(e) {
        e.preventDefault();
        router.push(`/search?q=${searchTerm}`);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: `relative flex w-full ${style !== "antique" ? "mt-6 rounded-md" : "rounded-lg mt-11"}`,
        noValidate: true,
        role: "search",
        onSubmit: onSubmit,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "hero-search",
                className: "flex flex-1 items-center py-0.5",
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    id: "hero-search",
                    className: `w-full text-sm transition-all duration-200 outline-none text-brand-dark/80 h-14 ${style !== "antique" ? "ltr:pl-5 rtl:pr-5 md:ltr:pl-6 md:rtl:pr-6 ltr:pr-14 rtl:pl-14 md:ltr:pr-16 md:rtl:pl-16 md:h-16 shadow-heroSearch placeholder:text-brand-dark/50 rounded-md" : "ltr:pl-16 rtl:pr-16 h-[70px] shadow-searchBox placeholder:text-brand-dark/30 rounded-lg"} text-brand-light lg:text-base focus:ring-2 focus:ring-brand`,
                    placeholder: t("placeholder-search"),
                    "aria-label": "Search",
                    autoComplete: "off",
                    value: searchTerm,
                    onChange: (e)=>setSearchTerm(e.target.value)
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "submit",
                title: "Search",
                className: `absolute top-0 flex items-center justify-center h-full transition duration-200 ease-in-out outline-none ${style !== "antique" ? "ltr:right-0 rtl:left-0" : "ltr:left-0 rtl:right-0 text-brand"} w-14 md:w-16 hover:text-heading focus:outline-none`,
                children: /*#__PURE__*/ jsx_runtime_.jsx(search_icon/* default */.Z, {
                    className: `${style !== "antique" ? "w-5 h-5 text-brand-dark text-opacity-40" : "w-6 h-6"}`
                })
            }),
            style === "antique" && (button === null || button === void 0 ? void 0 : button.text) ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute top-0 ltr:right-3 rtl:left-3 h-full py-3",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "submit",
                    title: "Search",
                    className: `flex items-center justify-center h-full transition duration-200 ease-in-out outline-none hover:text-heading focus:outline-none whitespace-nowrap bg-brand hover:opacity-80 text-white rounded-lg px-5`,
                    children: button === null || button === void 0 ? void 0 : button.text
                })
            }) : ""
        ]
    });
};
/* harmony default export */ const hero_banner_search = (HeroSearchBox);

;// CONCATENATED MODULE: ./src/components/hero/hero-banner-card.tsx






function getImage(deviceWidth, imgObj) {
    return deviceWidth < 480 ? imgObj.mobile : imgObj.desktop;
}
const HeroBannerCard = ({ banner , className ="py-20 xy:pt-24" , variant ="default" ,  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    const { width  } = (0,use_window_size/* default */.Z)();
    const { title , description , image  } = banner;
    const selectedImage = getImage(width, image);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_classnames_default()("w-full bg-no-repeat bg-cover bg-center flex items-center", {
            "min-h-[420px] md:min-h-[460px] lg:min-h-[500px] xl:min-h-[550px]": variant === "slider"
        }, {
            "bg-fill-thumbnail": variant !== "antique"
        }, className),
        style: {
            backgroundImage: `url('${selectedImage.url}')`,
            backgroundPosition: variant === "antique" ? "left bottom -10px" : ""
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: external_classnames_default()("mx-auto h-full flex flex-col text-center px-6 xl:max-w-[750px] 2xl:max-w-[850px]", {
                "max-w-[480px] md:max-w-[550px]": variant === "default" || "slider",
                "max-w-[480px] md:max-w-[650px]": variant === "medium",
                "2xl:max-w-[1000px]": variant === "antique"
            }),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: external_classnames_default()("text-3xl md:text-4xl font-manrope font-extrabold", {
                            "leading-snug md:leading-tight xl:leading-[1.3em] mb-3 md:mb-4 xl:mb-3 -mt-2 xl:-mt-3 2xl:-mt-4": variant !== "antique",
                            "text-brand-tree-dark xl:text-5xl 2xl:text-[55px]": variant === "default",
                            "text-brand-tree-dark xl:text-[40px] 2xl:text-5xl 2xl:mb-4 2xl:pb-0.5": variant === "medium",
                            "text-brand-light xl:text-5xl 2xl:text-[55px]": variant === "slider",
                            "text-black md:text-6xl -tracking-[0.5px] xl:mb-7": variant === "antique"
                        }),
                        children: t(title)
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: external_classnames_default()("text-base md:text-[17px] xl:text-lg leading-7 md:leading-8 xl:leading-[1.92em] xl:px-16", {
                            "text-brand-dark text-opacity-80 2xl:px-32": variant === "default",
                            "text-brand-light 2xl:px-32": variant === "slider",
                            "2xl:px-24": variant === "medium",
                            "xl:text-xl text-[#282F3B]": variant === "antique"
                        }),
                        children: t(description)
                    }),
                    variant !== "antique" && banner.btnText && /*#__PURE__*/ jsx_runtime_.jsx(ui_link/* default */.Z, {
                        href: banner.btnUrl,
                        className: "h-[45px] mt-7 md:mt-8 text-sm inline-flex items-center justify-center transition duration-300 rounded px-6 py-2 font-semibold bg-brand-light text-brand-dark hover:text-brand-light hover:bg-brand",
                        children: t(banner.btnText)
                    }),
                    banner.searchBox && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden lg:block max-w-[700px] mx-auto md:pt-1 lg:pt-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lg:flex",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(hero_banner_search, {
                                    style: variant,
                                    button: {
                                        text: banner.btnText
                                    }
                                })
                            }),
                            (banner === null || banner === void 0 ? void 0 : banner.formTips) ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-[#282F3B] font-medium text-base mt-6 opacity-70",
                                children: t(banner === null || banner === void 0 ? void 0 : banner.formTips)
                            }) : ""
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const hero_banner_card = (HeroBannerCard);


/***/ }),

/***/ 5503:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9734);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8139);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8126);
/* harmony import */ var _utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2020);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9146);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7310);
/* harmony import */ var _components_icons_user_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3865);
/* harmony import */ var _components_icons_menu_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6581);
/* harmony import */ var _components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8027);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8921);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5637);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_15__]);
([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const AuthMenu = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header-two.tsx -> " + "./auth-menu"
        ]
    },
    ssr: false
});
const CartButton = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header-two.tsx -> " + "@components/cart/cart-button"
        ]
    },
    ssr: false
});
const { site_header  } = _settings_site_settings__WEBPACK_IMPORTED_MODULE_4__/* .siteSettings */ .U;
const Header = ()=>{
    const { openSidebar , isAuthorized , displayMobileSearch  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_13__/* .useModalAction */ .SO)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    const siteHeaderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,_utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_7__/* .useActiveScroll */ .l)(siteHeaderRef);
    function handleLogin() {
        openModal("LOGIN_VIEW");
    }
    function handleMobileMenu() {
        return openSidebar();
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        id: "siteHeader",
        ref: siteHeaderRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("header-one w-full h-16 lg:h-20 z-30 sticky top-0", displayMobileSearch && "active-mobile-search"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "z-20 w-full h-16 transition duration-200 ease-in-out innerSticky body-font bg-brand-light lg:h-20",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    className: "top-bar-search lg:max-w-[600px] absolute z-30 px-4 md:px-6 top-1"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    className: "flex items-center justify-between w-full h-full",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex shrink-0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    "aria-label": "Menu",
                                    className: "flex-col items-center justify-center hidden outline-none menuBtn ltr:mr-5 rtl:ml-5 lg:flex xl:hidden shrink-0 focus:outline-none",
                                    onClick: handleMobileMenu,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_menu_icon__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    className: "-mt-1"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            data: site_header.menu,
                            className: "hidden xl:flex md:ltr:pl-6 md:rtl:pr-6 xl:ltr:pl-10 xl:rtl:pr-10"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex shrink-0 -mx-2.5 xl:-mx-3.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {
                                    className: "hidden lg:flex xl:mx-3.5 mx-2.5"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "items-center hidden lg:flex shrink-0 xl:mx-3.5 mx-2.5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            className: "text-brand-dark text-opacity-40"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                                            isAuthorized: isAuthorized,
                                            href: _utils_routes__WEBPACK_IMPORTED_MODULE_5__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                                            btnProps: {
                                                children: t("text-sign-in"),
                                                onClick: handleLogin
                                            },
                                            children: t("text-account")
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4063:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_header_header_two__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5503);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8168);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1858);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_header_header_two__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layout_header_header_two__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function Layout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col min-h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_two__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "relative flex-grow",
                style: {
                    WebkitOverflowScrolling: "touch"
                },
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9400:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6337);
/* harmony import */ var _components_layout_layout_two__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4063);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9146);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_common_download_apps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1694);
/* harmony import */ var _components_common_category_grid_list_block__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9519);
/* harmony import */ var _components_bundle_bundle_grid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2440);
/* harmony import */ var _framework_static_banner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4808);
/* harmony import */ var _components_common_collection_grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7298);
/* harmony import */ var _components_hero_hero_banner_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8156);
/* harmony import */ var _components_product_feeds_best_scholastics__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7182);
/* harmony import */ var _components_product_featured_scholastic__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3840);
/* harmony import */ var _framework_static_bundle__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9974);
/* harmony import */ var _components_seo_seo__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9183);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9717);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_query_hydration__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4758);
/* harmony import */ var _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4937);
/* harmony import */ var _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9092);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__, _components_layout_layout_two__WEBPACK_IMPORTED_MODULE_2__, _components_common_category_grid_list_block__WEBPACK_IMPORTED_MODULE_6__, _components_bundle_bundle_grid__WEBPACK_IMPORTED_MODULE_7__, _components_common_collection_grid__WEBPACK_IMPORTED_MODULE_9__, _components_product_feeds_best_scholastics__WEBPACK_IMPORTED_MODULE_11__, _components_product_featured_scholastic__WEBPACK_IMPORTED_MODULE_12__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_18__, _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_19__]);
([_components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__, _components_layout_layout_two__WEBPACK_IMPORTED_MODULE_2__, _components_common_category_grid_list_block__WEBPACK_IMPORTED_MODULE_6__, _components_bundle_bundle_grid__WEBPACK_IMPORTED_MODULE_7__, _components_common_collection_grid__WEBPACK_IMPORTED_MODULE_9__, _components_product_feeds_best_scholastics__WEBPACK_IMPORTED_MODULE_11__, _components_product_featured_scholastic__WEBPACK_IMPORTED_MODULE_12__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_18__, _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















function Home() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo_seo__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                title: "Standard",
                description: "Fastest E-commerce template built with React, NextJS, TypeScript, React-Query and Tailwind CSS.",
                path: "standard"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_hero_hero_banner_card__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                banner: _framework_static_banner__WEBPACK_IMPORTED_MODULE_8__/* .homeThreeHeroBanner */ .w1,
                className: "min-h-[400px] md:min-h-[460px] lg:min-h-[500px] xl:min-h-[550px] 2xl:min-h-[650px] py-20 py:pt-24 mb-5"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_bundle_bundle_grid__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        data: _framework_static_bundle__WEBPACK_IMPORTED_MODULE_13__/* .bundleDataTwo */ .b,
                        className: "mb-12 lg:mb-14 xl:mb-16 2xl:mb-20"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_category_grid_list_block__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_feeds_best_scholastics__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_banner_grid__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        data: _framework_static_banner__WEBPACK_IMPORTED_MODULE_8__/* .bannerGridThree */ .u$,
                        className: "mb-12 lg:mb-14 xl:mb-16 2xl:mb-20"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_featured_scholastic__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_collection_grid__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                headingPosition: "center",
                className: "mb-12 pb-1 lg:pb-0 lg:mb-14 xl:mb-16 2xl:pt-4"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_download_apps__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    });
}
Home.Layout = _components_layout_layout_two__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
Home.Layout = _components_layout_layout_two__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
const getStaticProps = async ({ locale  })=>{
    const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_15__.QueryClient();
    await queryClient.prefetchQuery([
        _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_17__/* .API_ENDPOINTS.CATEGORIES */ .P.CATEGORIES,
        {
            limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_20__/* .LIMITS.CATEGORIES_LIMITS */ .b.CATEGORIES_LIMITS
        }
    ], _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_18__/* .fetchCategories */ .p);
    await queryClient.prefetchQuery([
        _framework_utils_api_endpoints__WEBPACK_IMPORTED_MODULE_17__/* .API_ENDPOINTS.POPULAR_PRODUCTS */ .P.POPULAR_PRODUCTS,
        {
            limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_20__/* .LIMITS.POPULAR_PRODUCTS_LIMITS */ .b.POPULAR_PRODUCTS_LIMITS
        }
    ], _framework_product_get_all_popular_products__WEBPACK_IMPORTED_MODULE_19__/* .fetchPopularProducts */ .R);
    return {
        props: {
            dehydratedState: JSON.parse(JSON.stringify((0,react_query_hydration__WEBPACK_IMPORTED_MODULE_16__.dehydrate)(queryClient))),
            ...await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_4__.serverSideTranslations)(locale, [
                "common",
                "forms",
                "menu",
                "footer", 
            ])
        },
        revalidate: 60
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 153:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 5307:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8782:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 4449:
/***/ ((module) => {

module.exports = require("react-countdown");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 1175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9717:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 3094:
/***/ ((module) => {

module.exports = require("react-scroll");

/***/ }),

/***/ 7139:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 9137:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5675,676,1664,5152,5225,8448,7310,5437,8965,7571,9627,1694,4758,4109,2890,6861,7607,2857,5371,6003,3040,9390,6396,6337], () => (__webpack_exec__(9400)));
module.exports = __webpack_exports__;

})();