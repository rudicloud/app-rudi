"use strict";
exports.id = 1129;
exports.ids = [1129];
exports.modules = {

/***/ 1129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ counter)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/components/icons/minus-icon.tsx

const MinusIcon = ({ color ="currentColor" , width ="12" , height ="2" , opacity ="0.8" ,  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: "transition-all",
        width: width,
        height: height,
        viewBox: "0 0 22 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
            opacity: opacity,
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M3.15109 11.8438L10.174 11.8439L11.8264 11.8438L18.8493 11.8439C19.0772 11.8439 19.284 11.7515 19.4335 11.602C19.5831 11.4524 19.6755 11.2455 19.6754 11.0177C19.6755 10.5608 19.3062 10.1915 18.8493 10.1916L11.8264 10.1915L10.1741 10.1915L3.15109 10.1915C2.69427 10.1915 2.32496 10.5608 2.32496 11.0177C2.32486 11.4746 2.69416 11.8439 3.15109 11.8438Z",
                fill: color,
                stroke: color,
                strokeWidth: "0.5"
            })
        })
    });
};
/* harmony default export */ const minus_icon = (MinusIcon);

;// CONCATENATED MODULE: ./src/components/icons/plus-icon.tsx

const PlusIcon = ({ color ="currentColor" , width ="22" , height ="22" , opacity ="0.8" ,  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: height,
        height: width,
        viewBox: "0 0 22 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
            opacity: opacity,
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M10.174 11.8439L3.15109 11.8438C2.69416 11.8439 2.32486 11.4746 2.32496 11.0177C2.32496 10.5608 2.69427 10.1915 3.15109 10.1915L10.1741 10.1915L10.174 3.16858C10.1741 2.71165 10.5433 2.34245 11.0002 2.34245C11.4571 2.34234 11.8264 2.71165 11.8263 3.16858L11.8264 10.1915L18.8493 10.1916C19.3062 10.1915 19.6755 10.5608 19.6754 11.0177C19.6755 11.2455 19.5831 11.4524 19.4335 11.602C19.284 11.7515 19.0772 11.8439 18.8493 11.8439L11.8264 11.8438L11.8264 18.8668C11.8264 19.0947 11.734 19.3015 11.5845 19.451C11.4349 19.6006 11.2281 19.6929 11.0002 19.6929C10.5433 19.693 10.174 19.3237 10.1741 18.8668L10.174 11.8439Z",
                fill: color,
                stroke: color,
                strokeWidth: "0.5"
            })
        })
    });
};
/* harmony default export */ const plus_icon = (PlusIcon);

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
;// CONCATENATED MODULE: ./src/components/ui/counter.tsx





const Counter = ({ value , variant ="mercury" , onDecrement , onIncrement , className , disabled ,  })=>{
    const size = variant === "single" ? "22" : "14";
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()("flex items-center justify-between rounded overflow-hidden shrink-0", {
            "h-9 md:h-10 bg-brand-light shadow-counter rounded-3xl": variant === "mercury",
            "h-11 md:h-14 bg-[#f3f5f9]": variant === "single",
            "inline-flex": variant === "cart",
            "bg-brand rounded-[4px] z-1 mt-[10px]": variant === "venus"
        }, className),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                onClick: onDecrement,
                className: external_classnames_default()("flex items-center justify-center shrink-0 h-full transition-all ease-in-out duration-300 focus:outline-none focus-visible:outline-none", {
                    "w-8 md:w-12 h-8 rounded-2xl text-heading hover:bg-fill-four ltr:ml-1 rtl:mr-1": variant === "mercury",
                    "w-10 h-10 rounded-full transform scale-80 lg:scale-100 text-brand-dark hover:bg-fill-four ltr:ml-auto rtl:mr-auto": variant === "single",
                    "w-6 h-6 border border-border-three hover:bg-brand text-brand-muted hover:border-brand rounded-full hover:text-brand-light": variant === "cart",
                    "w-10 h-10 cursor-pointer rounded-tl-[4px] rounded-bl-[4px] transition-all bg-black/10 text-white": variant === "venus"
                }),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "sr-only",
                        children: t("button-minus")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(minus_icon, {
                        width: size,
                        height: size,
                        opacity: "1"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: external_classnames_default()("font-semibold text-brand-dark flex items-center justify-center h-full transition-colors duration-250 ease-in-out cursor-default shrink-0", {
                    "text-sm md:text-base w-6 md:w-8": variant === "mercury",
                    "text-base md:text-[17px] w-12 md:w-20 xl:w-28": variant === "single",
                    "text-15px w-9": variant === "cart",
                    "self-center text-sm sm:text-base text-white font-semibold": variant === "venus"
                }),
                children: value
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                onClick: onIncrement,
                disabled: disabled,
                className: external_classnames_default()("group flex items-center justify-center h-full shrink-0 transition-all ease-in-out duration-300 focus:outline-none focus-visible:outline-none", {
                    "w-8 md:w-12 h-8 rounded-2xl text-heading hover:bg-fill-four ltr:mr-1 rtl:ml-1": variant === "mercury",
                    "w-10 h-10 rounded-full scale-80 lg:scale-100 text-heading hover:bg-fill-four ltr:mr-auto rtl:ml-auto": variant === "single",
                    "w-6 h-6 border text-brand-muted border-border-three hover:bg-brand hover:border-brand rounded-full hover:text-brand-light": variant === "cart",
                    "w-10 h-10 cursor-pointer rounded-tl-[4px] rounded-bl-[4px] transition-all bg-black/10 text-white": variant === "venus"
                }),
                title: disabled ? "Out Of Stock" : "",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "sr-only",
                        children: t("button-plus")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(plus_icon, {
                        width: size,
                        height: size,
                        opacity: "1"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const counter = (Counter);


/***/ })

};
;