"use strict";
exports.id = 7607;
exports.ids = [7607];
exports.modules = {

/***/ 7607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9627);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8921);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6740);
/* harmony import */ var _components_icons_eye_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3758);
/* harmony import */ var _contexts_cart_cart_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5495);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_8__);







// import { AddToCart } from '@components/product/add-to-cart';


const AddToCart = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\product\\product-cards\\product-card-alpine.tsx -> " + "@components/product/add-to-cart"
        ]
    },
    ssr: false
});
function RenderPopupOrAddToCart({ props  }) {
    let { data  } = props;
    // console.log(variant);
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("common");
    const { id , quantity , product_type  } = data ?? {};
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_3__/* .useModalAction */ .SO)();
    const { isInCart , isInStock  } = (0,_contexts_cart_cart_context__WEBPACK_IMPORTED_MODULE_6__/* .useCart */ .jD)();
    const iconSize = width > 1024 ? "19" : "17";
    const outOfStock = isInCart(id) && !isInStock(id);
    function handlePopupView() {
        openModal("PRODUCT_VIEW", data);
    }
    if (Number(quantity) < 1 || outOfStock) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "text-[11px] md:text-xs font-bold text-brand-light uppercase inline-block bg-brand-danger rounded-full px-2.5 pt-1 pb-[3px] mx-0.5 sm:mx-1",
            children: t("text-out-stock")
        });
    }
    if (product_type === "variable") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: "inline-flex items-center justify-center w-8 h-8 text-4xl rounded-full bg-brand lg:w-10 lg:h-10 text-brand-light focus:outline-none focus-visible:outline-none",
            "aria-label": "Count Button",
            onClick: handlePopupView,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_eye_icon__WEBPACK_IMPORTED_MODULE_5__/* .Eye */ .b, {
                width: iconSize,
                height: iconSize,
                opacity: "1"
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddToCart, {
        data: data,
        variant: "mercury"
    });
}
const ProductCardAlpine = ({ product , className  })=>{
    const { price , name , unit , image_original  } = product ?? {};
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_3__/* .useModalAction */ .SO)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)("common");
    const { basePrice , discount  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP)({
        amount: (product === null || product === void 0 ? void 0 : product.sale_price) ? product === null || product === void 0 ? void 0 : product.sale_price : product === null || product === void 0 ? void 0 : product.price,
        baseAmount: product === null || product === void 0 ? void 0 : product.price,
        currencyCode: "Ugx"
    });
    function handlePopupView() {
        openModal("PRODUCT_VIEW", product);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex flex-col group overflow-hidden rounded-md cursor-pointer transition-all duration-300 shadow-card hover:shadow-cardHover relative h-full", className),
        onClick: handlePopupView,
        title: name,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative shrink-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex overflow-hidden max-w-[230px] mx-auto transition duration-200 ease-in-out transform group-hover:scale-105 relative",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: `${image_original}`,
                            alt: name || "Product Image",
                            width: 230,
                            height: 200,
                            quality: 100,
                            className: "object-cover bg-fill-thumbnail"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full h-full absolute top-0 pt-2.5 md:pt-3.5 px-3 md:px-4 lg:px-[18px] z-10 -mx-0.5 sm:-mx-1",
                        children: [
                            discount && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-[11px] md:text-xs font-bold text-brand-light uppercase inline-block bg-brand rounded-full px-2.5 pt-1 pb-[3px] mx-0.5 sm:mx-1",
                                children: t("text-on-sale")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `block product-count-button-position`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RenderPopupOrAddToCart, {
                                    props: {
                                        data: product
                                    }
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col px-3 md:px-4 lg:px-[18px] pb-5 lg:pb-6 lg:pt-1.5 h-full",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-1 lg:mb-1.5 -mx-1",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "inline-block mx-1 text-sm font-semibold sm:text-15px lg:text-base text-brand-dark",
                                children: [
                                    price,
                                    "/= Ugx"
                                ]
                            }),
                            basePrice && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("del", {
                                className: "mx-1 text-sm text-brand-dark text-opacity-70",
                                children: basePrice
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-brand-dark text-13px sm:text-sm lg:text-15px leading-5 sm:leading-6 mb-1.5",
                        children: name
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-auto text-13px sm:text-sm",
                        children: unit
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCardAlpine);


/***/ })

};
;