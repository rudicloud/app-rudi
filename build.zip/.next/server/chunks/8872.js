"use strict";
exports.id = 8872;
exports.ids = [8872];
exports.modules = {

/***/ 5764:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ko": () => (/* reexport */ product_placeholder)
});

// UNUSED EXPORTS: categoryPlaceholder, collectionPlaceholder, productPlaceholder, searchProductPlaceholder

;// CONCATENATED MODULE: ./src/assets/placeholders/product.png
/* harmony default export */ const product = ({"src":"/_next/static/media/product.a24fd757.png","height":200,"width":230,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAElBMVEXv7/Hh4eHj4+Po6OqKiZeysrtt0swnAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAKElEQVR4nC2JgQkAMAyDNOn+f3mMLiAKwT80G1lL5rDXBBsRKJVCHxcJLQBN7McwZAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/assets/placeholders/product-placeholder.png
/* harmony default export */ const product_placeholder = ({"src":"/_next/static/media/product-placeholder.e73a22ea.png","height":590,"width":650,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAD1BMVEXh4eLu7vHn5+iIh5W0s7zen2rpAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAJElEQVR4nGWIMQ4AMAiE4PT/b24a4yQLBLhkXe1U4Vw1BvKteQMMACbwvJB9AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/assets/placeholders/search-product.png
/* harmony default export */ const search_product = ({"src":"/_next/static/media/search-product.4cb5508d.png","height":50,"width":50,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAFVBMVEXi4uLv7/Lq6uvZ2dvBwMmenaloZ3kCbFFnAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAJ0lEQVR4nGNgwAOYmaEMNhYmiAArIxMDmMnIyMjEyMTAwMTIyATCAASxADSL6FR2AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/assets/placeholders/category.png
/* harmony default export */ const category = ({"src":"/_next/static/media/category.36411506.png","height":178,"width":178,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAGFBMVEXi4uLw8PLo6Orr6+3d3d24uMGWlaJ3dYZpVcZuAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAKUlEQVR4nH3GwQ0AIAzDwDgpsP/GCNR3/fFJU9U/K5+1HfkJYiIZHPAFBcYAQTbFajQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/assets/placeholders/collection.svg
/* harmony default export */ const collection = ({"src":"/_next/static/media/collection.d7e2b65d.svg","height":574,"width":574});
;// CONCATENATED MODULE: ./src/assets/placeholders/index.tsx







/***/ }),

/***/ 4904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const CartIcon = ({ color ="currentColor" , width =22 , height =22 , className ="" ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: width,
        height: height,
        viewBox: "0 0 22 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                clipPath: "url(#clip0)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M19.7999 19.0172L18.5402 4.8319C18.5132 4.51697 18.2478 4.27853 17.9374 4.27853H15.3459C15.31 1.91207 13.3754 0 10.9999 0C8.62447 0 6.68991 1.91207 6.65392 4.27853H4.06251C3.74758 4.27853 3.48664 4.51697 3.45965 4.8319L2.19993 19.0172C2.19993 19.0352 2.19543 19.0532 2.19543 19.0712C2.19543 20.6863 3.6756 22 5.49768 22H16.5022C18.3243 22 19.8044 20.6863 19.8044 19.0712C19.8044 19.0532 19.8044 19.0352 19.7999 19.0172ZM10.9999 1.21472C12.705 1.21472 14.0952 2.58241 14.1312 4.27853H7.86864C7.90464 2.58241 9.29482 1.21472 10.9999 1.21472ZM16.5022 20.7853H5.49768C4.35494 20.7853 3.42815 20.0294 3.41016 19.0982L4.61588 5.49775H6.64942V7.34233C6.64942 7.67975 6.91936 7.94969 7.25678 7.94969C7.59421 7.94969 7.86415 7.67975 7.86415 7.34233V5.49775H14.1312V7.34233C14.1312 7.67975 14.4012 7.94969 14.7386 7.94969C15.076 7.94969 15.3459 7.67975 15.3459 7.34233V5.49775H17.3795L18.5897 19.0982C18.5717 20.0294 17.6404 20.7853 16.5022 20.7853Z",
                    fill: color,
                    stroke: color,
                    strokeWidth: "0.1"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                    id: "clip0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        width: "22",
                        height: "22",
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartIcon);


/***/ }),

/***/ 4475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const LabelIcon = ({ color ="#999999" , width ="20" , height ="20" , className ="" ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: width,
        height: height,
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M17.125 1H12.3677C11.4662 1 10.6188 1.351 9.98123 1.98849L1.63974 10.33C1.22725 10.7425 1 11.2908 1 11.8765C1 12.4593 1.22725 13.0075 1.63974 13.42L6.58 18.3603C6.99249 18.7728 7.54075 19 8.12649 19C8.70924 19 9.2575 18.7728 9.66999 18.3603L18.0115 10.0188C18.649 9.38125 19 8.53374 19 7.63226V2.87499C19 1.8415 18.1585 1 17.125 1ZM18.25 7.63226C18.25 8.33352 17.977 8.99277 17.482 9.48777L9.13976 17.83C8.6005 18.3693 7.65476 18.373 7.111 17.83L2.17 12.889C1.89926 12.619 1.74999 12.259 1.74999 11.8735C1.74999 11.491 1.89923 11.131 2.17 10.8603L10.5115 2.51875C11.008 2.02301 11.6665 1.74999 12.3677 1.74999H17.125C17.7452 1.74999 18.25 2.25473 18.25 2.87499V7.63226H18.25Z",
                fill: color,
                stroke: color,
                strokeWidth: "0.5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M14.8749 3.25C13.8414 3.25 12.9999 4.0915 12.9999 5.12499C12.9999 6.15848 13.8414 6.99998 14.8749 6.99998C15.9084 6.99998 16.7499 6.15851 16.7499 5.12499C16.7499 4.0915 15.9084 3.25 14.8749 3.25ZM14.8749 6.24999C14.2546 6.24999 13.7499 5.74525 13.7499 5.12499C13.7499 4.50473 14.2546 3.99999 14.8749 3.99999C15.4952 3.99999 15.9999 4.50473 15.9999 5.12499C15.9999 5.74525 15.4951 6.24999 14.8749 6.24999Z",
                fill: color,
                stroke: color,
                strokeWidth: "0.5"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LabelIcon);


/***/ }),

/***/ 5923:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


const ProductAttributes = ({ className ="mb-2 pt-0.5" , variations , attributes , setAttributes ,  })=>{
    if (!variations) return null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: Object.keys(variations).map((variationName, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(className),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                        className: "mb-3 font-normal capitalize text-15px text-brand-dark text-opacity-70",
                        children: [
                            variationName.split("-").join(" "),
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "flex flex-wrap ltr:-mr-2 rtl:-ml-2",
                        children: variations[variationName].map((attribute)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("cursor-pointer rounded border h-9 md:h-10 p-1 mb-2 md:mb-3 ltr:mr-2 rtl:ml-2 flex justify-center items-center font-medium text-sm md:text-15px text-brand-dark transition duration-200 ease-in-out hover:text-brand hover:border-brand px-3", {
                                    "border-brand text-brand": attributes[variationName] === attribute.value
                                }),
                                onClick: ()=>setAttributes((prev)=>({
                                            ...prev,
                                            [variationName]: attribute.value
                                        })),
                                children: attribute.value
                            }, attribute.id))
                    })
                ]
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductAttributes);


/***/ }),

/***/ 7906:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6557);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3879);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_placeholders__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5764);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2687);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__]);
_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









// product gallery breakpoints
const galleryCarouselBreakpoints = {
    "0": {
        slidesPerView: 4
    }
};
const swiperParams = {
    slidesPerView: 1,
    spaceBetween: 0
};
const ThumbnailCarousel = ({ gallery , thumbnailClassName ="xl:w-[480px] 2xl:w-[650px]" , galleryClassName ="xl:w-28 2xl:w-[130px]" ,  })=>{
    const { 0: thumbsSwiper , 1: setThumbsSwiper  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const prevRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const nextRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_8__/* .getDirection */ .M)(locale);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full xl:flex xl:flex-row-reverse",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("w-full xl:ltr:ml-5 xl:rtl:mr-5 mb-2.5 md:mb-3 border border-border-base overflow-hidden rounded-md relative", thumbnailClassName),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__/* .Swiper */ .tq, {
                        id: "productGallery",
                        thumbs: {
                            swiper: thumbsSwiper
                        },
                        modules: [
                            _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__/* .Navigation */ .W_,
                            _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__/* .Thumbs */ .o3
                        ],
                        navigation: {
                            prevEl: prevRef.current,
                            nextEl: nextRef.current
                        },
                        ...swiperParams,
                        children: gallery === null || gallery === void 0 ? void 0 : gallery.map((item)=>{
                            /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__/* .SwiperSlide */ .o5, {
                                className: "flex items-center justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    src: (item === null || item === void 0 ? void 0 : item.original) ?? _assets_placeholders__WEBPACK_IMPORTED_MODULE_5__/* .productGalleryPlaceholder */ .ko,
                                    alt: `Product gallery ${item.id}`,
                                    width: 650,
                                    height: 590,
                                    className: "rounded-lg"
                                })
                            }, `product-gallery-${item.id}`);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between w-full absolute top-2/4 z-10 px-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: prevRef,
                                className: "flex items-center justify-center text-base transition duration-300 transform -translate-y-1/2 rounded-full cursor-pointer w-7 h-7 md:w-8 md:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 lg:text-lg xl:text-xl bg-brand-light hover:bg-brand hover:text-brand-light focus:outline-none shadow-navigation",
                                children: dir === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_7__.IoIosArrowForward, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_7__.IoIosArrowBack, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: nextRef,
                                className: "flex items-center justify-center text-base transition duration-300 transform -translate-y-1/2 rounded-full cursor-pointer w-7 h-7 md:w-8 md:h-8 lg:w-9 lg:h-9 xl:w-10 xl:h-10 lg:text-lg xl:text-xl bg-brand-light hover:bg-brand hover:text-brand-light focus:outline-none shadow-navigation",
                                children: dir === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_7__.IoIosArrowBack, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_7__.IoIosArrowForward, {})
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `shrink-0 ${galleryClassName}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__/* .Swiper */ .tq, {
                    id: "productGalleryThumbs",
                    onSwiper: setThumbsSwiper,
                    spaceBetween: 0,
                    watchSlidesProgress: true,
                    freeMode: true,
                    observer: true,
                    observeParents: true,
                    breakpoints: galleryCarouselBreakpoints,
                    children: gallery === null || gallery === void 0 ? void 0 : gallery.map((item)=>{
                        /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_1__/* .SwiperSlide */ .o5, {
                            className: "flex items-center justify-center overflow-hidden transition border rounded cursor-pointer border-border-base hover:opacity-75",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                src: (item === null || item === void 0 ? void 0 : item.thumbnail) ?? _assets_placeholders__WEBPACK_IMPORTED_MODULE_5__/* .productGalleryPlaceholder */ .ko,
                                alt: `Product thumb gallery ${item.id}`,
                                width: 170,
                                height: 170
                            })
                        }, `product-thumb-gallery-${item.id}`);
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ThumbnailCarousel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8139);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8921);





const TagLabel = ({ className , data  })=>{
    const { name  } = data;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { closeModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_4__/* .useModalAction */ .SO)();
    function changeTags() {
        closeModal();
        router.push(_utils_routes__WEBPACK_IMPORTED_MODULE_2__/* .ROUTES.SEARCH */ .Z.SEARCH);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("font-medium text-13px md:text-sm rounded hover:bg-fill-four block border border-sink-base px-2 py-1 transition", className),
        role: "button",
        onClick: changeTags,
        children: name
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TagLabel);


/***/ }),

/***/ 2349:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ getVariations)
/* harmony export */ });
/* harmony import */ var lodash_groupBy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8492);
/* harmony import */ var lodash_groupBy__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_groupBy__WEBPACK_IMPORTED_MODULE_0__);

function getVariations(variations) {
    if (!variations) return {};
    return lodash_groupBy__WEBPACK_IMPORTED_MODULE_0___default()(variations, "attribute.slug");
}


/***/ }),

/***/ 9792:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ generateCartItem)
/* harmony export */ });
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0__);

function generateCartItem(item, variation) {
    const { id , name , slug , image_original , price , sale_price , quantity , unit  } = item;
    if (!lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0___default()(variation)) {
        return {
            id: `${id}.${variation.id}`,
            productId: id,
            name: `${name} - ${variation.title}`,
            slug,
            unit,
            stock: variation.quantity,
            price: variation.sale_price ? variation.sale_price : variation.price,
            image_original: image_original,
            variationId: variation.id
        };
    }
    return {
        id,
        name,
        slug,
        unit,
        image_original: image_original,
        stock: quantity,
        price: sale_price ? sale_price : price
    };
}


/***/ })

};
;