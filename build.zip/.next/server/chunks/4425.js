"use strict";
exports.id = 4425;
exports.ids = [4425];
exports.modules = {

/***/ 4425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mh": () => (/* binding */ TotalPrice),
/* harmony export */   "eP": () => (/* binding */ DeliveryFee),
/* harmony export */   "ld": () => (/* binding */ SubTotalPrice),
/* harmony export */   "oP": () => (/* binding */ DiscountPrice)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9627);
/* harmony import */ var _contexts_cart_cart_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2080);



const TotalPrice = ({ items  })=>{
    const { price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)({
        amount: Math.round((0,_contexts_cart_cart_utils__WEBPACK_IMPORTED_MODULE_2__/* .calculateTotal */ .tf)(items === null || items === void 0 ? void 0 : items.products) + (items === null || items === void 0 ? void 0 : items.delivery_fee) - (items === null || items === void 0 ? void 0 : items.discount)),
        currencyCode: "USD"
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: "total_price",
        children: price
    });
};
const DiscountPrice = (discount)=>{
    const { price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)({
        amount: discount === null || discount === void 0 ? void 0 : discount.discount,
        currencyCode: "USD"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            "-",
            price
        ]
    });
};
const DeliveryFee = (delivery)=>{
    const { price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)({
        amount: delivery === null || delivery === void 0 ? void 0 : delivery.delivery,
        currencyCode: "USD"
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: price
    });
};
const SubTotalPrice = ({ items  })=>{
    const { price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP)({
        amount: (0,_contexts_cart_cart_utils__WEBPACK_IMPORTED_MODULE_2__/* .calculateTotal */ .tf)(items),
        currencyCode: "USD"
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: price
    });
};


/***/ })

};
;