"use strict";
exports.id = 5739;
exports.ids = [5739];
exports.modules = {

/***/ 5739:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5225);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4685);
/* harmony import */ var _components_ui_form_text_area__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4930);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9137);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8921);
/* harmony import */ var _components_ui_close_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9341);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_map__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5595);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const AddAddressForm = ()=>{
    var ref, ref1, ref2, ref3, ref4, ref5;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const { data  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_5__/* .useModalState */ .X9)();
    const { closeModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_5__/* .useModalAction */ .SO)();
    function onSubmit(values, e) {
        console.log(values, "Add Address");
    }
    const { register , handleSubmit , setValue , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            title: data || (data === null || data === void 0 ? void 0 : data.title) ? data === null || data === void 0 ? void 0 : data.title : "",
            default: data || (data === null || data === void 0 ? void 0 : data.default) ? data === null || data === void 0 ? void 0 : data.default : "",
            formatted_address: data || (data === null || data === void 0 ? void 0 : (ref = data.address) === null || ref === void 0 ? void 0 : ref.formatted_address) ? data === null || data === void 0 ? void 0 : (ref1 = data.address) === null || ref1 === void 0 ? void 0 : ref1.formatted_address : ""
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full md:w-[600px] lg:w-[900px] xl:w-[1000px] mx-auto p-5 sm:p-8 bg-brand-light rounded-md",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_close_button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                onClick: closeModal
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                variant: "title",
                className: "mb-8 -mt-1.5",
                children: t("common:text-add-delivery-address")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleSubmit(onSubmit),
                noValidate: true,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "solid",
                            label: "Address Title",
                            ...register("title", {
                                required: "Title Required"
                            }),
                            error: (ref2 = errors.title) === null || ref2 === void 0 ? void 0 : ref2.message
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-1 mb-6 gap-7",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_map__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                lat: (data === null || data === void 0 ? void 0 : (ref3 = data.address) === null || ref3 === void 0 ? void 0 : ref3.lat) || 1.295831,
                                lng: (data === null || data === void 0 ? void 0 : (ref4 = data.address) === null || ref4 === void 0 ? void 0 : ref4.lng) || 103.76261,
                                height: "420px",
                                zoom: 15,
                                showInfoWindow: false,
                                mapCurrentPosition: (value)=>setValue("formatted_address", value)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_text_area__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                label: "Address",
                                ...register("formatted_address", {
                                    required: "forms:address-required"
                                }),
                                error: (ref5 = errors.formatted_address) === null || ref5 === void 0 ? void 0 : ref5.message,
                                className: "text-brand-dark",
                                variant: "solid"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-end w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            className: "h-11 md:h-12 mt-1.5",
                            type: "submit",
                            children: t("common:text-save-address")
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddAddressForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);



const CloseButton = ({ className , onClick  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: onClick,
        "aria-label": "Close Button",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("fixed z-10 inline-flex items-center justify-center w-8 h-8 lg:w-9 lg:h-9 transition duration-200 text-brand-dark text-opacity-50 focus:outline-none  hover:text-opacity-100 top-0.5 md:top-2 lg:top-7 xl:top-10 ltr:right-0.5 rtl:left-0.5 md:ltr:right-2 md:rtl:left-0 lg:ltr:right-7 lg:rtl:left-7 xl:ltr:right-10 xl:rtl:left-10 bg-brand-light lg:bg-transparent rounded-full", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_1__.IoClose, {
            className: "text-xl lg:text-2xl"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CloseButton);


/***/ }),

/***/ 4930:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);




const variantClasses = {
    normal: "bg-white border border-border-two focus:shadow focus:outline-none focus:border-heading",
    solid: "border border-border-two focus:bg-white focus:border-2 focus:border-brand",
    outline: "border border-gray-300 focus:border-primary"
};
const TextArea = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef((props, ref)=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const { className , label , name , placeholder , error , variant ="normal" , shadow =false , inputClassName , labelClassName , ...rest } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: className,
        children: [
            label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                htmlFor: name,
                className: `block ${labelClassName || "text-brand-dark opacity-70"} font-normal text-13px lg:text-sm leading-none mb-3 cursor-pointer`,
                children: t(label)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                id: name,
                name: name,
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("px-4 py-3 flex items-center w-full rounded appearance-none transition duration-300 ease-in-out text-brand-dark text-13px lg:text-sm focus:outline-none focus:ring-0 placeholder-[#B3B3B3]", shadow && "focus:shadow", variantClasses[variant], inputClassName),
                autoComplete: "off",
                spellCheck: "false",
                rows: 4,
                ref: ref,
                // @ts-ignore
                placeholder: t(placeholder),
                ...rest
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "my-2 text-13px text-brand-danger text-opacity-70",
                children: t(error)
            })
        ]
    });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextArea);
TextArea.displayName = "TextArea";


/***/ }),

/***/ 5595:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);



const Map = ({ lat , lng , height , zoom , showInfoWindow , mapCurrentPosition ,  })=>{
    const containerStyle = {
        width: "100%",
        height: height || "420px"
    };
    const center = {
        lat: lat || 1.295831,
        lng: lng || 103.76261
    };
    const { isLoaded  } = (0,_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.useJsApiLoader)({
        id: "google-map-script",
        googleMapsApiKey: `${"Put your google api key here"}`
    });
    const { 0: selectedMarker , 1: setSelectedMarker  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: mapPosition , 1: setMapPosition  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: infoWindowToggle , 1: setInfoWindowToggle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const onMarkerDragEnd = (e)=>{
        if (e.domEvent.type === "click") {
            setInfoWindowToggle(true);
        }
        const geocoder = new window.google.maps.Geocoder();
        const latLng = {
            lat: parseFloat(e.latLng.lat()),
            lng: parseFloat(e.latLng.lng())
        };
        geocoder.geocode({
            location: latLng
        }).then((response)=>{
            if (response.results[0]) {
                if (mapCurrentPosition !== undefined) {
                    var ref;
                    mapCurrentPosition((ref = response.results[0]) === null || ref === void 0 ? void 0 : ref.formatted_address);
                }
                setSelectedMarker(response.results[0]);
                setMapPosition(latLng);
                setInfoWindowToggle(true);
            } else {
                window.alert("No results found");
            }
        }).catch((e)=>window.alert("Geocoder failed due to: " + e));
    };
    return isLoaded ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
            mapContainerStyle: containerStyle,
            center: mapPosition || center,
            zoom: zoom || 15,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
                position: mapPosition || center,
                draggable: true,
                visible: true,
                icon: "/assets/images/pin.png",
                onDragEnd: (e)=>onMarkerDragEnd(e),
                onClick: (e)=>onMarkerDragEnd(e),
                children: showInfoWindow && infoWindowToggle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.InfoWindow, {
                    position: mapPosition || center,
                    onCloseClick: ()=>setInfoWindowToggle(false),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: selectedMarker === null || selectedMarker === void 0 ? void 0 : selectedMarker.formatted_address
                    })
                })
            })
        })
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "Loading...."
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(Map));


/***/ })

};
;