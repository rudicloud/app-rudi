"use strict";
exports.id = 6003;
exports.ids = [6003];
exports.modules = {

/***/ 6003:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9732);





const SectionHeader = ({ sectionHeading ="text-section-title" , sectionSubHeading , className ="pb-0.5 mb-5 xl:mb-6" , headingPosition ="left" ,  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(`-mt-1.5 ${className}`, {
            "text-center pb-2 lg:pb-3 xl:pb-4 3xl:pb-7": headingPosition === "center"
        }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                variant: "heading",
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
                    "3xl:text-[25px] 3xl:leading-9": headingPosition === "center"
                }),
                children: t(sectionHeading)
            }),
            sectionSubHeading && headingPosition === "center" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                variant: "medium",
                className: "pb-0.5 mt-1.5 lg:mt-2.5 xl:mt-3",
                children: t(sectionSubHeading)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionHeader);


/***/ })

};
;