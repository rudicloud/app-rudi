"use strict";
exports.id = 6396;
exports.ids = [6396];
exports.modules = {

/***/ 9519:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6003);
/* harmony import */ var _components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2558);
/* harmony import */ var _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4937);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5239);
/* harmony import */ var _components_cards_category_list_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3040);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2857);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3015);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6740);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8139);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_6__, swiper_react__WEBPACK_IMPORTED_MODULE_7__]);
([_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_6__, swiper_react__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const breakpoints = {
    "1480": {
        slidesPerView: 5
    },
    "920": {
        slidesPerView: 3
    },
    "600": {
        slidesPerView: 2
    },
    "0": {
        slidesPerView: 1
    }
};
const antiqueBreakpoints = {
    "0": {
        slidesPerView: 1
    },
    390: {
        slidesPerView: 2
    },
    768: {
        slidesPerView: 3
    },
    1024: {
        slidesPerView: 4
    },
    1280: {
        slidesPerView: 5
    },
    1440: {
        slidesPerView: 6
    },
    1780: {
        slidesPerView: 8
    }
};
const CategoryGridListBlock = ({ className ="mb-12 lg:mb-14 xl:mb-16 2xl:mb-20" , variant ,  })=>{
    var ref, ref1, ref2, ref3, ref4, ref5;
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { data , isLoading , error  } = (0,_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__/* .useCategoriesQuery */ .E)({
        limit: 16
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `${variant !== "antique" ? "pt-0.5 pb-1.5" : ""}`,
            children: [
                variant !== "antique" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    sectionHeading: "Our Schools",
                    sectionSubHeading: "Customised for your Shopping for your favourite school requirements",
                    headingPosition: "center"
                }) : "",
                variant !== "antique" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "-mt-1.5 md:-mt-2",
                    children: error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        message: error === null || error === void 0 ? void 0 : error.message
                    }) : width < 1280 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            breakpoints: breakpoints,
                            grid: {
                                rows: 3,
                                fill: "row"
                            },
                            className: "-mx-1.5 md:-mx-2",
                            prevButtonClassName: "ltr:-left-2 rtl:-right-2 md:ltr:-left-2.5 md:rtl:-right-2.5",
                            nextButtonClassName: "ltr:-right-2 rtl:-left-2 lg:ltr:-right-2.5 lg:rtl:-left-2.5",
                            children: isLoading && !data ? Array.from({
                                length: 18
                            }).map((_, idx)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_7__.SwiperSlide, {
                                    className: "p-1.5 md:p-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        uniqueKey: `category-card-${idx}`
                                    })
                                }, `category--key-${idx}`);
                            }) : data === null || data === void 0 ? void 0 : (ref = data.categories) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_7__.SwiperSlide, {
                                    className: "p-1.5 md:p-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_category_list_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        category: category,
                                        href: {
                                            pathname: _utils_routes__WEBPACK_IMPORTED_MODULE_10__/* .ROUTES.SEARCH */ .Z.SEARCH,
                                            query: {
                                                category: category.slug
                                            }
                                        },
                                        className: "rounded-md text-brand-light shadow-category"
                                    })
                                }, `category--key-${category.id}`))
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-wrap justify-center -mx-1 xl:flex",
                        children: isLoading && !data ? Array.from({
                            length: 18
                        }).map((_, idx)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-[25%] 2xl:w-[20%] 3xl:w-[16.666%] shrink-0 p-2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    uniqueKey: `category-card-${idx}`
                                })
                            }, `category--key-${idx}`);
                        }) : data === null || data === void 0 ? void 0 : (ref2 = data.categories) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.data) === null || ref3 === void 0 ? void 0 : ref3.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-[25%] 2xl:w-[20%] 3xl:w-[16.666%] shrink-0 p-2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_category_list_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    category: category,
                                    href: {
                                        pathname: _utils_routes__WEBPACK_IMPORTED_MODULE_10__/* .ROUTES.SEARCH */ .Z.SEARCH,
                                        query: {
                                            category: category.slug
                                        }
                                    },
                                    className: "rounded-md text-brand-light shadow-category"
                                })
                            }, `category--key-${category.id}`))
                    })
                }) : error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    message: error === null || error === void 0 ? void 0 : error.message
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    breakpoints: antiqueBreakpoints,
                    className: "antique-carousel-slider",
                    prevButtonClassName: "ltr:-left-2 rtl:-right-2 md:ltr:-left-2.5 md:rtl:-right-2.5",
                    nextButtonClassName: "ltr:-right-2 rtl:-left-2 lg:ltr:-right-2.5 lg:rtl:-left-2.5",
                    children: isLoading && !data ? Array.from({
                        length: 18
                    }).map((_, idx)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_7__.SwiperSlide, {
                            className: "p-1.5 md:p-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                uniqueKey: `category-card-${idx}`
                            })
                        }, `category--key-${idx}`);
                    }) : data === null || data === void 0 ? void 0 : (ref4 = data.categories) === null || ref4 === void 0 ? void 0 : (ref5 = ref4.data) === null || ref5 === void 0 ? void 0 : ref5.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_7__.SwiperSlide, {
                            className: `p-1.5 md:p-3`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_category_list_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                category: category,
                                href: {
                                    pathname: _utils_routes__WEBPACK_IMPORTED_MODULE_10__/* .ROUTES.SEARCH */ .Z.SEARCH,
                                    query: {
                                        category: category.slug
                                    }
                                },
                                className: "rounded-lg shadow-category2 bg-white",
                                variant: variant
                            })
                        }, `category--key-${category.id}`))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryGridListBlock);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9439:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9732);





const FeaturedHeader = ({ sectionHeading ="text-section-title" , sectionSubHeading , className ="pb-0.5 mb-5 xl:mb-6" , headingPosition ="left" ,  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(`-mt-1.5 ${className}`, {
            "text-center pb-2 lg:pb-3 xl:pb-4 3xl:pb-7": headingPosition === "center"
        }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                variant: "heading",
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()({
                    "3xl:text-[25px] 3xl:leading-9": headingPosition === "center"
                }),
                children: "Faatured Scholastic Materials"
            }),
            sectionSubHeading && headingPosition === "center" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                variant: "medium",
                className: "pb-0.5 mt-1.5 lg:mt-2.5 xl:mt-3",
                children: "Shop from A list of our featured products"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FeaturedHeader);


/***/ }),

/***/ 3840:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PopularProductWithBestDeals)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_product_get_all_featured_scholastics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7023);
/* harmony import */ var _components_common_featured_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9439);
/* harmony import */ var _components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7607);
/* harmony import */ var _components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9988);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4251);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5239);
/* harmony import */ var _components_product_product_cards_product_flash_sale_coral__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6559);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3094);
/* harmony import */ var react_scroll__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_scroll__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_get_all_featured_scholastics__WEBPACK_IMPORTED_MODULE_1__]);
_framework_product_get_all_featured_scholastics__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function PopularProductWithBestDeals({ className =""  }) {
    var ref;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)("common");
    const limit = _framework_utils_limits__WEBPACK_IMPORTED_MODULE_5__/* .LIMITS.POPULAR_PRODUCTS_TWO_LIMITS */ .b.POPULAR_PRODUCTS_TWO_LIMITS;
    const { data , isLoading , error  } = (0,_framework_product_get_all_featured_scholastics__WEBPACK_IMPORTED_MODULE_1__/* .useFeaturedScholasticQuery */ .E)({
        limit: limit
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `-mt-2.5 mb-12 lg:mb-14 xl:mb-16 2xl:mb-20 ${className}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_featured_header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                sectionHeading: "text-popular-product",
                sectionSubHeading: "text-fresh-grocery-items",
                headingPosition: "center"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_scroll__WEBPACK_IMPORTED_MODULE_9__.Element, {
                name: "grid",
                className: "grid-cols-7 gap-3 md:grid lg:grid-cols-5 2xl:grid-cols-7 lg:gap-5 xl:gap-7",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:sticky md:top-16 lg:top-20 md:h-[600px] lg:h-[690px] 3xl:h-auto col-span-3 lg:col-span-2 mb-3 md:mb-0",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "h-auto overflow-hidden border-2 border-yellow-200 rounded-md 3xl:h-full shadow-card",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "bg-yellow-200 text-center font-bold text-brand-dark font-manrope p-2.5 text-15px lg:text-base",
                                    children: t("text-deals-of-the-week")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_flash_sale_coral__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    product: data === null || data === void 0 ? void 0 : data[0],
                                    date: Date.now() + 4000000 * 60
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid grid-cols-2 col-span-4 gap-3 lg:col-span-3 2xl:col-span-5 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 3xl:grid-cols-5 md:gap-4 2xl:gap-5",
                        children: error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            message: error === null || error === void 0 ? void 0 : error.message,
                            className: "col-span-full"
                        }) : isLoading ? Array.from({
                            length: limit
                        }).map((_, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                uniqueKey: `popular-product-${idx}`
                            }, `popular-product-${idx}`)) : (ref = data === null || data === void 0 ? void 0 : data.slice(1, 11)) === null || ref === void 0 ? void 0 : ref.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                product: product
                            }, `popular-product-${product.id}`))
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7182:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _framework_product_get_all_best_scholastic_products__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1676);
/* harmony import */ var _products_grid_block__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8616);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_get_all_best_scholastic_products__WEBPACK_IMPORTED_MODULE_1__]);
_framework_product_get_all_best_scholastic_products__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const BestSellerScholasticFeed = ({ className , variant ,  })=>{
    const { data , isLoading , error  } = (0,_framework_product_get_all_best_scholastic_products__WEBPACK_IMPORTED_MODULE_1__/* .useBestScholasticProductsQuery */ .o)({
        limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__/* .LIMITS.BEST_SELLER_GROCERY_PRODUCTS_LIMITS */ .b.BEST_SELLER_GROCERY_PRODUCTS_LIMITS
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_products_grid_block__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        sectionHeading: "text-best-grocery-near-you",
        sectionSubHeading: "text-fresh-grocery-items",
        className: className,
        products: data,
        loading: isLoading,
        error: error === null || error === void 0 ? void 0 : error.message,
        uniqueKey: "best-sellers",
        variant: variant
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BestSellerScholasticFeed);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_flash_sale_coral)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/framework/basic-rest/product/use-price.tsx
var use_price = __webpack_require__(9627);
// EXTERNAL MODULE: ./src/components/common/modal/modal.context.tsx
var modal_context = __webpack_require__(8921);
// EXTERNAL MODULE: external "react-countdown"
var external_react_countdown_ = __webpack_require__(4449);
var external_react_countdown_default = /*#__PURE__*/__webpack_require__.n(external_react_countdown_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
;// CONCATENATED MODULE: ./src/components/ui/progress-card.tsx


const ProgressCard = ({ soldProduct =0 , totalProduct =0 , className ="" ,  })=>{
    const progressBar = 100 / totalProduct * soldProduct;
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `w-full ${className}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-full h-2.5 lg:h-3 bg-fill-three rounded-full overflow-hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "absolute h-full bg-yellow-200 bg-opacity-90 rounded-full bg-progress-striped",
                    style: {
                        width: `${Math.round(progressBar)}%`
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between items-center mt-2.5 md:mt-3 xl:mt-2.5 2xl:mt-3.5",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-brand-dark text-opacity-60 text-13px sm:text-sm lg:text-15px leading-6 md:leading-7",
                        children: [
                            t("text-sold"),
                            " :\xa0",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: "text-brand-dark font-medium",
                                children: [
                                    soldProduct,
                                    " ",
                                    t("text-items")
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-brand-dark text-opacity-60 text-13px sm:text-sm lg:text-15px leading-6 md:leading-7",
                        children: [
                            t("text-available"),
                            " :\xa0",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: "text-brand-dark font-medium",
                                children: [
                                    totalProduct - soldProduct,
                                    " ",
                                    t("text-items")
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const progress_card = (ProgressCard);

// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
;// CONCATENATED MODULE: ./src/components/product/product-cards/product-flash-sale-coral.tsx







const renderer = ({ days , hours , minutes , seconds , completed  })=>{
    if (completed) {
        return null;
    } else {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
            className: "flex items-center justify-center text-base xl:text-lg text-brand-dark text-opacity-50 font-semibold -mx-2.5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "flex items-center justify-center min-w-[40px] md:min-w-[50px] min-h-[36px] md:min-h-[40px] bg-fill-three text-brand-dark rounded p-1 mx-1 md:mx-1.5 lg:mx-2.5",
                    children: (0,external_react_countdown_.zeroPad)(days)
                }),
                ":",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "flex items-center justify-center min-w-[40px] md:min-w-[50px] min-h-[36px] md:min-h-[40px] bg-fill-three text-brand-dark rounded p-1 mx-1 md:mx-1.5 lg:mx-2.5",
                    children: (0,external_react_countdown_.zeroPad)(hours)
                }),
                ":",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "flex items-center justify-center min-w-[40px] md:min-w-[50px] min-h-[36px] md:min-h-[40px] bg-fill-three text-brand-dark rounded p-1 mx-1 md:mx-1.5 lg:mx-2.5",
                    children: (0,external_react_countdown_.zeroPad)(minutes)
                }),
                ":",
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "flex items-center justify-center min-w-[40px] md:min-w-[50px] min-h-[36px] md:min-h-[40px] bg-fill-three text-brand-dark rounded p-1 mx-1 md:mx-1.5 lg:mx-2.5",
                    children: (0,external_react_countdown_.zeroPad)(seconds)
                })
            ]
        });
    }
};
const ProductFlashSaleCoral = ({ product , className , date ,  })=>{
    const { price , name , image_original , quantity , sold , product_type  } = product ?? {};
    const { openModal  } = (0,modal_context/* useModalAction */.SO)();
    const { t  } = (0,external_react_i18next_.useTranslation)("common");
    const { basePrice  } = (0,use_price/* default */.ZP)({
        amount: (product === null || product === void 0 ? void 0 : product.sale_price) ? product === null || product === void 0 ? void 0 : product.sale_price : product === null || product === void 0 ? void 0 : product.price,
        baseAmount: product === null || product === void 0 ? void 0 : product.price,
        currencyCode: "Ugx"
    });
    const { price: minPrice  } = (0,use_price/* default */.ZP)({
        amount: (product === null || product === void 0 ? void 0 : product.min_price) ?? 0,
        currencyCode: "Ugx"
    });
    const { price: maxPrice  } = (0,use_price/* default */.ZP)({
        amount: (product === null || product === void 0 ? void 0 : product.max_price) ?? 0,
        currencyCode: "Ugx"
    });
    function handlePopupView() {
        openModal("PRODUCT_VIEW", product);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
        className: external_classnames_default()("flex flex-col justify-between group cursor-pointer relative px-5 lg:px-7 pt-4 lg:pt-5 pb-6 lg:pb-8", className),
        onClick: handlePopupView,
        title: name,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative shrink-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative flex justify-center mx-auto overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: image_original,
                                    alt: name || "Product Image",
                                    width: 350,
                                    height: 350,
                                    quality: 100,
                                    className: "object-cover bg-fill-thumbnail"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full h-full absolute top-0 z-10 -mx-0.5 sm:-mx-1",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-[11px] md:text-xs font-bold text-brand-light uppercase inline-block bg-[#fd5473] rounded-full px-2.5 py-[5px] pb-1 mx-0.5 sm:mx-1",
                                    children: t("text-most-popular")
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col pb-5 lg:pb-6 mb-0.5 lg:pt-3 h-full text-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "-mx-1 mb-1 lg:mb-2.5",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "inline-block mx-1 text-xl font-semibold xl:text-2xl text-brand-dark",
                                        children: [
                                            price,
                                            "/= Ugx"
                                        ]
                                    }),
                                    basePrice && /*#__PURE__*/ jsx_runtime_.jsx("del", {
                                        className: "mx-1 text-base text-opacity-50 xl:text-lg text-brand-dark",
                                        children: basePrice
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-sm leading-5 text-brand-dark lg:text-15px xl:text-base sm:leading-6",
                                children: name
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_react_countdown_default()), {
                date: date,
                intervalDelay: 1000,
                renderer: renderer
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(progress_card, {
                soldProduct: sold,
                totalProduct: quantity,
                className: "pt-8 lg:pt-10"
            })
        ]
    });
};
/* harmony default export */ const product_flash_sale_coral = (ProductFlashSaleCoral);


/***/ }),

/***/ 1676:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ useBestScholasticProductsQuery)
/* harmony export */ });
/* unused harmony export fetchBestScholasticProducts */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchBestScholasticProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    return data;
};
const useBestScholasticProductsQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchBestScholasticProducts);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7023:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ useFeaturedScholasticQuery)
/* harmony export */ });
/* unused harmony export fetchPopularProducts */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchPopularProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    return data;
};
const useFeaturedScholasticQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchPopularProducts);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ bundleDataTwo)
/* harmony export */ });
const bundleDataTwo = [
    {
        id: 1,
        slug: "nursery",
        image: "/assets/images/bundle/nursery.png",
        title: "Nursery School Requirements",
        description: "Shop for all your Kindergarten and Pre-School going kids requirements",
        bgColor: "#FFEED6"
    },
    {
        id: 2,
        slug: "primary",
        image: "/assets/images/bundle/primary.png",
        title: "Primary  School Requirements",
        description: "Shop for all your Primary  School Requirements going pupils requirements",
        bgColor: "#D9ECD2"
    },
    {
        id: 3,
        slug: "secondary",
        image: "/assets/images/bundle/secondary.png",
        title: "Secondary  School Requirements",
        description: "Shop for all your Secondary  School Requirements going Students requirements",
        bgColor: "#DBE5EF"
    }, 
];


/***/ })

};
;