"use strict";
exports.id = 7419;
exports.ids = [7419];
exports.modules = {

/***/ 7419:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SignUpForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5225);
/* harmony import */ var _components_ui_form_password_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9947);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4685);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9137);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7310);
/* harmony import */ var _framework_auth_use_signup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5179);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3879);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8921);
/* harmony import */ var _components_ui_switch__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(410);
/* harmony import */ var _components_ui_close_button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9341);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _framework_auth_use_signup__WEBPACK_IMPORTED_MODULE_7__, _components_ui_switch__WEBPACK_IMPORTED_MODULE_11__, axios__WEBPACK_IMPORTED_MODULE_14__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _framework_auth_use_signup__WEBPACK_IMPORTED_MODULE_7__, _components_ui_switch__WEBPACK_IMPORTED_MODULE_11__, axios__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















function SignUpForm({ isPopup =true , className  }) {
    var ref, ref1, ref2;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_8__.useTranslation)();
    const { mutate: signUp , isLoading  } = (0,_framework_auth_use_signup__WEBPACK_IMPORTED_MODULE_7__/* .useSignUpMutation */ .O)();
    const { closeModal , openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_10__/* .useModalAction */ .SO)();
    const { 0: remember , 1: setRemember  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { register , handleSubmit , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)();
    function handleSignIn() {
        return openModal("LOGIN_VIEW");
    }
    function onSubmit({ firstname , lastname , email , password , password_confirm , remember_me  }) {
        signUp({
            firstname,
            lastname,
            email,
            password,
            password_confirm,
            remember_me
        });
        const formdata = {
            firstname: firstname,
            lastname: lastname,
            email: email,
            password: password,
            password_confirm: password_confirm
        };
        var config = {
            method: "post",
            url: "https://rudicloud.vercel.app/api/v1/user/register",
            headers: {},
            data: formdata
        };
        (0,axios__WEBPACK_IMPORTED_MODULE_14__["default"])(config).then(function(response) {
            localStorage.setItem("token", JSON.stringify(response.data));
            const userdata = {
                firstname: firstname,
                lastname: lastname,
                email: email,
                role: "Client"
            };
            const authconfig = {
                method: "post",
                baseURL: "https://rsbase.fanitehub.com/api/v1/clients",
                //url: 'clients/'+email,
                headers: {},
                data: userdata
            };
            (0,axios__WEBPACK_IMPORTED_MODULE_14__["default"])(authconfig).then(function(res) {
                localStorage.setItem("loggeduser2", JSON.stringify(res.data));
                window.location.href = "/";
            }).catch(function(error) {
                localStorage.setItem("loggederror2", JSON.stringify(error));
            });
        }).catch(function(error) {
            localStorage.setItem("loggederror", JSON.stringify(error));
        });
        console.log(firstname, lastname, email, password, password_confirm, "sign form values");
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex bg-brand-light mx-auto rounded-lg md:w-[720px] lg:w-[920px] xl:w-[1000px] 2xl:w-[1200px]", className),
        children: [
            isPopup === true && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_close_button__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                onClick: closeModal
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex w-full mx-auto overflow-hidden rounded-lg bg-brand-light",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:w-1/2 lg:w-[55%] xl:w-[60%] registration hidden md:block relative",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            src: "https://hub.fanitehub.com/registration.png",
                            alt: "sign up",
                            layout: "fill"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/2 lg:w-[45%] xl:w-[40%] py-6 sm:py-10 px-4 sm:px-8 md:px-6 lg:px-8 xl:px-12 rounded-md shadow-dropDown flex flex-col justify-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-center mb-6 pt-2.5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        onClick: closeModal,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                        className: "text-xl font-semibold text-brand-dark sm:text-2xl sm:pt-3 ",
                                        children: t("common:text-sign-up-for-free")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mt-3 mb-1 text-sm text-center sm:text-base text-body",
                                        children: [
                                            t("common:text-already-registered"),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                className: "text-sm font-semibold ltr:ml-1 rtl:mr-1 sm:text-base text-brand hover:no-underline focus:outline-none",
                                                onClick: handleSignIn,
                                                children: t("common:text-sign-in-now")
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                onSubmit: handleSubmit(onSubmit),
                                className: "flex flex-col justify-center",
                                noValidate: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col space-y-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: t("forms:label-name"),
                                            type: "text",
                                            variant: "solid",
                                            ...register("name", {
                                                required: "forms:name-required"
                                            }),
                                            error: (ref = errors.name) === null || ref === void 0 ? void 0 : ref.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: t("forms:label-email"),
                                            type: "email",
                                            variant: "solid",
                                            ...register("email", {
                                                required: `${t("forms:email-required")}`,
                                                pattern: {
                                                    value: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                                    message: t("forms:email-error")
                                                }
                                            }),
                                            error: (ref1 = errors.email) === null || ref1 === void 0 ? void 0 : ref1.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_password_input__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: t("forms:label-password"),
                                            error: (ref2 = errors.password) === null || ref2 === void 0 ? void 0 : ref2.message,
                                            ...register("password", {
                                                required: `${t("forms:password-required")}`
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-center",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-center shrink-0",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "relative inline-block cursor-pointer switch",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_switch__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                checked: remember,
                                                                onChange: setRemember
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            htmlFor: "remember",
                                                            className: "mt-1 text-sm cursor-pointer shrink-0 text-heading ltr:pl-2.5 rtl:pr-2.5",
                                                            children: t("forms:label-remember-me")
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex ltr:ml-auto rtl:mr-auto mt-[2px]",
                                                    onClick: closeModal
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "relative",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                type: "submit",
                                                loading: isLoading,
                                                disabled: isLoading,
                                                className: "w-full mt-2 tracking-normal h-11 md:h-12 font-15px md:font-15px",
                                                variant: "formButton",
                                                children: t("common:text-register")
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);



const CloseButton = ({ className , onClick  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: onClick,
        "aria-label": "Close Button",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("fixed z-10 inline-flex items-center justify-center w-8 h-8 lg:w-9 lg:h-9 transition duration-200 text-brand-dark text-opacity-50 focus:outline-none  hover:text-opacity-100 top-0.5 md:top-2 lg:top-7 xl:top-10 ltr:right-0.5 rtl:left-0.5 md:ltr:right-2 md:rtl:left-0 lg:ltr:right-7 lg:rtl:left-7 xl:ltr:right-10 xl:rtl:left-10 bg-brand-light lg:bg-transparent rounded-full", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_1__.IoClose, {
            className: "text-xl lg:text-2xl"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CloseButton);


/***/ }),

/***/ 410:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2687);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const SwitchComponent = ({ srText ="toggle" , checked , onChange  }, ref)=>{
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_3__/* .getDirection */ .M)(locale);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Switch, {
        checked: checked,
        onChange: onChange,
        type: "button",
        ref: ref,
        className: `${checked ? "bg-brand" : "bg-fill-four"}
          relative inline-flex shrink-0 h-6 lg:h-7 w-10 lg:w-12 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus-visible:ring-2  focus-visible:ring-brand-light focus-visible:ring-opacity-75 focus:border-brand`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "sr-only",
                children: srText
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                "aria-hidden": "true",
                className: `${checked ? dir === "rtl" ? "-translate-x-4 lg:-translate-x-5" : "translate-x-4 lg:translate-x-5" : "translate-x-0"}
            pointer-events-none inline-block h-5 lg:h-6 w-5 lg:w-6 rounded-full bg-brand-light shadow-switch transform ring-0 transition ease-in-out duration-200`
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SwitchComponent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ useSignUpMutation)
/* harmony export */ });
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8126);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9915);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_0__, js_cookie__WEBPACK_IMPORTED_MODULE_1__]);
([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_0__, js_cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function signUp(input) {
    return {
        token: `${input.email}.${input.firstname}.${input.lastname}`.split("").reverse().join("")
    };
}
console.log("signip debugger", signUp);
const useSignUpMutation = ()=>{
    const { authorize , closeModal  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_0__/* .useUI */ .l8)();
    return (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useMutation)((input)=>signUp(input), {
        onSuccess: (data)=>{
            js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].set("auth_token", data.token);
            authorize();
            closeModal();
        },
        onError: (data)=>{
            console.log(data, "login error response");
        }
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;