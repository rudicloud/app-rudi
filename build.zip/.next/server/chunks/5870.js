"use strict";
exports.id = 5870;
exports.ids = [5870];
exports.modules = {

/***/ 3462:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5225);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4685);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8448);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9137);
/* harmony import */ var _framework_customer_use_update_customer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4136);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const defaultValues = {};
const AccountDetails = ()=>{
    var ref, ref1, ref2;
    const { mutate: updateUser , isLoading  } = (0,_framework_customer_use_update_customer__WEBPACK_IMPORTED_MODULE_5__/* .useUpdateUserMutation */ .k)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const { register , handleSubmit , formState: { errors  } , control ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues
    });
    function onSubmit(input) {
        updateUser(input);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col w-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                variant: "titleLarge",
                className: "mb-5 md:mb-6 lg:mb-7 lg:-mt-1",
                children: t("common:text-account-details-personal")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleSubmit(onSubmit),
                className: "flex flex-col justify-center w-full mx-auto",
                noValidate: true,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b border-border-base pb-7 md:pb-8 lg:pb-10",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col space-y-4 sm:space-y-5",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col sm:flex-row -mx-1.5 md:-mx-2.5 space-y-4 sm:space-y-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            label: t("forms:label-first-name"),
                                            ...register("firstName", {
                                                required: "forms:first-name-required"
                                            }),
                                            variant: "solid",
                                            className: "w-full sm:w-1/2 px-1.5 md:px-2.5",
                                            error: (ref = errors.firstName) === null || ref === void 0 ? void 0 : ref.message
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            label: t("forms:label-last-name"),
                                            ...register("lastName", {
                                                required: "forms:last-name-required"
                                            }),
                                            variant: "solid",
                                            className: "w-full sm:w-1/2 px-1.5 md:px-2.5",
                                            error: (ref1 = errors.lastName) === null || ref1 === void 0 ? void 0 : ref1.message
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col sm:flex-row -mx-1.5 md:-mx-2.5 space-y-4 sm:space-y-0",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        type: "tel",
                                        label: t("forms:label-phone"),
                                        ...register("phoneNumber", {
                                            required: "forms:phone-required"
                                        }),
                                        variant: "solid",
                                        className: "w-full sm:w-1/2 px-1.5 md:px-2.5",
                                        error: (ref2 = errors.phoneNumber) === null || ref2 === void 0 ? void 0 : ref2.message
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative flex pb-2 mt-5 sm:ltr:ml-auto sm:rtl:mr-auto lg:pb-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            type: "submit",
                            loading: isLoading,
                            disabled: isLoading,
                            variant: "formButton",
                            className: "w-full sm:w-auto",
                            children: t("common:button-save-changes")
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AccountDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9183:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);


const Seo = ({ title , description , path  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
        title: title,
        description: description,
        openGraph: {
            url: `${"http://localhost:3001"}/${path}`,
            title,
            description,
            images: [
                {
                    url: "https://hub.fanitehub.com/og-image-01.png",
                    width: 800,
                    height: 600,
                    alt: "Og Image Alt"
                },
                {
                    url: "https://hub.fanitehub.com/og-image-02.png",
                    width: 900,
                    height: 800,
                    alt: "Og Image Alt Second"
                }, 
            ]
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Seo);


/***/ }),

/***/ 4136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ useUpdateUserMutation)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);

async function updateUser(input) {
    return input;
}
const useUpdateUserMutation = ()=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useMutation)((input)=>updateUser(input), {
        onSuccess: (data)=>{
            console.log(data, "UpdateUser success response");
        },
        onError: (data)=>{
            console.log(data, "UpdateUser error response");
        }
    });
};


/***/ })

};
;