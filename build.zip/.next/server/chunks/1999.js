"use strict";
exports.id = 1999;
exports.ids = [1999];
exports.modules = {

/***/ 1438:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9412);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6740);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6557);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__]);
([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const BannerGridTwo = ({ data , className ="mb-3 md:mb-4 lg:mb-5 xl:mb-6" , girdClassName ="2xl:gap-5" ,  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        children: width < 768 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            prevActivateId: "banner-carousel-button-prev",
            nextActivateId: "banner-carousel-button-next",
            children: data === null || data === void 0 ? void 0 : data.map((banner)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__/* .SwiperSlide */ .o5, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        banner: banner,
                        effectActive: true
                    })
                }, `banner-key-${banner.id}`))
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `grid gap-4 grid-cols-1 sm:grid-cols-2 ${girdClassName}`,
            children: data === null || data === void 0 ? void 0 : data.map((banner)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    banner: banner,
                    effectActive: true
                }, `banner--key${banner.id}`))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerGridTwo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3833:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ useProductsQuery),
/* harmony export */   "t": () => (/* binding */ fetchProducts)
/* harmony export */ });
/* harmony import */ var lodash_shuffle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9318);
/* harmony import */ var lodash_shuffle__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_shuffle__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fetchProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_2__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    return {
        data: lodash_shuffle__WEBPACK_IMPORTED_MODULE_0___default()(data),
        paginatorInfo: {
            nextPageUrl: ""
        }
    };
};
const useProductsQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useInfiniteQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchProducts, {
        getNextPageParam: ({ paginatorInfo  })=>paginatorInfo.nextPageUrl
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;