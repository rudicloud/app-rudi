"use strict";
exports.id = 9842;
exports.ids = [9842];
exports.modules = {

/***/ 9842:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ breadcrumb)
});

// UNUSED EXPORTS: BreadcrumbItems

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/ui/active-link.tsx




const ActiveLink = ({ children , activeClassName , href , ...props })=>{
    const { pathname  } = (0,router_.useRouter)();
    const child = external_react_.Children.only(children);
    const childClassName = child.props.className || "";
    const className = pathname === href ? `${childClassName} ${activeClassName}`.trim() : childClassName;
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: href,
        ...props,
        children: /*#__PURE__*/ external_react_default().cloneElement(child, {
            className: className || null
        })
    });
};
/* harmony default export */ const active_link = (ActiveLink);

;// CONCATENATED MODULE: ./src/utils/use-breadcrumb.ts


function convertBreadcrumbTitle(string) {
    return string.replace(/-/g, " ").replace(/oe/g, "\xf6").replace(/ae/g, "\xe4").replace(/ue/g, "\xfc").toLowerCase();
}
function useBreadcrumb() {
    const router = (0,router_.useRouter)();
    const { 0: breadcrumbs , 1: setBreadcrumbs  } = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        if (router) {
            const linkPath = router.asPath.indexOf("?") > 0 ? router.pathname.split("/") : router.asPath.split("/");
            linkPath.shift();
            const pathArray = linkPath.map((path, i)=>{
                return {
                    breadcrumb: path,
                    href: "/" + linkPath.slice(0, i + 1).join("/")
                };
            });
            setBreadcrumbs(pathArray);
        }
    }, [
        router
    ]);
    return breadcrumbs;
}

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
// EXTERNAL MODULE: ./src/utils/routes.ts
var routes = __webpack_require__(8139);
;// CONCATENATED MODULE: ./src/components/ui/breadcrumb.tsx








const BreadcrumbItem = ({ children , ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: "text-sm text-brand-muted px-2.5 transition duration-200 ease-in ltr:first:pl-0 rtl:first:pr-0 ltr:last:pr-0 rtl:last:pl-0 hover:text-brand-dark",
        ...props,
        children: children
    });
};
const BreadcrumbSeparator = ({ children , ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: "text-base text-brand-dark mt-[1px]",
        ...props,
        children: children
    });
};
const BreadcrumbItems = (props)=>{
    let children = external_react_default().Children.toArray(props.children);
    children = children.map((child, index)=>/*#__PURE__*/ jsx_runtime_.jsx(BreadcrumbItem, {
            children: child
        }, `breadcrumb_item${index}`));
    const lastIndex = children.length - 1;
    children = children.reduce((acc, child, index)=>{
        const notLast = index < lastIndex;
        if (notLast) {
            acc.push(child, /*#__PURE__*/ jsx_runtime_.jsx(BreadcrumbSeparator, {
                children: props.separator
            }, `breadcrumb_sep${index}`));
        } else {
            acc.push(child);
        }
        return acc;
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex items-center borobazarBreadcrumb",
        children: /*#__PURE__*/ jsx_runtime_.jsx("ol", {
            className: "flex items-center w-full overflow-hidden",
            children: children
        })
    });
};
const Breadcrumb = ({ separator =/*#__PURE__*/ jsx_runtime_.jsx(io5_.IoChevronForward, {
    className: "text-brand-dark text-opacity-40 text-15px"
}) ,  })=>{
    const breadcrumbs = useBreadcrumb();
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    routes/* ROUTES */.Z;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(BreadcrumbItems, {
        separator: separator,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(active_link, {
                href: routes/* ROUTES.HOME */.Z.HOME,
                activeClassName: "font-semibold text-heading",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: "inline-flex items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoHomeOutline, {
                            className: "ltr:mr-1.5 rtl:ml-1.5 text-brand-dark text-15px"
                        }),
                        t("breadcrumb-home")
                    ]
                })
            }),
            breadcrumbs === null || breadcrumbs === void 0 ? void 0 : breadcrumbs.map((breadcrumb)=>/*#__PURE__*/ jsx_runtime_.jsx(active_link, {
                    href: breadcrumb.href,
                    activeClassName: "font-semibold text-heading",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "capitalize",
                        children: convertBreadcrumbTitle(breadcrumb.breadcrumb)
                    })
                }, breadcrumb.href))
        ]
    });
};
/* harmony default export */ const breadcrumb = (Breadcrumb);


/***/ })

};
;