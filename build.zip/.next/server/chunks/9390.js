"use strict";
exports.id = 9390;
exports.ids = [9390];
exports.modules = {

/***/ 8616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ products_grid_block)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/ui/heading.tsx
var heading = __webpack_require__(8448);
// EXTERNAL MODULE: ./src/components/ui/text.tsx
var ui_text = __webpack_require__(9732);
;// CONCATENATED MODULE: ./src/components/common/best-header.tsx





const SectionHeader = ({ sectionHeading ="text-section-title" , sectionSubHeading , className ="pb-0.5 mb-5 xl:mb-6" , headingPosition ="left" ,  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()(`-mt-1.5 ${className}`, {
            "text-center pb-2 lg:pb-3 xl:pb-4 3xl:pb-7": headingPosition === "center"
        }),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(heading/* default */.Z, {
                variant: "heading",
                className: external_classnames_default()({
                    "3xl:text-[25px] 3xl:leading-9": headingPosition === "center"
                }),
                children: "All Scholastic Materials for your school needs"
            }),
            sectionSubHeading && headingPosition === "center" && /*#__PURE__*/ jsx_runtime_.jsx(ui_text/* default */.Z, {
                variant: "medium",
                className: "pb-0.5 mt-1.5 lg:mt-2.5 xl:mt-3",
                children: "We have all the scholastic materials for your school requirements."
            })
        ]
    });
};
/* harmony default export */ const best_header = (SectionHeader);

// EXTERNAL MODULE: ./src/components/product/product-cards/product-card-alpine.tsx
var product_card_alpine = __webpack_require__(7607);
// EXTERNAL MODULE: ./src/components/product/product-cards/product-card-oak.tsx
var product_card_oak = __webpack_require__(5577);
// EXTERNAL MODULE: ./src/components/ui/loaders/product-card-loader.tsx
var product_card_loader = __webpack_require__(9988);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5239);
;// CONCATENATED MODULE: ./src/components/product/products-grid-block.tsx







const ProductsGridBlock = ({ sectionHeading , sectionSubHeading , headingPosition ="center" , className ="mb-12 lg:mb-14 xl:mb-16" , products , loading , error , limit , uniqueKey , variant ="alpine" ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${className}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(best_header, {
                sectionHeading: sectionHeading,
                sectionSubHeading: sectionSubHeading,
                headingPosition: headingPosition
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: external_classnames_default()("grid", {
                    "grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 3xl:grid-cols-7 md:gap-4 2xl:gap-5": variant === "alpine"
                }, {
                    "grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6 md:gap-4 2xl:gap-5": variant === "oak"
                }),
                children: error ? /*#__PURE__*/ jsx_runtime_.jsx(ui_alert/* default */.Z, {
                    message: error,
                    className: "col-span-full"
                }) : loading && !(products === null || products === void 0 ? void 0 : products.length) ? Array.from({
                    length: limit
                }).map((_, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(product_card_loader/* default */.Z, {
                        uniqueKey: `${uniqueKey}-${idx}`
                    }, `${uniqueKey}-${idx}`)) : products === null || products === void 0 ? void 0 : products.map((product)=>variant === "oak" ? /*#__PURE__*/ jsx_runtime_.jsx(product_card_oak/* default */.Z, {
                        product: product
                    }, `${uniqueKey}-${product.id}`) : /*#__PURE__*/ jsx_runtime_.jsx(product_card_alpine/* default */.Z, {
                        product: product
                    }, `${uniqueKey}-${product.id}`))
            })
        ]
    });
};
/* harmony default export */ const products_grid_block = (ProductsGridBlock);


/***/ }),

/***/ 9092:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ fetchPopularProducts),
/* harmony export */   "T": () => (/* binding */ usePopularProductsQuery)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchPopularProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    return data;
};
const usePopularProductsQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchPopularProducts);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;