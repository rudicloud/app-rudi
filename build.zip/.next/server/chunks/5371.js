"use strict";
exports.id = 5371;
exports.ids = [5371];
exports.modules = {

/***/ 9412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6872);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6740);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);





function getImage(deviceWidth, imgObj) {
    return deviceWidth < 480 ? imgObj.mobile : imgObj.desktop;
}
const BannerCard = ({ banner , className , variant ="default" , effectActive =true , classNameInner ,  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { slug , image  } = banner;
    const selectedImage = getImage(width, image);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("mx-auto", className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            href: slug,
            className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("h-full group flex justify-center relative overflow-hidden", classNameInner),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: selectedImage.url,
                    width: selectedImage.width,
                    height: selectedImage.height,
                    alt: "rudi shule banner",
                    quality: 100,
                    className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("bg-fill-thumbnail object-cover w-full", {
                        "rounded-md": variant === "rounded"
                    })
                }),
                effectActive && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute top-0 block w-1/2 h-full transform -skew-x-12 ltr:-left-full rtl:-right-full z-5 bg-gradient-to-r from-transparent to-white opacity-30 group-hover:animate-shine"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerCard);


/***/ }),

/***/ 4808:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B$": () => (/* binding */ bannerGridMediumTwo),
/* harmony export */   "U_": () => (/* binding */ bannerDiscount),
/* harmony export */   "mk": () => (/* binding */ bannersGridHero),
/* harmony export */   "nP": () => (/* binding */ bannerGridTwo),
/* harmony export */   "u$": () => (/* binding */ bannerGridThree),
/* harmony export */   "w1": () => (/* binding */ homeThreeHeroBanner)
/* harmony export */ });
/* unused harmony exports homeTwoBanner, homeTwoBannerMedium, elegantBannerGrid, homeTwoHeroBanner, homeFourHeroBanner, homeSixHeroBanner, refinedSixHeroBanner, homeSixBanner, homeSixBannerMedium, homeRefinedBanner, homeAntiqueHeroBanner, heroSevenBanner */
const homeTwoBanner = {
    id: 1,
    title: "rudishule",
    slug: "/search",
    image: {
        mobile: {
            url: "/assets/images/banner/banner-mobile-6.png",
            width: 450,
            height: 370
        },
        desktop: {
            url: "/assets/images/banner/banner-6.png",
            width: 1460,
            height: 400
        }
    }
};
const homeTwoBannerMedium = {
    id: 1,
    title: "rudishule",
    slug: "/search",
    image: {
        mobile: {
            url: "/assets/images/banner/banner-mobile-6.png",
            width: 450,
            height: 370
        },
        desktop: {
            url: "/assets/images/banner/banner-6.png",
            width: 1400,
            height: 400
        }
    }
};
const bannersGridHero = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        type: "medium",
        image: {
            mobile: {
                url: "https://hub.fanitehub.com/banner-mobile-10.png",
                width: 450,
                height: 465
            },
            desktop: {
                url: "https://hub.fanitehub.com/banner-10.png",
                width: 1190,
                height: 500
            }
        }
    },
    {
        id: 2,
        title: "rudishule",
        slug: "/search",
        type: "small",
        image: {
            mobile: {
                url: "https://hub.fanitehub.com/banner-mobile-11.png",
                width: 450,
                height: 465
            },
            desktop: {
                url: "https://hub.fanitehub.com/banner-11.png",
                width: 740,
                height: 500
            }
        }
    }, 
];
const bannerGridTwo = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-1.png",
                width: 450,
                height: 222
            },
            desktop: {
                url: "/assets/images/banner/banner-1.png",
                width: 910,
                height: 450
            }
        }
    },
    {
        id: 2,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-2.png",
                width: 450,
                height: 222
            },
            desktop: {
                url: "/assets/images/banner/banner-2.png",
                width: 910,
                height: 450
            }
        }
    }, 
];
const elegantBannerGrid = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-8.png",
                width: 450,
                height: 440
            },
            desktop: {
                url: "/assets/images/banner/banner-8.png",
                width: 905,
                height: 420
            }
        }
    },
    {
        id: 2,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-9.png",
                width: 450,
                height: 440
            },
            desktop: {
                url: "/assets/images/banner/banner-9.png",
                width: 905,
                height: 420
            }
        }
    }, 
];
const bannerGridMediumTwo = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-1.png",
                width: 450,
                height: 220
            },
            desktop: {
                url: "/assets/images/banner/banner-medium-1.png",
                width: 720,
                height: 390
            }
        }
    },
    {
        id: 2,
        title: "Frudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-2.png",
                width: 450,
                height: 220
            },
            desktop: {
                url: "/assets/images/banner/banner-medium-2.png",
                width: 720,
                height: 390
            }
        }
    }, 
];
const bannerGridThree = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-3.png",
                width: 450,
                height: 255
            },
            desktop: {
                url: "/assets/images/banner/banner-3.png",
                width: 597,
                height: 340
            }
        }
    },
    {
        id: 2,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-4.png",
                width: 450,
                height: 255
            },
            desktop: {
                url: "/assets/images/banner/banner-4.png",
                width: 597,
                height: 340
            }
        }
    },
    {
        id: 3,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/banner-mobile-5.png",
                width: 450,
                height: 255
            },
            desktop: {
                url: "/assets/images/banner/banner-5.png",
                width: 597,
                height: 340
            }
        }
    }, 
];
const homeTwoHeroBanner = [
    {
        id: 1,
        title: "rudishule",
        description: "rudishule",
        btnText: "text-explore-more",
        btnUrl: "/search",
        image: {
            mobile: {
                url: "/assets/images/hero/banner-mobile-1.png"
            },
            desktop: {
                url: "/assets/images/hero/banner-1.png"
            }
        }
    },
    {
        id: 2,
        title: "rudishule",
        description: "rudishule",
        btnText: "text-explore-more",
        btnUrl: "/search",
        image: {
            mobile: {
                url: "/assets/images/hero/banner-1.png"
            },
            desktop: {
                url: "/assets/images/hero/banner-1.png"
            }
        }
    },
    {
        id: 3,
        title: "rudishule",
        description: "rudishule",
        btnText: "text-explore-more",
        btnUrl: "/search",
        image: {
            mobile: {
                url: "/assets/images/hero/banner-1.png"
            },
            desktop: {
                url: "/assets/images/hero/banner-1.png"
            }
        }
    }, 
];
const homeThreeHeroBanner = {
    id: 1,
    title: "rudishule",
    description: "rudishule",
    searchBox: true,
    image: {
        mobile: {
            url: "/assets/images/hero/banner-mobile-2.png"
        },
        desktop: {
            url: "/assets/images/hero/banner-2.png"
        }
    }
};
const homeFourHeroBanner = {
    id: 1,
    title: "banner-thousand-grocery-title",
    description: "banner-thousand-grocery-title-description",
    searchBox: true,
    image: {
        mobile: {
            url: "/assets/images/hero/banner-3.png"
        },
        desktop: {
            url: "/assets/images/hero/banner-3.png"
        }
    }
};
const homeSixHeroBanner = {
    id: 1,
    title: "banner-healthy-vegetable-title",
    description: "banner-healthy-vegetable-description",
    searchBox: true,
    image: {
        mobile: {
            url: "/assets/images/hero/banner-mobile-4.png"
        },
        desktop: {
            url: "/assets/images/hero/banner-4.webp"
        }
    }
};
const refinedSixHeroBanner = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/hero/banner-mobile-5.png",
                width: 450,
                height: 520
            },
            desktop: {
                url: "/assets/images/hero/banner-5.png",
                width: 1840,
                height: 370
            }
        }
    },
    {
        id: 2,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/hero/banner-mobile-6.png",
                width: 450,
                height: 520
            },
            desktop: {
                url: "/assets/images/hero/banner-6.png",
                width: 1840,
                height: 370
            }
        }
    }, 
];
const bannerDiscount = [
    {
        id: 1,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/discount/banner-1.png",
                width: 475,
                height: 250
            },
            desktop: {
                url: "/assets/images/banner/discount/banner-1.png",
                width: 475,
                height: 250
            }
        }
    },
    {
        id: 2,
        title: "Up to 50% off",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/discount/banner-2.png",
                width: 475,
                height: 250
            },
            desktop: {
                url: "/assets/images/banner/discount/banner-2.png",
                width: 475,
                height: 250
            }
        }
    },
    {
        id: 3,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/discount/banner-3.png",
                width: 475,
                height: 250
            },
            desktop: {
                url: "/assets/images/banner/discount/banner-3.png",
                width: 475,
                height: 250
            }
        }
    },
    {
        id: 4,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/discount/banner-4.png",
                width: 475,
                height: 250
            },
            desktop: {
                url: "/assets/images/banner/discount/banner-4.png",
                width: 475,
                height: 250
            }
        }
    },
    {
        id: 5,
        title: "rudishule",
        slug: "/search",
        image: {
            mobile: {
                url: "/assets/images/banner/discount/banner-5.png",
                width: 475,
                height: 250
            },
            desktop: {
                url: "/assets/images/banner/discount/banner-5.png",
                width: 475,
                height: 250
            }
        }
    }, 
];
const homeSixBanner = {
    id: 1,
    title: "rudishule",
    slug: "/search",
    image: {
        mobile: {
            url: "/assets/images/banner/banner-mobile-7.png",
            width: 450,
            height: 400
        },
        desktop: {
            url: "/assets/images/banner/banner-7.png",
            width: 1840,
            height: 400
        }
    }
};
const homeSixBannerMedium = {
    id: 1,
    title: "rudishule",
    slug: "/search",
    image: {
        mobile: {
            url: "/assets/images/banner/banner-mobile-7.png",
            width: 450,
            height: 400
        },
        desktop: {
            url: "/assets/images/banner/banner-medium-7.png",
            width: 1400,
            height: 400
        }
    }
};
const homeRefinedBanner = {
    id: 1,
    title: "rudishule",
    slug: "/search",
    image: {
        mobile: {
            url: "/assets/images/banner/banner-12.jpg",
            width: 450,
            height: 960
        },
        desktop: {
            url: "/assets/images/banner/banner-12.jpg",
            width: 385,
            height: 960
        }
    }
};
const homeAntiqueHeroBanner = {
    id: 1,
    title: "rudishule",
    description: "rudishule",
    searchBox: true,
    btnText: "Search Now",
    formTips: "rudishule",
    image: {
        mobile: {
            url: "/assets/images/hero/antique-banner-img.png"
        },
        desktop: {
            url: "/assets/images/hero/antique-banner-img.png"
        }
    }
};
const heroSevenBanner = {
    id: 1,
    title: "rudishule",
    slug: "/search",
    image: {
        mobile: {
            url: "/assets/images/hero/banner-mobile-7.png",
            width: 450,
            height: 400
        },
        desktop: {
            url: "/assets/images/hero/banner-7.png",
            width: 1400,
            height: 454
        }
    }
};


/***/ })

};
;