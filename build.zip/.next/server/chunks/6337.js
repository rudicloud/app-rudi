"use strict";
exports.id = 6337;
exports.ids = [6337];
exports.modules = {

/***/ 6337:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9412);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6740);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6557);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__]);
([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const breakpoints = {
    "560": {
        slidesPerView: 2,
        spaceBetween: 12
    },
    "0": {
        slidesPerView: 1
    }
};
const BannerGrid = ({ data , grid =3 , className ="mb-3 xl:mb-6" ,  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        children: width < 1280 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            breakpoints: breakpoints,
            prevActivateId: "bundle-carousel-button-prev",
            nextActivateId: "bundle-carousel-button-next",
            children: data === null || data === void 0 ? void 0 : data.map((banner)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__/* .SwiperSlide */ .o5, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        banner: banner,
                        effectActive: true
                    })
                }, `bundle-key-${banner.id}`))
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `grid gap-4 2xl:gap-5 grid-cols-1 sm:grid-cols-${grid}`,
            children: data === null || data === void 0 ? void 0 : data.map((banner)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    banner: banner,
                    effectActive: true
                }, `banner--key${banner.id}`))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerGrid);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;