"use strict";
exports.id = 7571;
exports.ids = [7571];
exports.modules = {

/***/ 51:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ search_box)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: ./src/components/icons/search-icon.tsx
var search_icon = __webpack_require__(2453);
;// CONCATENATED MODULE: ./src/components/icons/close-icon.tsx

const CloseIcon = ({ ...rest })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        ...rest,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M17.071 15.6564L11.4143 9.9996L17.0712 4.3427C17.4614 3.95247 17.4614 3.31881 17.071 2.92845C16.6808 2.53821 16.0471 2.53821 15.6569 2.92845L10 8.58534L4.3431 2.92845C3.95286 2.53821 3.31921 2.53821 2.92898 2.92845C2.53861 3.31881 2.53861 3.95247 2.92885 4.3427L8.58574 9.9996L2.92898 15.6564C2.53861 16.0467 2.53861 16.6804 2.92885 17.0706C3.31921 17.461 3.95286 17.461 4.34323 17.0706L10 11.4139L15.6568 17.0706C16.0471 17.461 16.6808 17.461 17.0712 17.0706C17.4614 16.6804 17.4614 16.0467 17.071 15.6564Z",
            fill: "currentColor",
            stroke: "currentColor",
            strokeWidth: "0"
        })
    });
};
/* harmony default export */ const close_icon = (CloseIcon);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/components/common/search-box.tsx






const SearchBox = /*#__PURE__*/ external_react_default().forwardRef(({ className , searchId ="search" , variant ="border" , value , onSubmit , onClear , onFocus , ...rest }, ref)=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("forms");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "relative flex w-full rounded-md",
        noValidate: true,
        role: "search",
        onSubmit: onSubmit,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: searchId,
                className: "flex flex-1 items-center py-0.5",
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    id: searchId,
                    className: external_classnames_default()("text-heading outline-none w-full h-[52px] ltr:pl-5 rtl:pr-5 md:ltr:pl-6 md:rtl:pr-6 ltr:pr-14 rtl:pl-14 md:ltr:pr-16 md:rtl:pl-16 bg-brand-light text-brand-dark text-sm lg:text-15px rounded-md transition-all duration-200 focus:border-brand focus:ring-0 placeholder:text-brand-dark/50", {
                        "border border-border-base": variant === "border",
                        "bg-fill-one": variant === "fill"
                    }),
                    placeholder: t("placeholder-search"),
                    "aria-label": searchId,
                    autoComplete: "off",
                    value: value,
                    onFocus: onFocus,
                    ref: ref,
                    ...rest
                })
            }),
            value ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                onClick: onClear,
                title: "Clear search",
                className: "absolute top-0 flex items-center justify-center h-full transition duration-200 ease-in-out outline-none ltr:right-0 rtl:left-0 w-14 md:w-16 hover:text-heading focus:outline-none",
                children: /*#__PURE__*/ jsx_runtime_.jsx(close_icon, {
                    className: "w-[17px] h-[17px] text-brand-dark text-opacity-40"
                })
            }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute top-0 flex items-center justify-center h-full w-14 md:w-16 ltr:right-0 rtl:left-0 shrink-0 focus:outline-none",
                children: /*#__PURE__*/ jsx_runtime_.jsx(search_icon/* default */.Z, {
                    className: "w-5 h-5 text-brand-dark text-opacity-40"
                })
            })
        ]
    });
});
/* harmony default export */ const search_box = (SearchBox);
SearchBox.displayName = "SearchBox";


/***/ }),

/***/ 3116:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6872);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8139);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




const SearchProduct = ({ item  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        href: `${_utils_routes__WEBPACK_IMPORTED_MODULE_2__/* .ROUTES.PRODUCT */ .Z.PRODUCT}/${item === null || item === void 0 ? void 0 : item.slug}`,
        className: "flex items-center justify-start w-full h-auto group",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative flex w-12 h-12 overflow-hidden rounded-md cursor-pointer shrink-0 ltr:mr-4 rtl:ml-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: item === null || item === void 0 ? void 0 : item.image_original,
                    width: 48,
                    height: 48,
                    loading: "eager",
                    alt: item.name || "Product Image",
                    className: "object-cover bg-fill-thumbnail"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col w-full overflow-hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "truncate text-brand-dark text-15px",
                    children: item.name
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchProduct);


/***/ }),

/***/ 5637:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _framework_product_use_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(416);
/* harmony import */ var _components_common_search_box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(51);
/* harmony import */ var _components_common_search_product__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3116);
/* harmony import */ var _components_ui_loaders_search_result_loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7547);
/* harmony import */ var _utils_use_freeze_body_scroll__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5360);
/* harmony import */ var _components_ui_scrollbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7024);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8126);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_product_use_search__WEBPACK_IMPORTED_MODULE_3__, _contexts_ui_context__WEBPACK_IMPORTED_MODULE_9__]);
([_framework_product_use_search__WEBPACK_IMPORTED_MODULE_3__, _contexts_ui_context__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Search = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(({ className ="md:w-[730px] 2xl:w-[800px]" , searchId ="search" , variant ="border" ,  }, ref)=>{
    const { displayMobileSearch , closeMobileSearch , displaySearch , closeSearch ,  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_9__/* .useUI */ .l8)();
    const { 0: searchText , 1: setSearchText  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: inputFocus , 1: setInputFocus  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { data , isLoading  } = (0,_framework_product_use_search__WEBPACK_IMPORTED_MODULE_3__/* .useSearchQuery */ .A)({
        text: searchText
    });
    (0,_utils_use_freeze_body_scroll__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(inputFocus === true || displaySearch || displayMobileSearch);
    function handleSearch(e) {
        e.preventDefault();
    }
    function handleAutoSearch(e) {
        setSearchText(e.currentTarget.value);
    }
    function clear() {
        setSearchText("");
        setInputFocus(false);
        closeMobileSearch();
        closeSearch();
    }
    function enableInputFocus() {
        setInputFocus(true);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ref: ref,
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("w-full transition-all duration-200 ease-in-out", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("overlay cursor-pointer invisible w-full h-full opacity-0 flex top-0 ltr:left-0 rtl:right-0 transition-all duration-300 fixed", {
                    open: displayMobileSearch,
                    "input-focus-overlay-open": inputFocus === true,
                    "open-search-overlay": displaySearch
                }),
                onClick: ()=>clear()
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative z-30 flex flex-col justify-center w-full shrink-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col w-full mx-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search_box__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            searchId: searchId,
                            name: "search",
                            value: searchText,
                            onSubmit: handleSearch,
                            onChange: handleAutoSearch,
                            onClear: clear,
                            onFocus: ()=>enableInputFocus(),
                            variant: variant
                        })
                    }),
                    searchText && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full absolute top-[56px] ltr:left-0 rtl:right-0 bg-brand-light rounded-md flex flex-col overflow-hidden shadow-dropDown z-30",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_scrollbar__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            className: "os-host-flexbox",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full max-h-[380px]",
                                children: isLoading ? Array.from({
                                    length: 15
                                }).map((_, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "py-2.5 ltr:pl-5 rtl:pr-5 ltr:pr-10 rtl:pl-10 scroll-snap-align-start",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_search_result_loader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            uniqueKey: `top-search-${idx}`
                                        }, idx)
                                    }, `search-result-loader-key-${idx}`)) : data === null || data === void 0 ? void 0 : data.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "py-2.5 ltr:pl-5 rtl:pr-5 ltr:pr-10 rtl:pl-10 scroll-snap-align-start transition-colors duration-200 hover:bg-fill-base",
                                        onClick: clear,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search_product__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            item: item
                                        }, index)
                                    }, `search-result-key-${index}`))
                            })
                        })
                    })
                ]
            })
        ]
    });
});
Search.displayName = "Search";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Search);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const EmailIcon = ({ color ="#B3B3B3" , width ="18" , height ="18" , className ="" ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: width,
        height: height,
        viewBox: "0 0 18 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            clipPath: "url(#clip0)",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M16.3125 2.25H1.68751C0.75696 2.25 0 3.00696 0 3.93751V14.0625C0 14.9931 0.75696 15.75 1.68751 15.75H16.3125C17.243 15.75 18 14.9931 18 14.0625V3.93751C18 3.00696 17.243 2.25 16.3125 2.25ZM16.3125 3.375C16.3889 3.375 16.4616 3.39085 16.5281 3.41854L9 9.94319L1.47188 3.41854C1.53834 3.39089 1.61105 3.375 1.68747 3.375H16.3125ZM16.3125 14.625H1.68751C1.37715 14.625 1.125 14.3729 1.125 14.0625V4.60711L8.6314 11.1127C8.73743 11.2044 8.86872 11.25 9 11.25C9.13128 11.25 9.26256 11.2044 9.3686 11.1127L16.875 4.60711V14.0625C16.875 14.3729 16.6228 14.625 16.3125 14.625Z",
                fill: color
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmailIcon);


/***/ }),

/***/ 3171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const HomeIcon = ({ color ="currentColor" , width ="18px" , height ="20px" ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: width,
        height: height,
        viewBox: "0 0 17.996 20.442",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M48.187,7.823,39.851.182A.7.7,0,0,0,38.9.2L31.03,7.841a.7.7,0,0,0-.211.5V19.311a.694.694,0,0,0,.694.694H37.3A.694.694,0,0,0,38,19.311V14.217h3.242v5.095a.694.694,0,0,0,.694.694h5.789a.694.694,0,0,0,.694-.694V8.335a.7.7,0,0,0-.228-.512ZM47.023,18.617h-4.4V13.522a.694.694,0,0,0-.694-.694H37.3a.694.694,0,0,0-.694.694v5.095H32.2V8.63l7.192-6.98L47.02,8.642v9.975Z",
            transform: "translate(-30.619 0.236)",
            fill: color,
            stroke: color,
            strokeWidth: "0.4"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeIcon);


/***/ }),

/***/ 6581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const MenuIcon = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "22",
        height: "14",
        viewBox: "0 0 25.567 18",
        ...props,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            transform: "translate(-776 -462)",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    "data-name": "Rectangle 941",
                    width: "12.749",
                    height: "2.499",
                    rx: "1.25",
                    transform: "translate(776 462)",
                    fill: "currentColor"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    "data-name": "Rectangle 942",
                    width: "25.567",
                    height: "2.499",
                    rx: "1.25",
                    transform: "translate(776 469.75)",
                    fill: "currentColor"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    "data-name": "Rectangle 943",
                    width: "17.972",
                    height: "2.499",
                    rx: "1.25",
                    transform: "translate(776 477.501)",
                    fill: "currentColor"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuIcon);


/***/ }),

/***/ 2453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const SearchIcon = ({ ...rest })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        ...rest,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M19.0144 17.9256L13.759 12.6703C14.777 11.4129 15.3899 9.81507 15.3899 8.07486C15.3899 4.04156 12.1081 0.759766 8.07483 0.759766C4.04152 0.759766 0.759766 4.04152 0.759766 8.07483C0.759766 12.1081 4.04156 15.3899 8.07486 15.3899C9.81507 15.3899 11.4129 14.777 12.6703 13.759L17.9256 19.0144C18.0757 19.1645 18.2728 19.24 18.47 19.24C18.6671 19.24 18.8642 19.1645 19.0144 19.0144C19.3155 18.7133 19.3155 18.2266 19.0144 17.9256ZM8.07486 13.8499C4.89009 13.8499 2.2998 11.2596 2.2998 8.07483C2.2998 4.89006 4.89009 2.29976 8.07486 2.29976C11.2596 2.29976 13.8499 4.89006 13.8499 8.07483C13.8499 11.2596 11.2596 13.8499 8.07486 13.8499Z",
            fill: "currentColor"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchIcon);


/***/ }),

/***/ 3231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const SendIcon = ({ color ="#02B290" , width ="20" , height ="20" , className ="" ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: width,
        height: height,
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                clipPath: "url(#clip0)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M18.809 8.21633L2.67252 1.52062C1.99272 1.23851 1.22471 1.36262 0.668264 1.84434C0.111818 2.32613 -0.120916 3.06848 0.0609589 3.78164L1.49725 9.41414H8.52951C8.85311 9.41414 9.11549 9.67648 9.11549 10.0001C9.11549 10.3237 8.85315 10.5861 8.52951 10.5861H1.49725L0.0609589 16.2186C-0.120916 16.9318 0.111779 17.6741 0.668264 18.1559C1.22584 18.6386 1.99393 18.7611 2.67256 18.4796L18.809 11.7839C19.5437 11.4791 20.0001 10.7955 20.0001 10.0001C20.0001 9.20469 19.5437 8.52113 18.809 8.21633Z",
                    fill: color
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                    id: "clip0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        width: width,
                        height: height,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SendIcon);


/***/ }),

/***/ 3865:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const UserIcon = ({ ...rest })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "22",
        height: "22",
        viewBox: "0 0 22 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...rest,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M20.9001 11C20.9001 5.52836 16.4723 1.09998 11.0001 1.09998C5.52848 1.09998 1.1001 5.52775 1.1001 11C1.1001 16.4231 5.49087 20.9 11.0001 20.9C16.4867 20.9 20.9001 16.448 20.9001 11ZM11.0001 2.26013C15.8193 2.26013 19.7399 6.1808 19.7399 11C19.7399 12.7629 19.2156 14.4573 18.2432 15.8926C14.3386 11.6924 7.66873 11.6849 3.75698 15.8926C2.78459 14.4573 2.26025 12.7629 2.26025 11C2.26025 6.1808 6.18092 2.26013 11.0001 2.26013ZM4.48056 16.8201C7.95227 12.926 14.0488 12.9269 17.5195 16.8201C14.0361 20.7172 7.96541 20.7184 4.48056 16.8201Z",
                fill: "currentColor",
                stroke: "currentColor",
                strokeWidth: "0.2"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M11 11.5801C12.9191 11.5801 14.4805 10.0187 14.4805 8.09961V6.93945C14.4805 5.02036 12.9191 3.45898 11 3.45898C9.08091 3.45898 7.51953 5.02036 7.51953 6.93945V8.09961C7.51953 10.0187 9.08091 11.5801 11 11.5801ZM8.67969 6.93945C8.67969 5.65996 9.7205 4.61914 11 4.61914C12.2795 4.61914 13.3203 5.65996 13.3203 6.93945V8.09961C13.3203 9.3791 12.2795 10.4199 11 10.4199C9.7205 10.4199 8.67969 9.3791 8.67969 8.09961V6.93945Z",
                fill: "currentColor",
                stroke: "currentColor",
                strokeWidth: "0.2"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserIcon);


/***/ }),

/***/ 5774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3879);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9734);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);




const year = new Date().getFullYear();
const Copyright = ({ payment , variant ="default" ,  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("footer");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "pb-20 lg:pb-7",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${variant === "default" && "mx-auto max-w-[1920px] px-4 md:px-6 lg:px-8 2xl:px-10"}`,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col pt-6 text-center border-t md:flex-row md:justify-between border-border-three lg:pt-7",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "text-brand-dark text-sm leading-7 lg:leading-[27px] lg:text-15px",
                        children: [
                            "\xa9\xa0",
                            t("text-copyright"),
                            " ",
                            year,
                            "\xa0",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "transition-colors duration-200 ease-in-out text-brand-dark hover:text-brand",
                                href: _settings_site_settings__WEBPACK_IMPORTED_MODULE_2__/* .siteSettings.author.websiteUrl */ .U.author.websiteUrl,
                                children: _settings_site_settings__WEBPACK_IMPORTED_MODULE_2__/* .siteSettings.author.name */ .U.author.name
                            }),
                            "\xa0 ",
                            t("text-all-rights-reserved")
                        ]
                    }),
                    payment && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "flex flex-wrap justify-center items-center -mb-1.5 md:mb-0 mx-auto md:mx-0 pt-3.5 md:pt-0",
                        children: payment === null || payment === void 0 ? void 0 : payment.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "inline-flex mb-2 transition md:mb-0 hover:opacity-80 ltr:mr-4 sm:ltr:mr-5 lg:ltr:mr-7 last:ltr:mr-0 rtl:ml-4 sm:rtl:ml-5 lg:rtl:ml-7 last:rtl:ml-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: item.path ? item.path : "/#",
                                    target: "_blank",
                                    className: "inline-flex",
                                    rel: "noreferrer",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        src: item.image,
                                        alt: t(item.name),
                                        height: item.height,
                                        width: item.width
                                    })
                                })
                            }, `payment-list--key${item.id}`))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Copyright);


/***/ }),

/***/ 1009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ footer)
/* harmony export */ });
const footer = {
    widgets: [
        {
            id: 1,
            widgetTitle: "Call to Order",
            lists: [
                {
                    id: 1,
                    title: "Help Line",
                    path: "#"
                },
                {
                    id: 2,
                    title: "+256772474631",
                    path: "#"
                },
                {
                    id: 4,
                    title: "Address",
                    path: "#"
                },
                {
                    id: 4,
                    title: "Nguvu House, Nateete, Uganda, P.O.Box 114747, Kampala, Uganda",
                    path: "#"
                },
                {
                    id: 2,
                    title: "Email",
                    path: "#"
                },
                {
                    id: 4,
                    title: "customercare@rudishule.com",
                    path: "#"
                }, 
            ]
        },
        {
            id: 2,
            widgetTitle: "widget-title-our-information",
            lists: [
                {
                    id: 1,
                    title: "link-privacy",
                    path: "/#"
                },
                {
                    id: 2,
                    title: "link-terms",
                    path: "/#"
                },
                {
                    id: 3,
                    title: "link-return-policy",
                    path: "/#"
                }, 
            ]
        }, 
    ],
    payment: [
        {
            id: 1,
            path: "/",
            image: "https://res.cloudinary.com/deiryswyr/image/upload/v1674494201/mtn_dmocnr.svg",
            name: "payment-mtn-mobile-money",
            width: 34,
            height: 20
        },
        {
            id: 2,
            path: "/",
            image: "https://res.cloudinary.com/deiryswyr/image/upload/v1674494188/airtel_uz8qaa.svg",
            name: "payment-airtel-money",
            width: 50,
            height: 20
        },
        {
            id: 3,
            path: "/",
            image: "/assets/images/payment/mastercard.svg",
            name: "payment-master-card",
            width: 76,
            height: 20
        },
        {
            id: 5,
            path: "/",
            image: "/assets/images/payment/visa.svg",
            name: "payment-visa",
            width: 39,
            height: 20
        },
        {
            id: 4,
            path: "/",
            image: "/assets/images/payment/jcb.svg",
            name: "payment-jcb",
            width: 26,
            height: 20
        }, 
    ]
};


/***/ }),

/***/ 8168:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_footer_widget_widget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7089);
/* harmony import */ var _components_layout_footer_copyright__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5774);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1009);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_footer_widget_widget__WEBPACK_IMPORTED_MODULE_1__]);
_components_layout_footer_widget_widget__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const { widgets , payment  } = _data__WEBPACK_IMPORTED_MODULE_3__/* .footer */ .M;
const Footer = ({ variant ="default"  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: "mt-[50px] lg:mt-14 2xl:mt-16",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_footer_widget_widget__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                widgets: widgets,
                variant: variant
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_footer_copyright__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                payment: payment,
                variant: variant
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9971:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7310);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9732);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8139);





const WidgetAbout = ({ social , className  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("footer");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `pb-10 sm:pb-0 ${className}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col text-center sm:ltr:text-left sm:rtl:text-right max-w-[300px] mx-auto sm:ltr:ml-0 sm:rtl:mr-0 pb-6 sm:pb-5",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    href: _utils_routes__WEBPACK_IMPORTED_MODULE_4__/* .ROUTES.HOME */ .Z.HOME,
                    className: "mx-auto mb-3 lg:mb-5 sm:ltr:ml-0 sm:rtl:mr-0"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    children: "Rudi Shule makes online school scholastic materials shopping fast and easy. Providing the ease and convenience of School Shopping at your fingertips. Download our app to enjoy more experience."
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WidgetAbout);


/***/ }),

/***/ 7897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6872);




const WidgetLink = ({ className , data  })=>{
    const { widgetTitle , lists  } = data;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("footer");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${className}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                variant: "mediumHeading",
                className: "mb-4 sm:mb-5 lg:mb-6 pb-0.5",
                children: t(`${widgetTitle}`)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "flex flex-col space-y-3 text-sm lg:text-15px",
                children: lists.map((list)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "flex items-baseline",
                        children: [
                            list.icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ltr:mr-3 rtl:ml-3 relative top-0.5 lg:top-1 text-sm lg:text-base",
                                children: list.icon
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                href: list.path ? list.path : "#!",
                                className: "transition-colors duration-200 hover:text-brand-dark",
                                children: t(`${list.title}`)
                            })
                        ]
                    }, `widget-list--key${list.id}`))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WidgetLink);


/***/ }),

/***/ 1740:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9137);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5225);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_icons_email_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9574);
/* harmony import */ var _components_icons_send_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3231);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9732);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8448);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2687);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const defaultValues = {
    email: ""
};
const WidgetSubscription = ({ className  })=>{
    var ref;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const { register , handleSubmit , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
        defaultValues
    });
    const { 0: subscriptionSuccess , 1: setSubscriptionSuccess  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    function onSubmit(values, e) {
        // show success message
        setSubscriptionSuccess(true);
        // remove success message after 3 seconds
        setTimeout(()=>{
            setSubscriptionSuccess(false);
        }, 5000);
        // reset form after submit
        e.target.reset();
        console.log(values, "News letter");
    }
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_11__/* .getDirection */ .M)(locale);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_10___default()("flex flex-col", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                variant: "mediumHeading",
                className: "mb-4 lg:mb-6 lg:pb-0.5",
                children: t("footer:widget-title-subscribe")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                className: "lg:-mt-1 max-w-[400px]",
                children: t("footer:text-subscribe")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                noValidate: true,
                className: "relative mt-5 max-w-[400px]",
                onSubmit: handleSubmit(onSubmit),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "flex items-center absolute ltr:left-0 rtl:right-0 top-0 h-12 px-3.5 transform",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_email_icon__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            className: "w-4 2xl:w-[18px] h-4 2xl:h-[18px]"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        placeholder: t("forms:placeholder-email-subscribe"),
                        type: "email",
                        id: "subscription-email",
                        variant: "solid",
                        className: "w-full",
                        inputClassName: "ltr:pl-10 rtl:pr-10 2xl:px-11 h-12 rounded-md",
                        ...register("email", {
                            required: `${t("forms:email-required")}`,
                            pattern: {
                                value: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                message: `${t("forms:email-error")}`
                            }
                        }),
                        error: (ref = errors.email) === null || ref === void 0 ? void 0 : ref.message
                    }),
                    !errors.email && subscriptionSuccess && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "my-2 text-13px text-brand",
                        children: t("common:text-subscription-success-msg")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "absolute ltr:right-0 rtl:left-0 top-0 hover:opacity-80 focus:outline-none h-12 px-3 lg:px-3.5 transform scale-90 2xl:scale-100",
                        "aria-label": "Subscribe Button",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_send_icon__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            className: `w-[18px] 2xl:w-5 h-[18px] 2xl:h-5 ${dir === "rtl" && "transform rotate-180"}`
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WidgetSubscription);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7089:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widget_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7897);
/* harmony import */ var _widget_about_us__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9971);
/* harmony import */ var _widget_subscription__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1740);
/* harmony import */ var _data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1009);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_widget_subscription__WEBPACK_IMPORTED_MODULE_3__]);
_widget_subscription__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Widgets = ({ widgets , variant ="default"  })=>{
    const { social  } = _data__WEBPACK_IMPORTED_MODULE_4__/* .footer */ .M;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${variant === "default" && "mx-auto max-w-[1920px] px-4 md:px-6 lg:px-8 2xl:px-10"}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "grid grid-cols-2 md:grid-cols-7 xl:grid-cols-12 gap-5 sm:gap-9 lg:gap-11 xl:gap-7 pb-[50px]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widget_about_us__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    social: social,
                    className: "mb-4 border-b col-span-full sm:col-span-1 md:col-span-3 sm:border-b-0 border-border-three sm:mb-0"
                }),
                widgets === null || widgets === void 0 ? void 0 : widgets.map((widget)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widget_link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        data: widget,
                        className: "pb-3.5 sm:pb-0 col-span-1 md:col-span-2"
                    }, `footer-widget--key${widget.id}`)),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_widget_subscription__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("pt-8 border-t col-span-full sm:col-span-1 md:col-start-4 xl:col-start-auto md:col-span-4 xl:col-span-3 xl:ltr:pl-6 xl:rtl:pr-6 sm:pt-0 sm:border-t-0 border-border-three", {
                        "2xl:ltr:pl-7 2xl:rtl:pr-7 3xl:ltr:pl-16 3xl:rtl:pr-16": variant === "default"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Widgets);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header_menu)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(6872);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "react-icons/io"
var io_ = __webpack_require__(4751);
;// CONCATENATED MODULE: ./src/components/ui/list-menu.tsx




const ListMenu = ({ dept , data , hasSubMenu , menuIndex  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("menu");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: "relative",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
                href: data.path,
                className: "flex items-center justify-between py-2 ltr:pl-5 rtl:pr-5 xl:ltr:pl-7 xl:rtl:pr-7 ltr:pr-3 rtl:pl-3 xl:ltr:pr-3.5 xl:rtl:pl-3.5 hover:bg-fill-dropdown-hover hover:text-brand-dark",
                children: [
                    t(data.label),
                    data.subMenu && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-sm mt-0.5 shrink-0",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(io_.IoIosArrowForward, {
                            className: "transition duration-300 ease-in-out text-body group-hover:text-brand-dark"
                        })
                    })
                ]
            }),
            hasSubMenu && /*#__PURE__*/ jsx_runtime_.jsx(SubMenu, {
                dept: dept,
                data: data.subMenu,
                menuIndex: menuIndex
            })
        ]
    });
};
const SubMenu = ({ dept , data , menuIndex  })=>{
    dept = dept + 1;
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "absolute z-0 invisible w-56 py-3 transition-all duration-300 opacity-0 subMenuChild shadow-subMenu bg-brand-light ltr:right-full rtl:left-full 2xl:ltr:right-auto 2xl:rtl:left-auto 2xl:ltr:left-full 2xl:rtl:right-full top-4",
        children: data === null || data === void 0 ? void 0 : data.map((menu, index)=>{
            const menuName = `sidebar-submenu-${dept}-${menuIndex}-${index}`;
            return /*#__PURE__*/ jsx_runtime_.jsx(ListMenu, {
                dept: dept,
                data: menu,
                hasSubMenu: menu.subMenu,
                menuName: menuName,
                menuIndex: index
            }, menuName);
        })
    });
};
/* harmony default export */ const list_menu = (ListMenu);

// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/components/layout/header/header-menu.tsx






const HeaderMenu = ({ data , className  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("menu");
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: external_classnames_default()("headerMenu flex w-full relative -mx-3 xl:-mx-4", className),
        children: data === null || data === void 0 ? void 0 : data.map((item)=>{
            /*#__PURE__*/ return (0,jsx_runtime_.jsxs)("div", {
                className: "relative py-3 mx-3 cursor-pointer menuItem group xl:mx-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
                        href: item.path,
                        className: "relative inline-flex items-center py-2 text-sm font-normal lg:text-15px text-brand-dark group-hover:text-brand before:absolute before:w-0 before:ltr:right-0 rtl:left-0 before:bg-brand before:h-[3px] before:transition-all before:duration-300 before:-bottom-[14px] group-hover:before:w-full ltr:group-hover:before:left-0 rtl:group-hover:before:right-0 lrt:group-hover:before:right-auto rtl:group-hover:before:left-auto",
                        children: [
                            t(item.label),
                            ((item === null || item === void 0 ? void 0 : item.columns) || item.subMenu) && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-xs mt-1 xl:mt-0.5 w-4 flex justify-end text-brand-dark opacity-40 group-hover:text-brand",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaChevronDown, {
                                    className: "transition duration-300 ease-in-out transform group-hover:-rotate-180"
                                })
                            })
                        ]
                    }),
                    (item === null || item === void 0 ? void 0 : item.subMenu) && Array.isArray(item === null || item === void 0 ? void 0 : item.subMenu) && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute z-30 opacity-0 subMenu shadow-dropDown transition-all duration-300 invisible bg-brand-light ltr:left-0 rtl:right-0 w-[220px] xl:w-[240px] group-hover:opacity-100",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "py-5 text-sm text-brand-muted",
                            children: item.subMenu.map((menu, index)=>{
                                const dept = 1;
                                const menuName = `sidebar-menu-${dept}-${index}`;
                                return /*#__PURE__*/ jsx_runtime_.jsx(list_menu, {
                                    dept: dept,
                                    data: menu,
                                    hasSubMenu: menu.subMenu,
                                    menuName: menuName,
                                    menuIndex: index
                                }, menuName);
                            })
                        })
                    })
                ]
            }, item.id);
        })
    });
};
/* harmony default export */ const header_menu = (HeaderMenu);


/***/ }),

/***/ 1858:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BottomNavigation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6872);
/* harmony import */ var _components_icons_search_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2453);
/* harmony import */ var _components_icons_user_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3865);
/* harmony import */ var _components_icons_menu_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6581);
/* harmony import */ var _components_icons_home_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3171);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8126);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8139);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_common_drawer_drawer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4298);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2687);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8921);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__]);
_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














const CartButton = next_dynamic__WEBPACK_IMPORTED_MODULE_9___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\mobile-navigation\\mobile-navigation.tsx -> " + "@components/cart/cart-button"
        ]
    },
    ssr: false
});
const AuthMenu = next_dynamic__WEBPACK_IMPORTED_MODULE_9___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\mobile-navigation\\mobile-navigation.tsx -> " + "@components/layout/header/auth-menu"
        ]
    },
    ssr: false
});
const MobileMenu = next_dynamic__WEBPACK_IMPORTED_MODULE_9___default()(()=>__webpack_require__.e(/* import() */ 2963).then(__webpack_require__.bind(__webpack_require__, 2963)), {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\mobile-navigation\\mobile-navigation.tsx -> " + "@components/layout/header/mobile-menu"
        ]
    }
});
function BottomNavigation() {
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_12__.useTranslation)("common");
    const { openSidebar , closeSidebar , displaySidebar , toggleMobileSearch , isAuthorized ,  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_11__/* .useModalAction */ .SO)();
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_13__/* .getDirection */ .M)(locale);
    const contentWrapperCSS = dir === "ltr" ? {
        left: 0
    } : {
        right: 0
    };
    function handleLogin() {
        openModal("LOGIN_VIEW");
    }
    function handleMobileMenu() {
        return openSidebar();
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:hidden fixed z-30 -bottom-0.5 flex items-center justify-between shadow-bottomNavigation body-font bg-brand-light w-full h-14 px-4 md:px-6 lg:px-8 text-brand-muted pb-0.5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        "aria-label": "Menu",
                        className: "flex flex-col items-center justify-center outline-none shrink-0 focus:outline-none",
                        onClick: handleMobileMenu,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_menu_icon__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "relative flex items-center justify-center h-auto shrink-0 focus:outline-none",
                        onClick: toggleMobileSearch,
                        "aria-label": "Search Button",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_search_icon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        href: _utils_routes__WEBPACK_IMPORTED_MODULE_8__/* .ROUTES.HOME */ .Z.HOME,
                        className: "shrink-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "sr-only",
                                children: t("breadcrumb-home")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_home_icon__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {
                        hideLabel: true,
                        iconClassName: "text-opacity-100"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                        isAuthorized: isAuthorized,
                        href: _utils_routes__WEBPACK_IMPORTED_MODULE_8__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                        btnProps: {
                            className: "shrink-0 focus:outline-none",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                            onClick: handleLogin
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_drawer_drawer__WEBPACK_IMPORTED_MODULE_10__/* .Drawer */ .d, {
                placement: dir === "rtl" ? "right" : "left",
                open: displaySidebar,
                onClose: closeSidebar,
                // @ts-ignore
                level: null,
                contentWrapperStyle: contentWrapperCSS,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MobileMenu, {})
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9146:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


const Container = ({ children , className , el ="div" , clean ,  })=>{
    const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_1___default()(className, {
        "mx-auto max-w-[1920px] px-4 md:px-6 lg:px-8 2xl:px-10": !clean
    });
    let Component = el;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        className: rootClassName,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ }),

/***/ 7547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8782);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_1__);


const SearchResultLoader = (props)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_content_loader__WEBPACK_IMPORTED_MODULE_1___default()), {
        speed: 2,
        width: 400,
        height: 26,
        viewBox: "0 0 400 26",
        backgroundColor: "#F3F6FA",
        foregroundColor: "#E7ECF3",
        className: "w-full h-auto rounded-md overflow-hidden",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                x: "0",
                y: "0",
                rx: "3",
                ry: "3",
                width: "26",
                height: "26"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                x: "32",
                y: "12",
                rx: "2",
                ry: "2",
                width: "100",
                height: "4"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchResultLoader);


/***/ }),

/***/ 7024:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(153);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_2__);




const Scrollbar = ({ options , children , style , className , ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_2__.OverlayScrollbarsComponent, {
        options: {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("os-theme-thin", className),
            scrollbars: {
                autoHide: "scroll"
            },
            ...options
        },
        style: style,
        ...props,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Scrollbar);


/***/ }),

/***/ 416:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useSearchQuery)
/* harmony export */ });
/* unused harmony export fetchSearchedProducts */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
//import http from '@framework/utils/http';
//import { API_ENDPOINTS } from '@framework/utils/api-endpoints';


const fetchSearchedProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    function searchProduct(product) {
        return product.name.toLowerCase().indexOf(_params.text.toLowerCase()) > -1;
    }
    return data.filter(searchProduct);
};
const useSearchQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchSearchedProducts);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2020:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ useActiveScroll)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useActiveScroll(ref, topOffset = 80) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const element = ref === null || ref === void 0 ? void 0 : ref.current;
        const listener = ()=>{
            if (window.scrollY > topOffset) {
                element === null || element === void 0 ? void 0 : element.classList.add("is-scrolling");
            } else {
                element === null || element === void 0 ? void 0 : element.classList.remove("is-scrolling");
            }
        };
        document.addEventListener("scroll", listener);
        return ()=>{
            document.removeEventListener("scroll", listener);
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
}


/***/ }),

/***/ 5360:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useFreezeBodyScroll)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useFreezeBodyScroll(freezeState) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
        document.body.style.overflow = freezeState ? "hidden" : "auto";
        document.body.style.paddingRight = freezeState ? `${scrollbarWidth}px` : "0";
    }, [
        freezeState
    ]);
}


/***/ })

};
;