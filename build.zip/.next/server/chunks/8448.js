"use strict";
exports.id = 8448;
exports.ids = [8448];
exports.modules = {

/***/ 8448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);



const Heading = ({ style , className , variant ="base" , children , html ,  })=>{
    const componentsMap = {
        base: "h3",
        heading: "h2",
        mediumHeading: "h3",
        title: "h2",
        titleMedium: "h3",
        titleLarge: "h2",
        pageHeading: "h1",
        subHeading: "h2",
        checkoutHeading: "h3"
    };
    const Component = componentsMap[variant];
    const htmlContentProps = html ? {
        dangerouslySetInnerHTML: {
            __html: html
        }
    } : {};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("text-brand-dark", {
            "text-15px sm:text-base font-semibold": variant === "base",
            "text-base xl:text-lg xl:leading-7 font-semibold font-manrope": variant === "title",
            "font-semibold text-brand-dark text-xl": variant === "titleMedium",
            "text-base lg:text-lg xl:text-[20px] font-semibold xl:leading-8": variant === "titleLarge",
            "text-base lg:text-[17px] lg:leading-7 font-medium": variant === "mediumHeading",
            "text-lg lg:text-xl xl:text-[22px] xl:leading-8 font-bold font-manrope": variant === "heading",
            "text-lg lg:text-xl xl:text-[26px] xl:leading-8 font-semibold text-brand-dark ": variant === "checkoutHeading"
        }, className),
        style: style,
        ...htmlContentProps,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Heading);


/***/ })

};
;