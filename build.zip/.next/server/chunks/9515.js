"use strict";
exports.id = 9515;
exports.ids = [9515];
exports.modules = {

/***/ 9515:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5225);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4685);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9137);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8921);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const AddPaymentForm = ()=>{
    var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, ref10, ref11, ref12, ref13;
    const { data  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_4__/* .useModalState */ .X9)();
    const { register , handleSubmit , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)({
        defaultValues: {
            title: data || (data === null || data === void 0 ? void 0 : data.title) ? data === null || data === void 0 ? void 0 : data.title : "",
            name: data || (data === null || data === void 0 ? void 0 : (ref = data.card) === null || ref === void 0 ? void 0 : ref.name) ? data === null || data === void 0 ? void 0 : (ref1 = data.card) === null || ref1 === void 0 ? void 0 : ref1.name : "",
            country: data || (data === null || data === void 0 ? void 0 : (ref2 = data.card) === null || ref2 === void 0 ? void 0 : ref2.address_country) ? data === null || data === void 0 ? void 0 : (ref3 = data.card) === null || ref3 === void 0 ? void 0 : ref3.address_country : "",
            type: data || (data === null || data === void 0 ? void 0 : data.type) ? data === null || data === void 0 ? void 0 : data.type : "",
            number: data || (data === null || data === void 0 ? void 0 : (ref4 = data.card) === null || ref4 === void 0 ? void 0 : ref4.number) ? data === null || data === void 0 ? void 0 : (ref5 = data.card) === null || ref5 === void 0 ? void 0 : ref5.number : "",
            zip: data || (data === null || data === void 0 ? void 0 : (ref6 = data.card) === null || ref6 === void 0 ? void 0 : ref6.address_zip) ? data === null || data === void 0 ? void 0 : (ref7 = data.card) === null || ref7 === void 0 ? void 0 : ref7.address_zip : "",
            default: data || (data === null || data === void 0 ? void 0 : data.default) ? data === null || data === void 0 ? void 0 : data.default : ""
        }
    });
    function onSubmit(values) {
        console.log(values, "Add Payment");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full md:w-[508px] mx-auto p-5 sm:p-8 bg-white rounded-xl",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            onSubmit: handleSubmit(onSubmit),
            noValidate: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        variant: "solid",
                        label: "Title",
                        ...register("title", {
                            required: "Title Required"
                        }),
                        error: (ref8 = errors.title) === null || ref8 === void 0 ? void 0 : ref8.message
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 mb-6 md:grid-cols-2 gap-7",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "solid",
                            label: "Name",
                            ...register("name", {
                                required: "Name Required"
                            }),
                            error: (ref9 = errors.country) === null || ref9 === void 0 ? void 0 : ref9.message
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "solid",
                            label: "Country",
                            ...register("country", {
                                required: "City Required"
                            }),
                            error: (ref10 = errors.country) === null || ref10 === void 0 ? void 0 : ref10.message
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "solid",
                            label: "Type",
                            ...register("type", {
                                required: "type Required"
                            }),
                            error: (ref11 = errors.type) === null || ref11 === void 0 ? void 0 : ref11.message
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "solid",
                            label: "Card Number",
                            ...register("number", {
                                required: "type Required"
                            }),
                            error: (ref12 = errors.number) === null || ref12 === void 0 ? void 0 : ref12.message
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            variant: "solid",
                            label: "ZIP",
                            ...register("zip", {
                                required: "ZIP Required"
                            }),
                            error: (ref13 = errors.zip) === null || ref13 === void 0 ? void 0 : ref13.message
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            id: "default-type",
                            type: "checkbox",
                            className: "w-5 h-5 transition duration-500 ease-in-out border border-gray-300 rounded cursor-pointer form-checkbox focus:ring-offset-0 hover:border-heading focus:outline-none focus:ring-0 focus-visible:outline-none checked:bg-heading",
                            ...register("default", {
                                required: "Default type Required"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            htmlFor: "default-type",
                            className: "align-middle ltr:ml-3 rtl:mr-3",
                            children: "Set Default Payment"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    className: "h-11 md:h-12 w-full mt-1.5",
                    type: "submit",
                    children: "Save Payment"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddPaymentForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;