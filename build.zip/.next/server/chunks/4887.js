"use strict";
exports.id = 4887;
exports.ids = [4887];
exports.modules = {

/***/ 8149:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CategoryDropdownMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5239);
/* harmony import */ var _components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2558);
/* harmony import */ var _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4937);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_category_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8934);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__]);
_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function CategoryDropdownMenu({ className  }) {
    var ref;
    const { data , isLoading: loading , error ,  } = (0,_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_3__/* .useCategoriesQuery */ .E)({
        limit: 15
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("absolute z-30", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "max-h-full overflow-hidden",
            children: error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "2xl:ltr:pr-4 2xl:rtl:pl-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    message: error.message
                })
            }) : loading ? Array.from({
                length: 15
            }).map((_, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    uniqueKey: "category-list-card-loader"
                }, `category-list-${idx}`)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_category_menu__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                items: data === null || data === void 0 ? void 0 : (ref = data.categories) === null || ref === void 0 ? void 0 : ref.data.slice(0, 9)
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9823:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3879);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6872);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);





const data = {
    title: "Make your online shop easier with our mobile app",
    description: "Rudi Shule makes online school scholastic materials shopping fast and easy. School Shopping at your fingertips.",
    appBG: "https://res.cloudinary.com/deiryswyr/image/upload/v1674494188/app-bg_gsme43.png",
    appImage: "https://res.cloudinary.com/deiryswyr/image/upload/v1674494188/app-thumbnail-2_v5bpvv.png",
    appButtons: [
        {
            id: 1,
            slug: "/#",
            altText: "button-app-store",
            appButton: "/assets/images/app-store.png",
            buttonWidth: 170,
            buttonHeight: 56
        },
        {
            id: 2,
            slug: "/#",
            altText: "button-play-store",
            appButton: "/assets/images/play-store.png",
            buttonWidth: 170,
            buttonHeight: 56
        }, 
    ]
};
const DownloadAppsTwo = ({ className ="pt-1.5 md:pt-0" , variant ="default" ,  })=>{
    const { appButtons , title , description , appImage , appBG  } = data;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("bg-fill-two overflow-hidden bg-cover bg-top", className),
        style: {
            backgroundImage: `url(${appBG})`
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(" md:flex justify-between max-w-[1920px] mx-auto px-4 sm:px-5 md:px-6 lg:px-16 xl:px-28 2xl:px-32", {
                " 3xl:px-40": variant === "default",
                "3xl:ltr:pl-14 3xl:rtl:pr-14": variant === "modern"
            }),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "shrink-0 mx-auto md:ltr:ml-0 md:rtl:mr-0 lg:flex lg:items-center pb-5 pt-1.5 md:pt-4 max-w-[350px] md:max-w-[340px] lg:max-w-[485px] xl:max-w-[540px] 2xl:max-w-[680px] 3xl:ltr:pl-10 3xl:rtl:pr-10",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "py-8 mb-1 text-center xl:py-10 2xl:py-16 md:ltr:text-left md:rtl:text-right",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-[22px] md:text-2xl lg:text-3xl xl:text-4xl 2xl:text-[42px] leading-9 lg:leading-[1.4em] xl:leading-[1.45em] text-brand-dark font-bold font-manrope -tracking-[0.2px] mb-3 lg:mb-4",
                                children: t(title)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-15px xl:text-base 2xl:text-[17px] leading-7 xl:leading-9 text-brand-dark text-opacity-70 pb-5 lg:pb-7 ltr:pr-0 rtl:pl-0 xl:ltr:pr-8 xl:rtl:pl-8 2xl:ltr:pr-20 2xl:rtl:pl-20",
                                children: t(description)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center md:justify-start -mx-1 md:-mx-1.5 pt-0.5 px-7 sm:px-0",
                                children: appButtons === null || appButtons === void 0 ? void 0 : appButtons.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        href: item.slug,
                                        className: "inline-flex transition duration-200 ease-in hover:box-shadow hover:opacity-80 mx-1 md:mx-1.5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            src: item.appButton,
                                            alt: t(item.altText),
                                            className: "rounded-md w-36 lg:w-44 xl:w-auto",
                                            width: item.buttonWidth,
                                            height: item.buttonHeight
                                        })
                                    }, item.id))
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "hidden md:flex items-end ltr:pl-4 rtl:pr-4 2xl:ltr:pl-0 2xl:rtl:pr-0 md:max-w-[450px] lg:max-w-[660px] xl:max-w-auto ltr:-mr-10 rtl:-ml-10 lg:ltr:-mr-16 lg:rtl:-ml-16 xl:ltr:-mr-10 xl:rtl:-ml-10 3xl:ltr:mr-7 3xl:rtl:ml-7",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        src: appImage,
                        alt: t("text-app-thumbnail"),
                        width: 660,
                        height: 465,
                        quality: 100
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DownloadAppsTwo);


/***/ }),

/***/ 8137:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8139);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8126);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9734);
/* harmony import */ var _utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2020);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9146);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7310);
/* harmony import */ var _components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8027);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5637);
/* harmony import */ var _components_icons_user_icon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3865);
/* harmony import */ var _components_icons_search_icon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2453);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8921);
/* harmony import */ var _utils_use_click_outside__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1132);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _components_category_category_dropdown_menu__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8149);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_12__, _components_category_category_dropdown_menu__WEBPACK_IMPORTED_MODULE_18__]);
([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_12__, _components_category_category_dropdown_menu__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const AuthMenu = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header-five.tsx -> " + "./auth-menu"
        ]
    },
    ssr: false
});
const CartButton = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header-five.tsx -> " + "@components/cart/cart-button"
        ]
    },
    ssr: false
});
const { site_header  } = _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U;
const Header = ()=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    const { displaySearch , displayMobileSearch , openSearch , closeSearch , isAuthorized ,  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_15__/* .useModalAction */ .SO)();
    const siteHeaderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const siteSearchRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { 0: categoryMenu , 1: setCategoryMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(Boolean(false));
    (0,_utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_8__/* .useActiveScroll */ .l)(siteHeaderRef, 40);
    (0,_utils_use_click_outside__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)(siteSearchRef, ()=>closeSearch());
    function handleLogin() {
        openModal("LOGIN_VIEW");
    }
    function handleCategoryMenu() {
        setCategoryMenu(!categoryMenu);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        id: "siteHeader",
        ref: siteHeaderRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("header-five sticky-header sticky -top-[1px] z-20 lg:relative w-full h-16 lg:h-auto", displayMobileSearch && "active-mobile-search"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "z-20 w-screen transition-all duration-200 ease-in-out innerSticky lg:w-full body-font bg-brand-light",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                    searchId: "mobile-search",
                    className: "top-bar-search hidden lg:max-w-[600px] absolute z-30 px-4 md:px-6 top-1"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    className: "flex items-center justify-between h-16 py-3 border-b top-bar lg:h-auto border-border-base",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative shrink-0 lg:hidden",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "border border-border-base rounded-md focus:outline-none shrink-0 text-sm lg:text-15px font-medium text-brand-dark px-2.5 md:px-3 lg:px-[18px] py-2 md:py-2.5 lg:py-3 flex items-center transition-all hover:border-border-four",
                                    onClick: handleCategoryMenu,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_17__.FiMenu, {
                                            className: "text-xl lg:text-2xl"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "hidden md:inline-flex ltr:ml-2.5 rtl:mr-2.5",
                                            children: t("text-all-categories")
                                        })
                                    ]
                                }),
                                categoryMenu && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_category_category_dropdown_menu__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                    className: "mt-3 md:mt-2.5"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            className: "logo -mt-1.5 md:-mt-1 md:mx-auto ltr:pl-3 rtl:pr-3 md:ltr:pl-0 md:rtl:pr-0 lg:mx-0"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            searchId: "top-bar-search",
                            className: "hidden lg:flex lg:max-w-[650px] 2xl:max-w-[800px] lg:mx-8",
                            variant: "fill"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "ltr:ml-auto rtl:mr-auto md:ltr:ml-0 md:rtl:mr-0",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex shrink-0 -mx-2.5 xl:-mx-3.5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {
                                        className: "hidden lg:flex xl:mx-3.5 mx-2.5"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "items-center hidden lg:flex shrink-0 xl:mx-3.5 mx-2.5",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                className: "text-brand-dark text-opacity-40"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                                                isAuthorized: isAuthorized,
                                                href: _utils_routes__WEBPACK_IMPORTED_MODULE_5__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                                                btnProps: {
                                                    children: t("text-sign-in"),
                                                    onClick: handleLogin
                                                },
                                                children: t("text-account")
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "hidden navbar lg:block bg-brand-light",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        className: "h-20 flex justify-between items-center py-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                className: "w-0 transition-all duration-200 ease-in-out opacity-0 navbar-logo"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "relative categories-header-button ltr:mr-8 rtl:ml-8 shrink-0",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        className: "border border-border-base rounded-md focus:outline-none shrink-0 text-15px font-medium text-brand-dark px-[18px] py-3 flex items-center transition-all hover:border-border-four",
                                        onClick: handleCategoryMenu,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_17__.FiMenu, {
                                                className: "text-2xl ltr:mr-3 rtl:ml-3"
                                            }),
                                            t("text-all-categories")
                                        ]
                                    }),
                                    categoryMenu && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_category_category_dropdown_menu__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                data: site_header.menu,
                                className: "flex transition-all duration-200 ease-in-out"
                            }),
                            displaySearch && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute top-0 left-0 flex items-center justify-center w-full h-full px-4 sticky-search",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    ref: siteSearchRef,
                                    className: "max-w-[780px] xl:max-w-[830px] 2xl:max-w-[1000px]"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center ltr:ml-auto rtl:mr-auto shrink-0",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center w-0 py-4 overflow-hidden transition-all duration-200 ease-in-out opacity-0 navbar-right",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            "aria-label": "Search Toggle",
                                            onClick: ()=>openSearch(),
                                            title: "Search toggle",
                                            className: "flex items-center justify-center w-12 h-full transition duration-200 ease-in-out outline-none ltr:mr-6 rtl:ml-6 md:w-14 hover:text-heading focus:outline-none",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_search_icon__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                className: "w-[22px] h-[22px] text-brand-dark text-opacity-40"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center shrink-0 ltr:ml-7 rtl:mr-7",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                    className: "text-brand-dark text-opacity-40"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                                                    isAuthorized: isAuthorized,
                                                    href: _utils_routes__WEBPACK_IMPORTED_MODULE_5__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                                                    btnProps: {
                                                        children: t("text-sign-in"),
                                                        onClick: handleLogin
                                                    },
                                                    children: t("text-account")
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5232:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_header_header_five__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8137);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8168);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1858);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_header_header_five__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layout_header_header_five__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function Layout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col min-h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_five__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "relative flex-grow",
                style: {
                    WebkitOverflowScrolling: "touch"
                },
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8934:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6872);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3879);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8139);







function SidebarMenuItem({ className , item , depth =0  }) {
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
    const { name , children: items , icon  } = item;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
            className: `flex justify-between items-center transition ${className ? className : "text-sm hover:text-brand px-3.5 2xl:px-4 py-2.5 border-b border-border-base last:border-b-0"}`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    href: _utils_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.SEARCH */ .Z.SEARCH,
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("flex items-center w-full ltr:text-left rtl:text-right outline-none focus:outline-none focus:ring-0 focus:text-brand-dark"),
                    children: [
                        icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "inline-flex w-8 shrink-0 3xl:h-auto",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                src: icon ?? "/assets/placeholder/category-small.svg",
                                alt: name || t("text-category-thumbnail"),
                                width: 25,
                                height: 25
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "capitalize ltr:pl-2.5 rtl:pr-2.5 md:ltr:pl-4 md:rtl:pr-4 2xl:ltr:pl-3 2xl:rtl:pr-3 3xl:ltr:pl-4 3xl:rtl:pr-4",
                            children: name
                        }),
                        items && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "hidden ltr:ml-auto rtl:mr-auto md:inline-flex",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_4__.IoIosArrowForward, {
                                className: "text-15px text-brand-dark text-opacity-40"
                            })
                        })
                    ]
                }),
                Array.isArray(items) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute top-0 z-10 invisible hidden w-full h-full border rounded-md opacity-0 md:block left-full bg-brand-light border-border-base",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "text-xs py-1.5",
                        children: items === null || items === void 0 ? void 0 : items.map((currentItem)=>{
                            const childDepth = depth + 1;
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarMenuItem, {
                                item: currentItem,
                                depth: childDepth,
                                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("text-sm px-3 py-3 ltr:pr-3 rtl:pl-3 text-brand-muted hover:text-brand border-b border-border-base last:border-b-0 mb-0.5")
                            }, `${currentItem.name}${currentItem.slug}`);
                        })
                    }, "content")
                }) : null
            ]
        })
    });
}
function SidebarMenu({ items , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("w-64 md:w-72 h-430px bg-brand-light border border-border-base rounded-md category-dropdown-menu pt-1.5", className),
        children: items === null || items === void 0 ? void 0 : items.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarMenuItem, {
                item: item
            }, `${item.slug}-key-${item.id}`))
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SidebarMenu);


/***/ }),

/***/ 1132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useOnClickOutside)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useOnClickOutside(ref, handler) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const listener = (event)=>{
            const el = ref === null || ref === void 0 ? void 0 : ref.current;
            if (!el || el.contains((event === null || event === void 0 ? void 0 : event.target) || null)) {
                return;
            }
            handler(event);
        };
        document.addEventListener("mousedown", listener);
        document.addEventListener("touchstart", listener);
        return ()=>{
            document.removeEventListener("mousedown", listener);
            document.removeEventListener("touchstart", listener);
        };
    }, [
        ref,
        handler
    ]);
}


/***/ })

};
;