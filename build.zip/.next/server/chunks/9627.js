"use strict";
exports.id = 9627;
exports.ids = [9627];
exports.modules = {

/***/ 9627:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ usePrice)
/* harmony export */ });
/* unused harmony exports formatPrice, formatVariantPrice */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function formatPrice({ amount , currencyCode , locale  }) {
    const formatCurrency = new Intl.NumberFormat(locale, {
        style: "currency",
        currency: currencyCode
    });
    return formatCurrency.format(amount);
}
function formatVariantPrice({ amount , baseAmount , currencyCode , locale  }) {
    const hasDiscount = baseAmount > amount;
    const formatDiscount = new Intl.NumberFormat(locale, {
        style: "percent"
    });
    const discount = hasDiscount ? formatDiscount.format((baseAmount - amount) / baseAmount) : null;
    const price = formatPrice({
        amount,
        currencyCode,
        locale
    });
    const basePrice = hasDiscount ? formatPrice({
        amount: baseAmount,
        currencyCode,
        locale
    }) : null;
    return {
        price,
        basePrice,
        discount
    };
}
function usePrice(data) {
    const { amount , baseAmount , currencyCode  } = data ?? {};
    const locale = "en";
    const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (typeof amount !== "number" || !currencyCode) return "";
        return baseAmount ? formatVariantPrice({
            amount,
            baseAmount,
            currencyCode,
            locale
        }) : formatPrice({
            amount,
            currencyCode,
            locale
        });
    }, [
        amount,
        baseAmount,
        currencyCode
    ]);
    return typeof value === "string" ? {
        price: value,
        basePrice: null,
        discount: null
    } : value;
}


/***/ })

};
;