"use strict";
exports.id = 7195;
exports.ids = [7195];
exports.modules = {

/***/ 6995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6872);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);



const BannerThreeCard = ({ collection , imgWidth =440 , imgHeight =280 , href ,  })=>{
    const { image_original , title , description  } = collection;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        href: href,
        className: "flex flex-col overflow-hidden rounded-md group shadow-card ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            src: image_original,
            alt: t(title) || t("text-card-thumbnail"),
            width: imgWidth,
            height: imgHeight,
            className: "object-cover transition duration-300 ease-in-out transform bg-fill-thumbnail group-hover:opacity-90 group-hover:scale-105"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerThreeCard);


/***/ }),

/***/ 1691:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9412);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2857);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__, swiper_react__WEBPACK_IMPORTED_MODULE_3__]);
([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__, swiper_react__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const breakpoints = {
    "1536": {
        slidesPerView: 3,
        spaceBetween: 20
    },
    "1280": {
        slidesPerView: 3,
        spaceBetween: 16
    },
    "1024": {
        slidesPerView: 3,
        spaceBetween: 16
    },
    "768": {
        slidesPerView: 2,
        spaceBetween: 16
    },
    "520": {
        slidesPerView: 2,
        spaceBetween: 12
    },
    "0": {
        slidesPerView: 1
    }
};
const BannerAllCarousel = ({ data , className ="mb-6" , buttonSize ="default" ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            autoplay: false,
            breakpoints: breakpoints,
            buttonSize: buttonSize,
            prevActivateId: "all-banner-carousel-button-prev",
            nextActivateId: "all-banner-carousel-button-next",
            children: data === null || data === void 0 ? void 0 : data.map((banner)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        banner: banner,
                        effectActive: true
                    })
                }, `all-banner--key${banner.id}`))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerAllCarousel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1921:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_cards_banner_three_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6995);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9146);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6740);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2857);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6557);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8139);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_4__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__, axios__WEBPACK_IMPORTED_MODULE_8__]);
([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_4__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__, axios__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const breakpoints = {
    "1024": {
        slidesPerView: 3
    },
    "768": {
        slidesPerView: 3
    },
    "540": {
        slidesPerView: 2
    },
    "0": {
        slidesPerView: 1
    }
};
const CollectionGrid = ({ className ="mb-12 lg:mb-14 xl:mb-16 2xl:mb-20 pb-1 lg:pb-0 3xl:pb-2.5" , headingPosition ="left" ,  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { 0: slideresponse , 1: setSlideresponse  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const url = "https://ruduapi.vercel.app/api/v1/products";
        axios__WEBPACK_IMPORTED_MODULE_8__["default"].get(url).then((response)=>{
            setSlideresponse(response.data);
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            children: width < 1536 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                breakpoints: breakpoints,
                autoplay: {
                    delay: 4000
                },
                prevButtonClassName: "ltr:-left-2.5 rtl:-right-2.5 -top-14",
                nextButtonClassName: "ltr:-right-2.5 rtl:-left-2.5 -top-14",
                className: "-mx-1.5 md:-mx-2 xl:-mx-2.5 -my-4",
                prevActivateId: "collection-carousel-button-prev",
                nextActivateId: "collection-carousel-button-next",
                children: slideresponse === null || slideresponse === void 0 ? void 0 : slideresponse.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_5__/* .SwiperSlide */ .o5, {
                        className: "px-1.5 md:px-2 xl:px-2.5 py-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_three_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            collection: item,
                            href: `${_utils_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.SEARCH */ .Z.SEARCH}?slug=${item.slug}`
                        }, item._id)
                    }, `collection-key-${item._id}`))
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "gap-5 2xl:grid 2xl:grid-cols-4 3xl:gap-7",
                children: slideresponse === null || slideresponse === void 0 ? void 0 : slideresponse.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_banner_three_card__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        collection: item,
                        href: `${_utils_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.SEARCH */ .Z.SEARCH}?slug=${item.slug}`
                    }, item._id))
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CollectionGrid);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7195:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_banner_grid_two__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1438);
/* harmony import */ var _framework_static_banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4808);
/* harmony import */ var _components_common_banner_all_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1691);
/* harmony import */ var _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4937);
/* harmony import */ var _components_cards_category_list_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3040);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8139);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4251);
/* harmony import */ var _components_common_banner_three__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1921);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_banner_grid_two__WEBPACK_IMPORTED_MODULE_1__, _components_common_banner_all_carousel__WEBPACK_IMPORTED_MODULE_3__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_4__, _components_common_banner_three__WEBPACK_IMPORTED_MODULE_8__]);
([_components_common_banner_grid_two__WEBPACK_IMPORTED_MODULE_1__, _components_common_banner_all_carousel__WEBPACK_IMPORTED_MODULE_3__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_4__, _components_common_banner_three__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const HeroBannerWithCategory = ({ className ="mb-12 lg:mb-14 xl:mb-16 2xl:mb-20" ,  })=>{
    var ref, ref1, ref2;
    const { data  } = (0,_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_4__/* .useCategoriesQuery */ .E)({
        limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_7__/* .LIMITS.CATEGORIES_LIMITS */ .b.CATEGORIES_LIMITS
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `xl:flex md:pb-2.5 ${className}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "hidden xl:block shrink-0 ltr:pr-8 rtl:pl-8 xl:w-[320px] 2xl:w-[370px] pt-px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col justify-between h-full border rounded-md border-border-base",
                    children: (ref2 = data === null || data === void 0 ? void 0 : (ref = data.categories) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.slice(0, 10)) === null || ref2 === void 0 ? void 0 : ref2.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cards_category_list_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            category: category,
                            href: {
                                pathname: _utils_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.SEARCH */ .Z.SEARCH,
                                query: {
                                    category: category.slug
                                }
                            },
                            className: "transition border-b border-border-base last:border-b-0",
                            variant: "small"
                        }, `category--key-${category.id}`))
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full trendy-main-content",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_banner_grid_two__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        data: _framework_static_banner__WEBPACK_IMPORTED_MODULE_2__/* .bannerGridMediumTwo */ .B$
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_banner_three__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_banner_all_carousel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        data: _framework_static_banner__WEBPACK_IMPORTED_MODULE_2__/* .bannerDiscount */ .U_,
                        buttonSize: "small",
                        className: "mb-0"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeroBannerWithCategory);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;