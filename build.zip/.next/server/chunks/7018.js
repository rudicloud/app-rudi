"use strict";
exports.id = 7018;
exports.ids = [7018];
exports.modules = {

/***/ 2883:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8139);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8126);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9734);
/* harmony import */ var _utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2020);
/* harmony import */ var _components_ui_container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9146);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7310);
/* harmony import */ var _components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8027);
/* harmony import */ var _components_common_search__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5637);
/* harmony import */ var _components_icons_user_icon__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3865);
/* harmony import */ var _components_icons_search_icon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2453);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8921);
/* harmony import */ var _utils_use_click_outside__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1132);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_12__]);
([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__, _components_common_search__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const AuthMenu = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header.tsx -> " + "./auth-menu"
        ]
    },
    ssr: false
});
const CartButton = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\layout\\header\\header.tsx -> " + "@components/cart/cart-button"
        ]
    },
    ssr: false
});
const { site_header  } = _settings_site_settings__WEBPACK_IMPORTED_MODULE_7__/* .siteSettings */ .U;
const Header = ()=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    const { displaySearch , displayMobileSearch , openSearch , closeSearch , isAuthorized ,  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const { openModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_15__/* .useModalAction */ .SO)();
    const siteHeaderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const siteSearchRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,_utils_use_active_scroll__WEBPACK_IMPORTED_MODULE_8__/* .useActiveScroll */ .l)(siteHeaderRef, 40);
    (0,_utils_use_click_outside__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)(siteSearchRef, ()=>closeSearch());
    function handleLogin() {
        openModal("LOGIN_VIEW");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        id: "siteHeader",
        ref: siteHeaderRef,
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("header-two sticky-header sticky top-0 z-20 lg:relative w-full h-16 lg:h-auto", displayMobileSearch && "active-mobile-search"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "z-20 w-screen transition-all duration-200 ease-in-out innerSticky lg:w-full body-font bg-fill-secondary",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                    searchId: "mobile-search",
                    className: "top-bar-search hidden lg:max-w-[600px] absolute z-30 px-4 md:px-6 top-1"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    className: "flex items-center justify-between h-16 py-3 top-bar lg:h-auto",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            className: "logo -mt-1.5 md:-mt-1"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            searchId: "top-bar-search",
                            className: "hidden lg:flex lg:max-w-[650px] 2xl:max-w-[800px] lg:ltr:ml-7 lg:rtl:mr-7 lg:ltr:mr-5 lg:rtl:ml-5"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex shrink-0 -mx-2.5 xl:-mx-3.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "xl:mx-3.5 mx-2.5",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                children: "Call to Order "
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                href: "tel:256772474631",
                                                children: "0772474631"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {
                                    className: "hidden lg:flex mx-2.5 xl:mx-3.5"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "items-center hidden lg:flex shrink-0 mx-2.5 xl:mx-3.5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                            className: "text-brand-dark text-opacity-40"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                                            isAuthorized: isAuthorized,
                                            href: _utils_routes__WEBPACK_IMPORTED_MODULE_5__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                                            btnProps: {
                                                children: t("text-sign-in"),
                                                onClick: handleLogin
                                            },
                                            children: t("text-account")
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "hidden navbar bg-brand-light lg:block",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_container__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        className: "flex items-center justify-between h-16",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                className: "w-0 transition-all duration-200 ease-in-out opacity-0 navbar-logo"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header_menu__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                data: site_header.menu,
                                className: "flex transition-all duration-200 ease-in-out"
                            }),
                            displaySearch && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute top-0 left-0 flex items-center justify-center w-full h-full px-4 sticky-search",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_search__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    ref: siteSearchRef,
                                    className: "max-w-[780px] xl:max-w-[830px] 2xl:max-w-[1000px]"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center ltr:ml-auto rtl:mr-auto shrink-0",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center w-0 py-4 overflow-hidden transition-all duration-200 ease-in-out opacity-0 navbar-right",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            "aria-label": "Search Toggle",
                                            onClick: ()=>openSearch(),
                                            title: "Search toggle",
                                            className: "flex items-center justify-center w-12 h-full transition duration-200 ease-in-out outline-none ltr:mr-6 rtl:ml-6 md:w-14 hover:text-heading focus:outline-none",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_search_icon__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                className: "w-[22px] h-[22px] text-brand-dark text-opacity-40"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartButton, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center shrink-0 ltr:ml-7 rtl:mr-7",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_user_icon__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                    className: "text-brand-dark text-opacity-40"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthMenu, {
                                                    isAuthorized: isAuthorized,
                                                    href: _utils_routes__WEBPACK_IMPORTED_MODULE_5__/* .ROUTES.ACCOUNT */ .Z.ACCOUNT,
                                                    btnProps: {
                                                        children: t("text-sign-in"),
                                                        onClick: handleLogin
                                                    },
                                                    children: t("text-account")
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7018:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_layout_header_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2883);
/* harmony import */ var _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8168);
/* harmony import */ var _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1858);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_header_header__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__]);
([_components_layout_header_header__WEBPACK_IMPORTED_MODULE_1__, _components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__, _components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function Layout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col min-h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_header_header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                className: "relative flex-grow",
                style: {
                    WebkitOverflowScrolling: "touch"
                },
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_footer_footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_mobile_navigation_mobile_navigation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useOnClickOutside)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useOnClickOutside(ref, handler) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const listener = (event)=>{
            const el = ref === null || ref === void 0 ? void 0 : ref.current;
            if (!el || el.contains((event === null || event === void 0 ? void 0 : event.target) || null)) {
                return;
            }
            handler(event);
        };
        document.addEventListener("mousedown", listener);
        document.addEventListener("touchstart", listener);
        return ()=>{
            document.removeEventListener("mousedown", listener);
            document.removeEventListener("touchstart", listener);
        };
    }, [
        ref,
        handler
    ]);
}


/***/ })

};
;