"use strict";
exports.id = 7239;
exports.ids = [7239];
exports.modules = {

/***/ 4821:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_product_products_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4487);
/* harmony import */ var _framework_product_get_related_product__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5530);
/* harmony import */ var _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4251);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_product_products_carousel__WEBPACK_IMPORTED_MODULE_1__, _framework_product_get_related_product__WEBPACK_IMPORTED_MODULE_2__]);
([_components_product_products_carousel__WEBPACK_IMPORTED_MODULE_1__, _framework_product_get_related_product__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const RelatedProductFeed = ({ carouselBreakpoint , className , uniqueKey ="related-product-popup" ,  })=>{
    const { data , isLoading , error  } = (0,_framework_product_get_related_product__WEBPACK_IMPORTED_MODULE_2__/* .useRelatedProductsQuery */ .Z)({
        limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__/* .LIMITS.RELATED_PRODUCTS_LIMITS */ .b.RELATED_PRODUCTS_LIMITS
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_products_carousel__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        sectionHeading: "text-related-products",
        categorySlug: "/search",
        className: className,
        products: data,
        loading: isLoading,
        error: error === null || error === void 0 ? void 0 : error.message,
        limit: _framework_utils_limits__WEBPACK_IMPORTED_MODULE_3__/* .LIMITS.RELATED_PRODUCTS_LIMITS */ .b.RELATED_PRODUCTS_LIMITS,
        uniqueKey: uniqueKey,
        carouselBreakpoint: carouselBreakpoint
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RelatedProductFeed);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7239:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProductPopup)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8139);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4685);
/* harmony import */ var _components_ui_counter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1129);
/* harmony import */ var _contexts_cart_cart_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5495);
/* harmony import */ var _components_product_product_attributes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5923);
/* harmony import */ var _utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9792);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9627);
/* harmony import */ var _framework_utils_get_variations__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2349);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7906);
/* harmony import */ var _components_icons_cart_icon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4904);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9732);
/* harmony import */ var _components_ui_tag_label__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1453);
/* harmony import */ var _components_icons_label_icon__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4475);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _components_product_feeds_related_product_feed__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4821);
/* harmony import */ var _components_ui_social_share_box__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(2853);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3590);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6740);
/* harmony import */ var _components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8921);
/* harmony import */ var _components_ui_close_button__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(9341);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(113);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_27__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_13__, _components_product_feeds_related_product_feed__WEBPACK_IMPORTED_MODULE_20__, _components_ui_social_share_box__WEBPACK_IMPORTED_MODULE_21__, react_toastify__WEBPACK_IMPORTED_MODULE_23__]);
([_components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_13__, _components_product_feeds_related_product_feed__WEBPACK_IMPORTED_MODULE_20__, _components_ui_social_share_box__WEBPACK_IMPORTED_MODULE_21__, react_toastify__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




























const breakpoints = {
    "1536": {
        slidesPerView: 6
    },
    "1280": {
        slidesPerView: 5
    },
    "1024": {
        slidesPerView: 4
    },
    "640": {
        slidesPerView: 3
    },
    "360": {
        slidesPerView: 2
    },
    "0": {
        slidesPerView: 1
    }
};
function ProductPopup() {
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_12__.useTranslation)("common");
    const { data  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_25__/* .useModalState */ .X9)();
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z)();
    const { closeModal  } = (0,_components_common_modal_modal_context__WEBPACK_IMPORTED_MODULE_25__/* .useModalAction */ .SO)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { addItemToCart , isInCart , getItemFromCart , isInStock  } = (0,_contexts_cart_cart_context__WEBPACK_IMPORTED_MODULE_7__/* .useCart */ .jD)();
    const { 0: selectedQuantity , 1: setSelectedQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const { 0: attributes , 1: setAttributes  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: addToCartLoader , 1: setAddToCartLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: favorite , 1: setFavorite  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: addToWishlistLoader , 1: setAddToWishlistLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: shareButtonStatus , 1: setShareButtonStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { basePrice , discount  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP)({
        amount: data.sale_price ? data.sale_price : data.price,
        baseAmount: data.price,
        currencyCode: "Ugx"
    });
    const variations = (0,_framework_utils_get_variations__WEBPACK_IMPORTED_MODULE_11__/* .getVariations */ .y)(data.variations);
    const { slug , gallery_image_1 , name , unit , description , gallery_image1 , tag , quantity , price ,  } = data;
    const productUrl = `${"http://localhost:3001"}${_utils_routes__WEBPACK_IMPORTED_MODULE_4__/* .ROUTES.PRODUCT */ .Z.PRODUCT}/${slug}`;
    const handleChange = ()=>{
        setShareButtonStatus(!shareButtonStatus);
    };
    const isSelected = !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(variations) ? !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(attributes) && Object.keys(variations).every((variation)=>attributes.hasOwnProperty(variation)) : true;
    let selectedVariation = {};
    if (isSelected) {
        var ref;
        selectedVariation = data === null || data === void 0 ? void 0 : (ref = data.variation_options) === null || ref === void 0 ? void 0 : ref.find((o)=>lodash_isEqual__WEBPACK_IMPORTED_MODULE_27___default()(o.options.map((v)=>v.value).sort(), Object.values(attributes).sort()));
    }
    const item = (0,_utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_9__/* .generateCartItem */ .z)(data, selectedVariation);
    const outOfStock = isInCart(item.id) && !isInStock(item.id);
    function addToCart() {
        if (!isSelected) return;
        // to show btn feedback while product carting
        setAddToCartLoader(true);
        setTimeout(()=>{
            setAddToCartLoader(false);
        }, 1500);
        addItemToCart(item, selectedQuantity);
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_23__.toast)(t("text-added-bag"), {
            progressClassName: "fancy-progress-bar",
            position: width > 768 ? "bottom-right" : "top-right",
            autoClose: 1500,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true
        });
    }
    function addToWishlist() {
        setAddToWishlistLoader(true);
        setFavorite(!favorite);
        const toastStatus = favorite === true ? t("text-remove-favorite") : t("text-added-favorite");
        setTimeout(()=>{
            setAddToWishlistLoader(false);
        }, 1500);
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_23__.toast)(toastStatus, {
            progressClassName: "fancy-progress-bar",
            position: width > 768 ? "bottom-right" : "top-right",
            autoClose: 1500,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true
        });
    }
    function navigateToProductPage() {
        closeModal();
        router.push(`${_utils_routes__WEBPACK_IMPORTED_MODULE_4__/* .ROUTES.PRODUCT */ .Z.PRODUCT}/${slug}`);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>setSelectedQuantity(1), [
        data.id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "md:w-[600px] lg:w-[940px] xl:w-[1180px] 2xl:w-[1360px] mx-auto p-1 lg:p-0 xl:p-3 bg-brand-light rounded-md",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_close_button__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                onClick: closeModal
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "overflow-hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-4 pt-4 md:px-6 lg:p-8 2xl:p-10 mb-9 lg:mb-2 md:pt-7 2xl:pt-10",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "items-start justify-between lg:flex",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "items-center justify-center mb-6 overflow-hidden xl:flex md:mb-8 lg:mb-0",
                                    children: !!(gallery_image1 === null || gallery_image1 === void 0 ? void 0 : gallery_image1.length) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_thumbnail_carousel__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                        gallery: gallery_image1
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center justify-center w-auto",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: gallery_image_1,
                                            alt: name,
                                            width: 650,
                                            height: 590
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "shrink-0 flex flex-col lg:ltr:pl-5 lg:rtl:pr-5 xl:ltr:pl-8 xl:rtl:pr-8 2xl:ltr:pl-10 2xl:rtl:pr-10 lg:w-[430px] xl:w-[470px] 2xl:w-[480px]",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "pb-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mb-2 md:mb-2.5 block -mt-1.5",
                                                    onClick: navigateToProductPage,
                                                    role: "button",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "text-lg font-medium transition-colors duration-300 text-brand-dark md:text-xl xl:text-2xl hover:text-brand",
                                                        children: name
                                                    })
                                                }),
                                                unit && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(variations) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-sm font-medium md:text-15px",
                                                    children: unit
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-sm font-medium md:text-15px"
                                                }),
                                                lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(variations) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex items-center mt-5",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "text-brand-dark font-bold text-base md:text-xl xl:text-[22px]",
                                                        children: [
                                                            price,
                                                            "/= Ugx"
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        Object.keys(variations).map((variation)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_attributes__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                variations: variations,
                                                attributes: attributes,
                                                setAttributes: setAttributes
                                            }, `popup-attribute-key${variation}`);
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "pb-2",
                                            children: [
                                                lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(variations) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: Number(quantity) > 0 || !outOfStock ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-sm font-medium text-yellow",
                                                        children: t("text-only") + " " + quantity + " " + t("text-left-item")
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "text-base text-brand-danger whitespace-nowrap",
                                                        children: t("text-out-stock")
                                                    })
                                                }),
                                                !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(selectedVariation) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-sm font-medium text-yellow",
                                                    children: (selectedVariation === null || selectedVariation === void 0 ? void 0 : selectedVariation.is_disable) || selectedVariation.quantity === 0 ? t("text-out-stock") : `${t("text-only") + " " + selectedVariation.quantity + " " + t("text-left-item")}`
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "pt-1.5 lg:pt-3 xl:pt-4 space-y-2.5 md:space-y-3.5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_counter__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                    variant: "single",
                                                    value: selectedQuantity,
                                                    onIncrement: ()=>setSelectedQuantity((prev)=>prev + 1),
                                                    onDecrement: ()=>setSelectedQuantity((prev)=>prev !== 1 ? prev - 1 : 1),
                                                    disabled: isInCart(item.id) ? getItemFromCart(item.id).quantity + selectedQuantity >= Number(item.stock) : selectedQuantity >= Number(item.stock)
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                    onClick: addToCart,
                                                    className: "w-full px-1.5",
                                                    disabled: !isSelected,
                                                    loading: addToCartLoader,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_cart_icon__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                            color: "#ffffff",
                                                            className: "ltr:mr-3 rtl:ml-3"
                                                        }),
                                                        t("text-add-to-cart")
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "grid grid-cols-2 gap-2.5",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                            variant: "border",
                                                            onClick: addToWishlist,
                                                            loading: addToWishlistLoader,
                                                            className: `group hover:text-brand ${favorite === true && "text-brand"}`,
                                                            children: [
                                                                favorite === true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_22__.IoIosHeart, {
                                                                    className: "text-2xl md:text-[26px] ltr:mr-2 rtl:ml-2 transition-all"
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_22__.IoIosHeartEmpty, {
                                                                    className: "text-2xl md:text-[26px] ltr:mr-2 rtl:ml-2 transition-all group-hover:text-brand"
                                                                }),
                                                                t("text-wishlist")
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "relative group",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                                    variant: "border",
                                                                    className: `w-full hover:text-brand ${shareButtonStatus === true && "text-brand"}`,
                                                                    onClick: handleChange,
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_19__.IoArrowRedoOutline, {
                                                                            className: "text-2xl md:text-[26px] ltr:mr-2 rtl:ml-2 transition-all group-hover:text-brand"
                                                                        }),
                                                                        t("text-share")
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_social_share_box__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                                    className: `absolute z-10 ltr:right-0 rtl:left-0 w-[300px] md:min-w-[400px] transition-all duration-300 ${shareButtonStatus === true ? "visible opacity-100 top-full" : "opacity-0 invisible top-[130%]"}`,
                                                                    shareUrl: productUrl
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        tag && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                            className: "pt-5 xl:pt-6",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "relative inline-flex items-center justify-center text-sm md:text-15px text-brand-dark text-opacity-80 ltr:mr-2 rtl:ml-2 top-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons_label_icon__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                            className: "ltr:mr-2 rtl:ml-2"
                                                        }),
                                                        " ",
                                                        t("text-tags"),
                                                        ":"
                                                    ]
                                                }),
                                                tag === null || tag === void 0 ? void 0 : tag.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "inline-block p-[3px]",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_tag_label__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                            data: item
                                                        })
                                                    }, `tag-${item.id}`))
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "pt-6 xl:pt-8",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_heading__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                    className: "mb-3 lg:mb-3.5",
                                                    children: [
                                                        t("text-product-details"),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_text__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                    variant: "small",
                                                    children: [
                                                        description.split(" ").slice(0, 40).join(" "),
                                                        "...",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            onClick: navigateToProductPage,
                                                            role: "button",
                                                            className: "text-brand ltr:ml-0.5 rtl:mr-0.5",
                                                            children: t("text-read-more")
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_feeds_related_product_feed__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                        carouselBreakpoint: breakpoints,
                        className: "mb-0.5 md:mb-2 lg:mb-3.5 xl:mb-4 2xl:mb-6"
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6003);
/* harmony import */ var _components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6557);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5239);
/* harmony import */ var _components_ui_see_all__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3941);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6740);
/* harmony import */ var _components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9988);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _utils_get_direction__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2687);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__]);
([_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__, _components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const breakpoints = {
    "1921": {
        slidesPerView: 7
    },
    "1780": {
        slidesPerView: 8
    },
    "1536": {
        slidesPerView: 7
    },
    "1280": {
        slidesPerView: 6
    },
    "1024": {
        slidesPerView: 4
    },
    "640": {
        slidesPerView: 3
    },
    "360": {
        slidesPerView: 2
    },
    "0": {
        slidesPerView: 1
    }
};
const ProductsCarousel = ({ sectionHeading , categorySlug , className ="mb-8 lg:mb-10 xl:mb-12" , products , loading , error , limit , uniqueKey , carouselBreakpoint ,  })=>{
    const { width  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const dir = (0,_utils_get_direction__WEBPACK_IMPORTED_MODULE_11__/* .getDirection */ .M)(locale);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("max-w-[1920px] overflow-hidden 4xl:overflow-visible px-4 md:px-6 lg:px-8 2xl:ltr:pl-10 2xl:rtl:pr-10 2xl:ltr:pr-0 2xl:rtl:pl-0 4xl:ltr:pr-10 4xl:rtl:pl-10 mx-auto relative", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-wrap items-center justify-between mb-5 md:mb-6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    sectionHeading: sectionHeading,
                    className: "mb-0"
                })
            }),
            error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "2xl:ltr:pr-10 2xl:rtl:pl-10",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    message: error
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `heightFull relative after-item-opacity  ${dir === "rtl" ? "xl:-ml-40 2xl:-ml-28 4xl:ml-0" : "xl:-mr-40 2xl:-mr-28 4xl:mr-0"}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    breakpoints: carouselBreakpoint || breakpoints,
                    className: "-mx-1.5 md:-mx-2 xl:-mx-2.5 -mt-4",
                    prevButtonClassName: "ltr:-left-2 rtl:-right-2 md:ltr:-left-1 md:rtl:-right-1.5 lg:ltr:-left-2 rtl:-right-2 xl:ltr:-left-2.5 xl:rtl:-right-2.5 2xl:ltr:left-5 2xl:rtl:right-5 -top-12 3xl:top-auto 3xl:-translate-y-2 4xl:-translate-y-10",
                    nextButtonClassName: "xl:rtl:-translate-x-2.5 xl:lrt:translate-x-2.5 ltr:-right-2 rtl:-left-2 xl:ltr:right-40 xl:rtl:left-40 -top-12 3xl:top-auto transform 2xl:translate-x-0 3xl:-translate-y-2 4xl:-translate-y-10",
                    children: loading && !(products === null || products === void 0 ? void 0 : products.length) ? Array.from({
                        length: limit
                    }).map((_, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__/* .SwiperSlide */ .o5, {
                            className: "px-1.5 md:px-2 xl:px-2.5 py-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_product_card_loader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                uniqueKey: `${uniqueKey}-${idx}`
                            })
                        }, `${uniqueKey}-${idx}`)) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            products === null || products === void 0 ? void 0 : products.map((product, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__/* .SwiperSlide */ .o5, {
                                    className: "px-1.5 md:px-2 xl:px-2.5 py-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_product_cards_product_card_alpine__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        product: product
                                    })
                                }, `${uniqueKey}-${idx}`)),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__/* .SwiperSlide */ .o5, {
                                className: "p-2.5 flex items-center justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_see_all__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    href: categorySlug
                                })
                            }),
                            width > 1024 && width < 1921 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_carousel_slider__WEBPACK_IMPORTED_MODULE_4__/* .SwiperSlide */ .o5, {})
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsCarousel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);



const CloseButton = ({ className , onClick  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: onClick,
        "aria-label": "Close Button",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("fixed z-10 inline-flex items-center justify-center w-8 h-8 lg:w-9 lg:h-9 transition duration-200 text-brand-dark text-opacity-50 focus:outline-none  hover:text-opacity-100 top-0.5 md:top-2 lg:top-7 xl:top-10 ltr:right-0.5 rtl:left-0.5 md:ltr:right-2 md:rtl:left-0 lg:ltr:right-7 lg:rtl:left-7 xl:ltr:right-10 xl:rtl:left-10 bg-brand-light lg:bg-transparent rounded-full", className),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_1__.IoClose, {
            className: "text-xl lg:text-2xl"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CloseButton);


/***/ }),

/***/ 6872:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Link)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function Link({ href , children , className , ...props }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: href,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: className,
            ...props,
            children: children
        })
    });
}


/***/ }),

/***/ 3941:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ see_all)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/components/icons/arrow-icon.tsx


const ArrowIcon = ({ className ="" , color ="currentColor" , width ="50" , height ="50" ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: external_classnames_default()(className),
        width: width,
        height: height,
        viewBox: "0 0 50 50",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                cx: "25",
                cy: "25",
                r: "24",
                fill: "white",
                stroke: color,
                strokeWidth: "2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M13.4762 23.9716H34.3756L26.3729 16.4878C25.9538 16.0959 25.9376 15.4448 26.3367 15.0334C26.7354 14.6225 27.3985 14.606 27.8181 14.9979L36.9575 23.5452C37.353 23.934 37.5714 24.4504 37.5714 25.0001C37.5714 25.5494 37.353 26.0662 36.9392 26.472L27.8176 35.0018C27.6148 35.1916 27.355 35.2857 27.0952 35.2857C26.8187 35.2857 26.5421 35.1788 26.3362 34.9664C25.9371 34.5549 25.9533 33.9044 26.3724 33.5125L34.4086 26.0287H13.4762C12.8979 26.0287 12.4286 25.5679 12.4286 25.0001C12.4286 24.4324 12.8979 23.9716 13.4762 23.9716Z",
                fill: color,
                stroke: color,
                strokeWidth: "0.5"
            })
        ]
    });
};
/* harmony default export */ const arrow_icon = (ArrowIcon);

// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(6872);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
;// CONCATENATED MODULE: ./src/components/ui/see-all.tsx




const SeeAll = ({ className , href ="/"  })=>{
    const { t  } = (0,external_next_i18next_.useTranslation)("common");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
        href: href,
        className: `${className} p-4 flex items-center justify-center flex-col hover:opacity-80`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(arrow_icon, {
                color: "#02B290",
                className: "w-10"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "font-semibold text-sm sm:text-base text-brand block pt-1.5 sm:pt-3.5",
                children: t("text-see-all")
            })
        ]
    });
};
/* harmony default export */ const see_all = (SeeAll);


/***/ }),

/***/ 2853:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8448);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9732);
/* harmony import */ var _components_ui_form_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5225);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9137);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2807);
/* harmony import */ var react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6158);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_share__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_6__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const defaultValues = {
    shareLink: ""
};
const SocialShareBox = ({ className ="" , shareUrl =""  })=>{
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
    const { 0: copyText , 1: setCopyText  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        value: shareUrl,
        copied: false
    });
    const { register  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useForm)({
        defaultValues
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (copyText.copied) {
            setTimeout(()=>{
                setCopyText({
                    ...copyText,
                    copied: false
                });
            }, 1500);
        }
    }, [
        copyText
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("shadow-card bg-brand-light rounded-md p-4 md:p-6 lg:p-7", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                className: "mb-2",
                children: t("text-share-social-network")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                variant: "small",
                children: t("text-share-social-network-description")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap items-center mb-4 -mx-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.FacebookShareButton, {
                        url: shareUrl,
                        className: "mx-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.FacebookIcon, {
                            size: 40,
                            round: true,
                            className: "transition-all hover:opacity-90"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.TwitterShareButton, {
                        url: shareUrl,
                        className: "mx-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.TwitterIcon, {
                            size: 40,
                            round: true,
                            className: "transition-all hover:opacity-90"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.WhatsappShareButton, {
                        url: shareUrl,
                        separator: ":: ",
                        className: "mx-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.WhatsappIcon, {
                            size: 40,
                            round: true,
                            className: "transition-all hover:opacity-90"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.LinkedinShareButton, {
                        url: shareUrl,
                        className: "mx-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_9__.LinkedinIcon, {
                            size: 40,
                            round: true,
                            className: "transition-all hover:opacity-90"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                variant: "small",
                children: t("text-or-copy-link")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative mt-2.5 mb-1.5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_form_input__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        type: "link",
                        variant: "solid",
                        className: "w-full",
                        value: shareUrl,
                        inputClassName: "px-4 border-border-base rounded-md focus:outline focus:border-brand",
                        ...register("shareLink", {
                            pattern: {
                                value: /^((https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,}))$/,
                                message: " "
                            }
                        })
                    }),
                    !copyText.copied ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_copy_to_clipboard__WEBPACK_IMPORTED_MODULE_8___default()), {
                        text: copyText.value,
                        onCopy: ()=>setCopyText({
                                ...copyText,
                                copied: true
                            }),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "absolute ltr:right-0.5 rtl:left-0.5 top-[6%] h-[90%] px-2 text-brand text-sm uppercase font-bold flex items-center bg-brand-light cursor-pointer",
                            role: "button",
                            children: t("text-copy")
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "absolute ltr:right-0.5 rtl:left-0.5 top-[6%] h-[90%] ltr:pr-1.5 rtl:pl-1.5 ltr:pl-8 rtl:pr-8 text-brand text-sm uppercase font-bold flex items-center bg-brand-light cursor-pointer",
                        children: t("text-copied")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SocialShareBox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5530:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useRelatedProductsQuery)
/* harmony export */ });
/* unused harmony export fetchRelatedProducts */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchRelatedProducts = async ({ queryKey  })=>{
    const api = axios__WEBPACK_IMPORTED_MODULE_1__["default"].create({
        baseURL: "https://ruduapi.vercel.app/api/v1/"
    });
    const [_key, _params] = queryKey;
    const { data  } = await api.get("products");
    return data;
};
const useRelatedProductsQuery = (options)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "https://rudicloud.vercel.app/api/v1/products",
        options
    ], fetchRelatedProducts);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4251:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ LIMITS)
/* harmony export */ });
const LIMITS = {
    CATEGORIES_LIMITS: 18,
    PRODUCTS_LIMITS: 30,
    REFINED_PRODUCTS_LIMITS: 20,
    RELATED_PRODUCTS_LIMITS: 15,
    BEST_SELLER_PRODUCTS_LIMITS: 15,
    BEST_SELLER_GROCERY_PRODUCTS_LIMITS: 21,
    POPULAR_PRODUCTS_LIMITS: 14,
    POPULAR_PRODUCTS_TWO_LIMITS: 10,
    COOKIES_PRODUCTS_LIMITS: 15,
    CHIPS_PRODUCTS_LIMITS: 15,
    POPCORN_JERKY_PRODUCTS_LIMITS: 15,
    FRESH_VEGETABLES_PRODUCTS_LIMITS: 15
};


/***/ })

};
;