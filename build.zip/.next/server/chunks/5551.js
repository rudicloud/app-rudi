"use strict";
exports.id = 5551;
exports.ids = [5551];
exports.modules = {

/***/ 5437:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8126);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contexts_ui_context__WEBPACK_IMPORTED_MODULE_4__]);
_contexts_ui_context__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function checkIsActive(arr, item) {
    if (arr.includes(item)) {
        return true;
    }
    return false;
}
function CategoryFilterMenuItem({ className ="hover:bg-fill-base border-t border-border-base first:border-t-0 px-3.5 2xl:px-4 py-3 xl:py-3.5 2xl:py-2.5 3xl:py-3" , item , depth =0  }) {
    var ref;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)("common");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { pathname , query  } = router;
    const selectedCategories = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(()=>{
        return (query === null || query === void 0 ? void 0 : query.category) ? query.category.split(",") : [];
    }, [
        query === null || query === void 0 ? void 0 : query.category
    ]);
    const isActive = checkIsActive(selectedCategories, item.slug) || (item === null || item === void 0 ? void 0 : (ref = item.children) === null || ref === void 0 ? void 0 : ref.some((_item)=>checkIsActive(selectedCategories, _item.slug)));
    const { 0: isOpen , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(isActive);
    const { 0: subItemAction , 1: setSubItemAction  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        setOpen(isActive);
    }, [
        isActive
    ]);
    const { slug , name , children: items , image_original  } = item;
    const { displaySidebar , closeSidebar  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_4__/* .useUI */ .l8)();
    function toggleCollapse() {
        setOpen((prevValue)=>!prevValue);
    }
    const handleChange = ()=>{
        setSubItemAction(!subItemAction);
    };
    function onClick() {
        if (Array.isArray(items) && !!items.length) {
            toggleCollapse();
        } else {
            const { category , ...restQuery } = query;
            let currentFormState = selectedCategories.includes(slug) ? selectedCategories.filter((i)=>i !== slug) : [
                ...selectedCategories,
                slug
            ];
            router.push({
                pathname,
                query: {
                    ...restQuery,
                    ...!!currentFormState.length ? {
                        category: currentFormState.join(",")
                    } : {}
                }
            }, undefined, {
                scroll: false
            });
            displaySidebar && closeSidebar();
        }
    }
    let expandIcon;
    if (Array.isArray(items) && items.length) {
        expandIcon = !isOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_3__.IoIosArrowDown, {
            className: "text-base text-brand-dark text-opacity-40"
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_3__.IoIosArrowUp, {
            className: "text-base text-brand-dark text-opacity-40"
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                onClick: onClick,
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex justify-between items-center transition text-sm md:text-15px", {
                    "bg-fill-base": isOpen
                }, className),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex items-center w-full ltr:text-left rtl:text-right cursor-pointer group", {
                        "py-3 xl:py-3.5 2xl:py-2.5 3xl:py-3": depth > 0
                    }),
                    children: [
                        image_original && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "inline-flex shrink-0 2xl:w-12 2xl:h-12 3xl:w-auto 3xl:h-auto ltr:mr-2.5 rtl:ml-2.5 md:ltr:mr-4 md:rtl:ml-4 2xl:ltr:mr-3 2xl:rtl:ml-3 3xl:ltr:mr-4 3xl:rtl:ml-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: image_original,
                                alt: name,
                                width: 40,
                                height: 40
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-brand-dark capitalize py-0.5",
                            children: name
                        }),
                        depth > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: `w-[22px] h-[22px] text-13px flex items-center justify-center border-2 border-border-four rounded-full ltr:ml-auto rtl:mr-auto transition duration-500 ease-in-out group-hover:border-yellow-100 text-brand-light ${selectedCategories.includes(slug) && "border-yellow-100 bg-yellow-100"}`,
                            children: selectedCategories.includes(slug) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_7__.FaCheck, {})
                        }),
                        expandIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ltr:ml-auto rtl:mr-auto",
                            children: expandIcon
                        })
                    ]
                })
            }),
            Array.isArray(items) && isOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: "px-4 text-xs",
                    children: items === null || items === void 0 ? void 0 : items.map((currentItem)=>{
                        const childDepth = depth + 1;
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CategoryFilterMenuItem, {
                            item: currentItem,
                            depth: childDepth,
                            className: "px-0 border-t border-border-base first:border-t-0 mx-[3px] bg-transparent"
                        }, `${currentItem.name}${currentItem.slug}`);
                    })
                }, "content")
            }) : null
        ]
    });
}
function CategoryFilterMenu({ items , className  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(className),
        children: items === null || items === void 0 ? void 0 : items.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CategoryFilterMenuItem, {
                item: item
            }, `${item.slug}-key-${item.id}`))
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryFilterMenu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3784:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ CategoryFilter)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8448);
/* harmony import */ var _components_search_category_filter_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5437);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5239);
/* harmony import */ var _components_ui_scrollbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7024);
/* harmony import */ var _components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2558);
/* harmony import */ var _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4937);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_search_category_filter_menu__WEBPACK_IMPORTED_MODULE_3__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_7__]);
([_components_search_category_filter_menu__WEBPACK_IMPORTED_MODULE_3__, _framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const CategoryFilter = ()=>{
    var ref, ref1, ref2;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("common");
    const { data , isLoading: loading , error ,  } = (0,_framework_category_get_all_categories__WEBPACK_IMPORTED_MODULE_7__/* .useCategoriesQuery */ .E)({
        limit: 10
    });
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "hidden xl:block",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-72 mt-8 px-2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_loaders_category_list_card_loader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    uniqueKey: "category-list-card-loader"
                })
            })
        });
    }
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        message: error.message
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "block",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                className: "mb-5 -mt-1",
                children: t("text-categories")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-h-full overflow-hidden rounded border border-border-base",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_scrollbar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    className: "w-full category-filter-scrollbar",
                    children: (data === null || data === void 0 ? void 0 : (ref = data.categories) === null || ref === void 0 ? void 0 : (ref1 = ref.data) === null || ref1 === void 0 ? void 0 : ref1.length) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search_category_filter_menu__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        items: data === null || data === void 0 ? void 0 : (ref2 = data.categories) === null || ref2 === void 0 ? void 0 : ref2.data
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "min-h-full pt-6 pb-8 px-9 lg:p-8",
                        children: t("text-no-results-found")
                    })
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ FilteredItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__);




const FilteredItem = ({ itemKey , itemValue  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { pathname , query  } = router;
    function handleClose() {
        const currentItem = query[itemKey].split(",").filter((i)=>i !== itemValue);
        delete query[itemKey];
        router.push({
            pathname,
            query: {
                ...query,
                ...!lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(currentItem) ? {
                    [itemKey]: currentItem.join(",")
                } : {}
            }
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "group flex shrink-0 m-1 items-center border border-border-base rounded-lg text-13px px-2.5 py-1.5 capitalize text-brand-dark cursor-pointer transition duration-200 ease-in-out hover:border-brand",
        onClick: handleClose,
        children: [
            itemValue,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_2__.IoClose, {
                className: "text-sm text-body ltr:ml-2 rtl:mr-2 shrink-0 ltr:-mr-0.5 rtl:-ml-0.5 mt-0.5 transition duration-200 ease-in-out group-hover:text-heading"
            })
        ]
    });
};


/***/ }),

/***/ 5551:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ ShopFilters)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _category_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3784);
/* harmony import */ var _filtered_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9138);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9699);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_ui_heading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8448);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_category_filter__WEBPACK_IMPORTED_MODULE_1__]);
_category_filter__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ShopFilters = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { pathname , query  } = router;
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "space-y-10",
        children: [
            !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default()(query) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "block -mb-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between mb-4 -mt-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_heading__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                children: t("text-filters")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "flex-shrink transition duration-150 ease-in text-13px focus:outline-none hover:text-brand-dark",
                                "aria-label": t("text-clear-all"),
                                onClick: ()=>{
                                    router.push(pathname);
                                },
                                children: t("text-clear-all")
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap -m-1",
                        children: Object.values(query).join(",").split(",").map((v, idx)=>{
                            return !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_4___default()(v) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filtered_item__WEBPACK_IMPORTED_MODULE_2__/* .FilteredItem */ .S, {
                                itemKey: Object.keys(query).find((k)=>{
                                    var ref;
                                    return (ref = query[k]) === null || ref === void 0 ? void 0 : ref.includes(v);
                                }),
                                itemValue: v
                            }, idx);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_category_filter__WEBPACK_IMPORTED_MODULE_1__/* .CategoryFilter */ .f, {})
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;